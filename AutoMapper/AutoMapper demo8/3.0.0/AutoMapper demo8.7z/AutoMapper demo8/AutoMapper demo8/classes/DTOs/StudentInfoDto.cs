﻿using AutoMapper;
using AutoMapper_demo8.classes.Entities;

namespace AutoMapper_demo8.classes.DTOs
{
    [AutoMap(typeof(StudentInfo))]
    public class StudentInfoDto
    {
        public User Student { get; set; }
        public int Score { get; set; }
    }
}

﻿using AutoMapper;
using AutoMapper_demo2.Mapping.MapperProfiles;

namespace AutoMapper_demo2.Mapping.Mappers
{
    public class UserMappers
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg => {
                cfg.AddProfile<UserProfile>();
                cfg.AddProfile<UserDTOProfile>();
            });
            var mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

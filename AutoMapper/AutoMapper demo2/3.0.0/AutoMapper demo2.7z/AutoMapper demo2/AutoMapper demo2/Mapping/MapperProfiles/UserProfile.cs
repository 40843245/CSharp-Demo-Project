﻿using AutoMapper;
using AutoMapper_demo2.classes;
using AutoMapper_demo2.Mapping.Resolvers;

namespace AutoMapper_demo2.Mapping.MapperProfiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<User, UserDTO>()
                   .ForMember(userDTO => userDTO.USERNAME, action => action.MapFrom(user => user.username))
                   .ForMember(userDTO => userDTO.ACCOUNT, action => action.MapFrom(user => user.account))
                   .ForMember(userDTO => userDTO.PASSWORD, action => action.MapFrom(user => user.password))
                   .ForMember(userDTO => userDTO.AGE, action => action.ResolveUsing<AgeResolver>())
                       ;
        }
    }
}

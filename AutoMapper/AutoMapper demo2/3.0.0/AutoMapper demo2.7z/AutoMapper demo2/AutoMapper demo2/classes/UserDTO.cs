﻿namespace AutoMapper_demo2.classes
{
    public class UserDTO
    {
        public int AGE { get; set; }
        public string USERNAME { get; set; }
        public string ACCOUNT { get; set; }
        public string PASSWORD { get; set; }
    }
}

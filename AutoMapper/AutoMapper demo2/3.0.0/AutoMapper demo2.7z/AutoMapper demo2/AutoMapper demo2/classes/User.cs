﻿using System;

namespace AutoMapper_demo2.classes
{
    public class User
    {
        public DateTime birthdate { get; set; }
        public string username { get; set; }
        public string account { get; set; }
        public string password { get; set; }
    }
}

﻿using AutoMapper_demo2.classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoMapper_demo2.extensions
{
    public static class ExtensionMethods
    {
        public static string GetInfo(this User user)
        {
            string result = $"user.username:'{user.username}'\t" +
                $"user.account:'{user.account}'\t" +
                $"user.password:'{user.password}'\t";
            return result;
        }

        public static string GetInfo(this UserDTO userDTO)
        {
            string result = $"userDTO.USERNAME:'{userDTO.USERNAME}'\t" +
                $"userDTO.account:'{userDTO.ACCOUNT}'\t" +
                $"userDTO.password:'{userDTO.PASSWORD}'\t";
            return result;
        }
    }
}

﻿using AutoMapper_demo2.demo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoMapper_demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            // DemoClass1.test1();
            //DemoClass1.test2();
            //DemoClass1.test3();
            //DemoClass1.test4();
            DemoClass1.test5();
        }
    }
}

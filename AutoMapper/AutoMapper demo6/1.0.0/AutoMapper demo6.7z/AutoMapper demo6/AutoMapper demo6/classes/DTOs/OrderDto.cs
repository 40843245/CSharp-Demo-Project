﻿using AutoMapper;
using AutoMapper_demo6.classes.Entities;

namespace AutoMapper_demo6.classes.DTOs
{
    [AutoMap(typeof(Order))]
    public class OrderDto
    {
        public int Id { get; set; }

        public User OrderPlacer { get; set; }

    }
}

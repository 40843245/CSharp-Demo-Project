﻿namespace AutoMapper_demo6.classes.Entities
{
    public class Order
    {
        public int Id { get; set; }
        public User OrderPlacer { get; set; }
    }
}

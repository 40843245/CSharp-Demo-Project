﻿using AutoMapper;
using AutoMapper_demo6.classes.DTOs;
using AutoMapper_demo6.classes.Entities;
using AutoMapper_demo6.Mapping.Mappers;
using System;
using static AutoMapper_demo6.ExtensionMethods.ExtensionMethods;

namespace AutoMapper_demo6.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            Order order1 = new Order()
            {
                Id = 2,
                OrderPlacer = new User()
                {
                    firstName = "Yazawa",
                    lastName = "Nico"
                }
            };
            IMapper mapper = OrderMappingTable.CreateMappingTable();
            OrderDto orderDto1 =  mapper.Map<Order,OrderDto>(order1);

            Console.WriteLine(orderDto1.GetOrderDtoInfo());
            Console.WriteLine("--------------------------------------------");

            Order order2 = mapper.Map<OrderDto, Order>(orderDto1);

            Console.WriteLine(order2.GetOrderInfo());
            Console.WriteLine("--------------------------------------------");
        }
    }
}

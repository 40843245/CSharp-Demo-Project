﻿using AutoMapper_demo6.classes.DTOs;
using AutoMapper_demo6.classes.Entities;

namespace AutoMapper_demo6.ExtensionMethods
{
    public static class ExtensionMethods
    {
        public static string GetUserInfo(
            this User user
        )
        {
            string message = $"{user.firstName},{user.lastName}";
            return message;
        }

        public static string GetOrderInfo(
            this Order order
        )
        {
            string message = $"order.Id:{order.Id} order.PlaceOwner:{order.OrderPlacer.GetUserInfo()}.";
            return message;
        }

        public static string GetOrderDtoInfo(
            this OrderDto orderDto
        )
        {
            string message = $"orderDto.Id:{orderDto.Id}.";
            return message;
        }
    }
}

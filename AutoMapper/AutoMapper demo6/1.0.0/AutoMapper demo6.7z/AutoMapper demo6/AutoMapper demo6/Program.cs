﻿using System;

namespace AutoMapper_demo6
{
    class Program
    {
        static void Main(string[] args)
        {
            DemoClass.DemoClass1.TestMethod1();

            Console.ReadLine();
        }
    }
}

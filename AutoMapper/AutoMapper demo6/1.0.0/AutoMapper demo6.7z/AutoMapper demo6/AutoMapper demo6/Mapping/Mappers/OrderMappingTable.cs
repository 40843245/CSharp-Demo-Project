﻿using AutoMapper;
using AutoMapper_demo6.classes.DTOs;
using AutoMapper_demo6.classes.Entities;

namespace AutoMapper_demo6.Mapping.Mappers
{
    public class OrderMappingTable
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Order, OrderDto>();
                cfg.CreateMap<OrderDto, Order>();

            });

            var mapper = new Mapper(configuration);

            return mapper;
        }
    }
}

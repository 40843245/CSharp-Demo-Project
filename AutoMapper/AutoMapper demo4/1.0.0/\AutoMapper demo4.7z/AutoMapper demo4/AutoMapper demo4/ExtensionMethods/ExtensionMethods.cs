﻿using AutoMapper_demo4.classes.Beans;
using AutoMapper_demo4.classes.DTOs;

namespace AutoMapper_demo4.ExtensionMethods
{
    public static class ExtensionMethods
    {
        public static string GetCustomerInfo(
            this Customer customer    
        )
        {
            string message = $"customer.Name:{customer.Name}";
            return message;
        }

        public static string GetOrderInfo(
            this Order order
        )
        {
            string message = $"order.Total:{order.Total},\n{order.Customer.GetCustomerInfo()}";
            return message;
        }

        public static string GetOrderDtoInfo(
            this OrderDto orderDto
        )
        {
            string message = $"orderDto.CustomerName:{orderDto.CustomerName}";
            return message;
        }
    }
}

﻿using System;

namespace AutoMapper_demo4
{
    public class Program
    {
        static void Main(string[] args)
        {
            DemoClass.DemoClass1.TestMethod1();

            Console.ReadLine();
        }
    }
}

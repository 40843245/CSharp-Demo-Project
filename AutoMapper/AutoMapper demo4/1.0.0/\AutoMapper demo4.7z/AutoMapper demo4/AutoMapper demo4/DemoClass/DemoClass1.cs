﻿using AutoMapper_demo4.classes.Beans;
using AutoMapper_demo4.classes.DTOs;
using AutoMapper_demo4.Mapping.Mappers;
using System;
using static AutoMapper_demo4.ExtensionMethods.ExtensionMethods;
namespace AutoMapper_demo4.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            var customer = new Customer
            {
                Name = "Bob"
            };

            var order = new Order
            {
                Customer = customer,
                Total = 15.8m
            };

            var mapper = OrderMappingTable.CreateMappingTable();
            
            var orderDto = mapper.Map<Order, OrderDto>(order);
            Console.WriteLine(order.GetOrderInfo());
            Console.WriteLine();
            Console.WriteLine(orderDto.GetOrderDtoInfo());
            Console.WriteLine("-----------------------------------------------");
            

            orderDto.CustomerName = "Joe";

            Console.WriteLine(order.GetOrderInfo());
            Console.WriteLine();
            Console.WriteLine(orderDto.GetOrderDtoInfo());
            Console.WriteLine("-----------------------------------------------");

            mapper.Map(orderDto, order);

            Console.WriteLine(order.GetOrderInfo());
            Console.WriteLine();
            Console.WriteLine(orderDto.GetOrderDtoInfo());
            Console.WriteLine("-----------------------------------------------");
        }
    }
}

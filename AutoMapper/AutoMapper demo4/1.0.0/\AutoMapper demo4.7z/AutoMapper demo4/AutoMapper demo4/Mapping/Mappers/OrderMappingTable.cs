﻿using AutoMapper;
using AutoMapper_demo4.classes.Beans;
using AutoMapper_demo4.classes.DTOs;

namespace AutoMapper_demo4.Mapping.Mappers
{
    public class OrderMappingTable
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg => {
                cfg.CreateMap<Order, OrderDto>()
                   .ReverseMap();
            });

            var mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

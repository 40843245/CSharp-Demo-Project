﻿namespace AutoMapper_demo4.classes.DTOs
{
    public class OrderDto
    {
        public decimal Total { get; set; }
        public string CustomerName { get; set; }
    }
}

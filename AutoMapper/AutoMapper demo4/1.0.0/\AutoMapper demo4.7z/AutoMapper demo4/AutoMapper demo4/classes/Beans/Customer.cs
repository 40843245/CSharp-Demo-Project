﻿namespace AutoMapper_demo4.classes.Beans
{
    public class Customer
    {
        public string Name { get; set; }
    }
}

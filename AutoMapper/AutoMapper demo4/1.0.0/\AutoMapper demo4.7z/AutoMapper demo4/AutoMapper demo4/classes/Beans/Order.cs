﻿namespace AutoMapper_demo4.classes.Beans
{
    public class Order
    {
        public decimal Total { get; set; }
        public Customer Customer { get; set; }
    }
}

﻿using AutoMapper_demo2.classes;

namespace AutoMapper_demo2.extensions
{
    public static class ExtensionMethods
    {
        public static string GetInfo(this User user)
        {
            string result = 
                $"user.username:'{user.username}'\t" +
                $"user.account:'{user.account}'\t" +
                $"user.password:'{user.password}'\t" +
                $"user.birthdate:'{user.birthdate}'\t"
                ;
            return result;
        }

        public static string GetInfo(this UserDTO userDTO)
        {
            string result = 
                $"userDTO.USERNAME:'{userDTO.USERNAME}'\t" +
                $"userDTO.ACCOUNT:'{userDTO.ACCOUNT}'\t" +
                $"userDTO.PASSWORD:'{userDTO.PASSWORD}'\t" +
                $"userDTO.AGE:{userDTO.AGE}\t"
                ;
            return result;
        }
    }
}

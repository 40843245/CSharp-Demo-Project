﻿using AutoMapper;
using AutoMapper_demo2.classes;

namespace AutoMapper_demo2.Mapping.MapperProfiles
{
    public class UserDTOProfile : Profile
    {
        public UserDTOProfile()
        {
            CreateMap<UserDTO, User>()
                   .ForMember(user => user.username, action => action.MapFrom(userDTO => userDTO.USERNAME))
                   .ForMember(user => user.account, action => action.MapFrom(userDTO => userDTO.ACCOUNT))
                   .ForMember(user => user.password, action => action.MapFrom(userDTO => userDTO.PASSWORD))
                   .ForMember(user => user.birthdate, action => action.Ignore())
                   ;
        }
    }
}

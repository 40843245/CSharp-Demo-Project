﻿using AutoMapper;
using AutoMapper_demo2.classes;
using System;

namespace AutoMapper_demo2.Mapping.Resolvers
{
    public class AgeResolver : IValueResolver<User, UserDTO, int>
    {
        #region implement all interfaces
        public int Resolve(User source, UserDTO destination, int destMember, ResolutionContext context)
        {
            DateTime now = DateTime.Now;

            DateTime birthdate = source.birthdate;

            int age = now.Year - birthdate.Year;

            // Check if the birthday has occurred this year
            if (birthdate > now.AddYears(-age))
            {
                age--;
            }

            return age;
        }
        #endregion
    }
}

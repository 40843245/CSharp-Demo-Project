﻿using AutoMapper;
using AutoMapper_demo2.Mapping.MapperProfiles;

namespace AutoMapper_demo2.Mapping.Mappers
{
    public class UserMappers
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg => {
                cfg.AddMaps(
                    new[]
                    {
                        typeof(Mapping.MapperProfiles.UserProfile).Assembly,
                        typeof(Mapping.MapperProfiles.UserDTOProfile).Assembly,
                    }
                );
            });
            var mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

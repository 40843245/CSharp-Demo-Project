﻿using AutoMapper;
using AutoMapper_demo7.classes.Entities;

namespace AutoMapper_demo7.classes.DTOs
{
    [AutoMap(typeof(Question))]
    public class AnswerDto
    {
        public User Answerer { get; set; }

        public string Title { get; set; }

        public string Body { get; set; }
    }
}

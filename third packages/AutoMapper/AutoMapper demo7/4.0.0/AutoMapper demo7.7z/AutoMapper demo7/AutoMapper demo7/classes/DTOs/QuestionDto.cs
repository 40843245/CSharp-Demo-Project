﻿using AutoMapper;
using AutoMapper_demo7.classes.Entities;
using System.Collections.Generic;

namespace AutoMapper_demo7.classes.DTOs
{
    [AutoMap(typeof(Question))]
    public class QuestionDto
    {
        public User Asker { get; set; }

        public string Title { get; set; }

        public string Body { get; set; }

        public List<Answer> Responses { get; set; }

    }
}

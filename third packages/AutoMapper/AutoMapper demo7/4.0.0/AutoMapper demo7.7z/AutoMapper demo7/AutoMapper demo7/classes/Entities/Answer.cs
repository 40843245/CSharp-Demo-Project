﻿namespace AutoMapper_demo7.classes.Entities
{
    public class Answer
    {
        public User Answerer { get; set; }

        public string Title { get; set; }

        public string Body { get; set; }
    }
}

﻿using System.Collections.Generic;

namespace AutoMapper_demo7.classes.Entities
{
    public class Question
    {
        public User Asker { get; set; }

        public string Title { get; set; }

        public string Body { get; set; }

        public List<Answer> Responses { get; set; }
    }
}

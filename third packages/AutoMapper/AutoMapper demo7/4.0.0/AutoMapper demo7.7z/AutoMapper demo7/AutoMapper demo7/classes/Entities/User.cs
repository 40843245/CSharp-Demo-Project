﻿namespace AutoMapper_demo7.classes.Entities
{
    public class User
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
    }
}

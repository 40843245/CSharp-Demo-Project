﻿using AutoMapper;
using AutoMapper_demo7.classes.DTOs;
using AutoMapper_demo7.classes.Entities;
using System;

namespace AutoMapper_demo7.Mapping.Profiles
{
    public class AnswerProfile : Profile
    {
        public AnswerProfile()
        {
            CreateMap<Answer, AnswerDto>();
            // create a value transformer in profile level.
            ValueTransformers.Add<string>(val=> $"Answered at:{DateTime.Now.ToString(@"MM\/dd\/yyyy HH:mm")},{val}");
        }
    }
}

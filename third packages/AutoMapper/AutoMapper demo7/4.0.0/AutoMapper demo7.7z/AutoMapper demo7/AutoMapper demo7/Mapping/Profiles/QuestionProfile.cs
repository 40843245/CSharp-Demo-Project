﻿using AutoMapper;
using AutoMapper_demo7.classes.DTOs;
using AutoMapper_demo7.classes.Entities;

namespace AutoMapper_demo7.Mapping.Profiles
{
    public class QuestionProfile : Profile
    {
        public QuestionProfile()
        {
            CreateMap<Question, QuestionDto>()
                // create a value transformer in map level.
                .AddTransform<string>(val =>"LoveLive School Question."+val)
                ;
        }
    }
}

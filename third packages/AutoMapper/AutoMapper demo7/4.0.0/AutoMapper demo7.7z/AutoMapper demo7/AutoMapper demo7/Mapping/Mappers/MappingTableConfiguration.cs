﻿using AutoMapper;
using AutoMapper_demo7.Mapping.Profiles;

namespace AutoMapper_demo7.Mapping.Mappers
{
    public class MappingTableConfiguration
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg => {
                cfg.AddProfile<QuestionProfile>();
                cfg.AddProfile<AnswerProfile>();

                // Global value transformer for strings
                cfg.ValueTransformers.Add<string>(str => str.Trim());
            });

            IMapper mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

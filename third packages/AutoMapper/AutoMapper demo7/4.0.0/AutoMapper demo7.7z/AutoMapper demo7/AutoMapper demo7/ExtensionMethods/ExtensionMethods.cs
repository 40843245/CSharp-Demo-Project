﻿using AutoMapper_demo7.classes.DTOs;
using AutoMapper_demo7.classes.Entities;
using System.Collections.Generic;

namespace AutoMapper_demo7.ExtensionMethods
{
    public static class ExtensionMethods
    {
        public static string GetUserInfo(
            this User user 
        )
        {
            string message = $"'{user.firstName} {user.lastName}'";
            return message;
        }
        public static string GetQuestionInfo(
            this Question question
        )
        {
            string message = $"{question.Asker.GetUserInfo()} asks a question.\n" +
                $"Title:{question.Title}\n" +
                $"Body:{question.Body}\n"
                ;
            return message;
        }

        public static string GetQuestionDtoInfo(
            this QuestionDto questionDto
        )
        {
            string message = $"{questionDto.Asker.GetUserInfo()} asks a question.\n" +
                $"Title:{questionDto.Title}\n" +
                $"Body:{questionDto.Body}\n"
                ;
            return message;
        }

        public static string GetAnswerInfo(
            this Answer answer
        )
        {
            string message = $"{answer.Answerer.GetUserInfo()} answers a question.\n" +
                $"Title:{answer.Title}\n" +
                $"Body:{answer.Body}\n"
                ;
            return message;
        }

        public static string GetAnswerDtoInfo(
            this AnswerDto answerDto
        )
        {
            string message = $"{answerDto.Answerer.GetUserInfo()} answers a question.\n" +
                $"Title:{answerDto.Title}\n" +
                $"Body:{answerDto.Body}\n"
                ;
            return message;
        }

        public static int GetAnswersCount(
            this Question question
        )
        {
            List<Answer> responses = question.Responses;
            return responses != null ? responses.Count : 0;
        }

        public static int GetAnswersCount(
            this QuestionDto questionDto
        )
        {
            List<Answer> responses = questionDto.Responses;
            return responses != null ? responses.Count : 0;
        }

    }
}

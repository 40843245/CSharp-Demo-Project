﻿using System;

namespace AutoMapper_demo7
{
    class Program
    {
        static void Main(string[] args)
        {
            //DemoClass.DemoClass1.TestMethod1();
            DemoClass.DemoClass1.TestMethod2();

            Console.ReadLine();
        }
    }
}

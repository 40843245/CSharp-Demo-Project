﻿using AutoMapper;
using AutoMapper_demo7.classes.DTOs;
using AutoMapper_demo7.classes.Entities;
using AutoMapper_demo7.Mapping.Mappers;
using System;
using System.Collections.Generic;
using static AutoMapper_demo7.ExtensionMethods.ExtensionMethods;

namespace AutoMapper_demo7.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            Question[] questions = new Question[]
            {
                new Question()
                {
                    Asker = new User()
                    {
                        firstName = "Yazawa",
                        lastName = "Nico"
                    },
                    Title = "Can 'Yazawa Nico' join the LoveLive club?",
                    Body = "I love music and dancing. So I want to join LoveLive club.",
                    Responses = new List<Answer>()
                },
                new Question()
                {
                    Asker = new User()
                    {
                        firstName = "Ayase",
                        lastName = "Eli"
                    },
                    Title = "How to manage the LoveLive club?",
                    Body = " "+"I'm a student council in LoveLive school.\nI'm encountering a very huge difficulty.\nThere are fewer and fewer student want to join in our school.\nHow can I do?" + " ",
                    Responses = new List<Answer>()
                }
            };

            IMapper mapper = MappingTableConfiguration.CreateMappingTable();
            QuestionDto[]  questionDtos = mapper.Map<QuestionDto[]>(questions);

            Console.WriteLine("TestMethod1");
            foreach (var questionDto in questionDtos)
            {
                Console.WriteLine(questionDto.GetQuestionDtoInfo());
            }
            Console.WriteLine("------------------------------------------------------");
        }


        public static void TestMethod2()
        {
            Question[] questions = new Question[]
            {
                new Question()
                {
                    Asker = new User()
                    {
                        firstName = "Yazawa",
                        lastName = "Nico"
                    },
                    Title = "Can 'Yazawa Nico' join the LoveLive club?",
                    Body = "I love music and dancing. So I want to join LoveLive club.",
                    Responses = new List<Answer>()
                },
                new Question()
                {
                    Asker = new User()
                    {
                        firstName = "Ayase",
                        lastName = "Eli"
                    },
                    Title = "How to manage the LoveLive club?",
                    Body = " "+"I'm a student council in LoveLive school.\nI'm encountering a very huge difficulty.\nThere are fewer and fewer student want to join in our school.\nHow can I do?" + " ",
                    Responses = new List<Answer>()
                }
            };

            Answer[] answers = new Answer[]
            {
                new Answer()
                {
                    Answerer = new User()
                    {
                        firstName = "Ayase",
                        lastName = "Eli"
                    },
                    Title = "Brief answer",
                    Body = "Yes, you can join the LoveLive club.",
                },
                new Answer()
                {
                    Answerer = new User()
                    {
                        firstName = "Ayase",
                        lastName = "Eli"
                    },
                    Title = "Detailed answer",
                    Body = " "+"Get first rank on the following dancing contest."+" ",
                }   
            };

            questions[0].Responses.Add(answers[0]);
            questions[1].Responses.Add(answers[1]);

            IMapper mapper = MappingTableConfiguration.CreateMappingTable();
            QuestionDto[] questionDtos = mapper.Map<QuestionDto[]>(questions);
            AnswerDto[] answerDtos = mapper.Map<AnswerDto[]>(answers);

            Console.WriteLine("TestMethod2");
            foreach (var questionDto in questionDtos)
            {
                Console.WriteLine(questionDto.GetQuestionDtoInfo());
            }
            Console.WriteLine("------------------------------------------------------");
            foreach (var answerDto in answerDtos)
            {
                Console.WriteLine(answerDto.GetAnswerDtoInfo());
            }
            Console.WriteLine("------------------------------------------------------");

        }
    }
}

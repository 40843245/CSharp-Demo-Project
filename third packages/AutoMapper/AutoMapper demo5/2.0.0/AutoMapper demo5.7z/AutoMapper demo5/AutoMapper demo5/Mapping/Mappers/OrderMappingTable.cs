﻿using AutoMapper;
using AutoMapper_demo5.classes.DTOs;
using AutoMapper_demo5.classes.Entities;

namespace AutoMapper_demo5.Mapping.Mappers
{
    public class OrderMappingTable
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg => {
                cfg.CreateMap<Order, OrderDto>()
                  .ForMember(o => o.Id, m => m.MapFrom(s => s.OrderId));
                cfg.CreateMap<OnlineOrder, OnlineOrderDto>()
                  .IncludeBase<Order, OrderDto>();
                cfg.CreateMap<MailOrder, MailOrderDto>()
                  .IncludeBase<Order, OrderDto>();
            });
            var mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

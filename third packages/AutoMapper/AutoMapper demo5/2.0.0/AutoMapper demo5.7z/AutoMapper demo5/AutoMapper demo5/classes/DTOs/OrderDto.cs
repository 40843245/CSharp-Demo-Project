﻿namespace AutoMapper_demo5.classes.DTOs
{
    public class OrderDto 
    { 
        public int Id { get; set; }
    }
    public class OnlineOrderDto : OrderDto { }
    public class MailOrderDto : OrderDto { }
}

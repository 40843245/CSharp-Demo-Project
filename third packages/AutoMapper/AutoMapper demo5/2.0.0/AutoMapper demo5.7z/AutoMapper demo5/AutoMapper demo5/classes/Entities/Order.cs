﻿namespace AutoMapper_demo5.classes.Entities
{
    public class Order
    {
        public int OrderId {get;set;} 
    }
    public class OnlineOrder : Order { }
    public class MailOrder : Order { }
}

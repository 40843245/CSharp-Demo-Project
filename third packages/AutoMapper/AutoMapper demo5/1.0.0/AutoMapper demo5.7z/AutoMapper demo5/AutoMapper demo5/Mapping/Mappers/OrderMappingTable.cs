﻿using AutoMapper;
using AutoMapper_demo5.classes.DTOs;
using AutoMapper_demo5.classes.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoMapper_demo5.Mapping.Mappers
{
    public class OrderMappingTable
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Order, OrderDto>()
                    .Include<OnlineOrder, OnlineOrderDto>()
                    .Include<MailOrder, MailOrderDto>();
                cfg.CreateMap<OnlineOrder, OnlineOrderDto>();
                cfg.CreateMap<MailOrder, MailOrderDto>();
            });
            var mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

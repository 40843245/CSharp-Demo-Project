﻿using AutoMapper_demo5.classes.DTOs;
using AutoMapper_demo5.classes.Entities;
using AutoMapper_demo5.Mapping.Mappers;
using Xunit;

namespace AutoMapper_demo5.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            var onlineOrder = new OnlineOrder();
            var mapper = OrderMappingTable.CreateMappingTable();
            var mapped = mapper.Map(onlineOrder, onlineOrder.GetType(), typeof(OrderDto));
            Assert.IsType<OnlineOrderDto>(mapped);
        }
    }
}

﻿namespace AutoMapper_demo5.classes.DTOs
{
    public class OrderDto { }
    public class OnlineOrderDto : OrderDto { }
    public class MailOrderDto : OrderDto { }
}

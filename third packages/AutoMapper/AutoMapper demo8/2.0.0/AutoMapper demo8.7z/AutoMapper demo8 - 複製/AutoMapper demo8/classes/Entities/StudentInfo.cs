﻿namespace AutoMapper_demo8.classes.Entities
{
    public class StudentInfo
    {
        public User Student { get; set; }
        public int Score { get; set; }
    }
}

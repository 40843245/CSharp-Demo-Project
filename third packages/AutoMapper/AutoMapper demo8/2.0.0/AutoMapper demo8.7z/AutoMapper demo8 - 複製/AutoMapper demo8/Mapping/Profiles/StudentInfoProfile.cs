﻿using AutoMapper;
using AutoMapper_demo8.classes.DTOs;
using AutoMapper_demo8.classes.Entities;
using AutoMapper_demo8.Utilities.NumberHandler;

namespace AutoMapper_demo8.Mapping.Profiles
{
    public class StudentInfoProfile: Profile
    {
        public StudentInfoProfile()
        {
            CreateMap<StudentInfo, StudentInfoDto>()
                .BeforeMap((studentInfo, studentInfoDto) =>
                    {
                        GeometricAdjustificationHandler geometricAdjustificationHandler = new GeometricAdjustificationHandler(100, 0);
                        studentInfo.Score = geometricAdjustificationHandler.Adjust(studentInfo, 2);
                    }
                )
                /// to make every student passes the test by adjusting the score to 60 for those students who fails test (i.e. score is under 60) 
                .AfterMap((studentInfo, studentInfoDto) =>
                    {
                        int oldScore = studentInfoDto.Score;
                        int newScore = oldScore >= 60 ? oldScore : 60;
                        studentInfoDto.Score = newScore;
                    }
                )
                ;
        }
    }
}

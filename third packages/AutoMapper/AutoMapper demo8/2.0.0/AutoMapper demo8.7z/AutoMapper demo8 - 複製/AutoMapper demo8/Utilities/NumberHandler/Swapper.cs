﻿namespace AutoMapper_demo8.Utilities.NumberHandler
{
    public static class Swapper
    {
        #region Swap two numbers
        public static void TryToSwap(
            ref int upperBound,
            ref int lowerBound
        )
        {
            if (lowerBound > upperBound)
            {
                Swapper.Swap(ref upperBound, ref lowerBound);
            }
        }

        public static void Swap(
            ref int source,
            ref int dest
        )
        {
            int temp = source;
            source = dest;
            dest = temp;
        }
        #endregion
    }
}

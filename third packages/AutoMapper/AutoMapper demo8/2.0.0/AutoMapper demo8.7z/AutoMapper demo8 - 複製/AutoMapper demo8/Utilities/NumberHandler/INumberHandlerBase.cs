﻿using AutoMapper_demo8.classes.Entities;

namespace AutoMapper_demo8.Utilities.NumberHandler
{
    public interface INumberHandlerBase
    {
        int Adjust(StudentInfo studentInfo, int adjustmentFactor);
    }
}

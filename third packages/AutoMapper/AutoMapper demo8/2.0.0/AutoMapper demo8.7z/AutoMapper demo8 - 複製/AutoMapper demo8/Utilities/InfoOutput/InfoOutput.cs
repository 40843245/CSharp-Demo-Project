﻿using AutoMapper_demo8.classes.DTOs;
using AutoMapper_demo8.classes.Entities;
using System;
using static AutoMapper_demo8.Extensions.ExtensionMethods.ExtensionMethods;

namespace AutoMapper_demo8.Utilities.InfoOutput
{
    public static class InfoOutput
    {
        public static void PrintStudentInfos(StudentInfo[] studentInfos)
        {
            for (int i=0;i<studentInfos.Length;i++)
            {
                StudentInfo studentInfo = studentInfos[i];
                Console.WriteLine(studentInfo.GetStudentInfo());
            }
        }

        public static void PrintStudentInfoDtos(StudentInfoDto[] studentInfoDtos)
        {
            for (int i = 0; i < studentInfoDtos.Length; i++)
            {
                StudentInfoDto studentInfoDto = studentInfoDtos[i];
                Console.WriteLine(studentInfoDto.GetStudentDtoInfo());
            }
        }
    }
}

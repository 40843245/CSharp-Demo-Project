﻿using AutoMapper;
using AutoMapper_demo8.Mapping.Profiles;

namespace AutoMapper_demo8.Mapping.Mappers
{
    public class MappingTableConfiguration
    {
        public static IMapper CreateMappingTable()
        {
            var configuration = new MapperConfiguration(cfg =>{
                cfg.AddProfile<StudentInfoProfile>();
            });

            var mapper = configuration.CreateMapper();
            return mapper;
        }
    }
}

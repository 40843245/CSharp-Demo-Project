﻿using AutoMapper;
using AutoMapper_demo8.classes.DTOs;
using AutoMapper_demo8.classes.Entities;
using AutoMapper_demo8.Mapping.Mappers;
using AutoMapper_demo8.Utilities.InfoOutput;
using System;

namespace AutoMapper_demo8.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            StudentInfo[] studentInfos = new StudentInfo[]
            {
                new StudentInfo()
                {
                    Student = new User()
                    {
                        firstName = "Yazawa",
                        lastName = "Nico"
                    },
                    Score = 30
                },
                new StudentInfo()
                {
                    Student = new User()
                    {
                        firstName = "Ayase",
                        lastName = "Eli"
                    },
                    Score = 60
                },
                new StudentInfo()
                {
                    Student = new User()
                    {
                        firstName = "Minami",
                        lastName = "Kotori"
                    },
                    Score = 20
                },
            };


            Console.WriteLine("Before adjusting the score,");
            Console.WriteLine();
            Console.WriteLine("StudentInfos:");
            InfoOutput.PrintStudentInfos(studentInfos);
            Console.WriteLine("--------------------------------------------------");

            IMapper mapper = MappingTableConfiguration.CreateMappingTable();
            StudentInfoDto[] studentInfoDtos = mapper.Map<StudentInfo[], StudentInfoDto[]>(studentInfos);

            Console.WriteLine("After adjusting the score,");
            Console.WriteLine();
            Console.WriteLine("StudentInfos:");
            InfoOutput.PrintStudentInfos(studentInfos);
            Console.WriteLine("StudentInfoDtos:");
            InfoOutput.PrintStudentInfoDtos(studentInfoDtos);
            Console.WriteLine("--------------------------------------------------");
        }
    }
}

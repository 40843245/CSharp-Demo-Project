﻿using AutoMapper_demo8.classes.DTOs;
using AutoMapper_demo8.classes.Entities;

namespace AutoMapper_demo8.Extensions.ExtensionMethods
{
    public static class ExtensionMethods
    {
        public static string GetUserInfo(
            this User user    
        )
        {
            string message = $"'{user.firstName} {user.lastName}'";
            return message;
        }
        public static string GetStudentInfo(
            this StudentInfo studentInfo
        )
        {
            string message = $"The student:{studentInfo.Student.GetUserInfo()} gets {studentInfo.Score} score.";
            return message;
        }

        public static string GetStudentDtoInfo(
            this StudentInfoDto studentInfo
        )
        {
            string message = $"The student:{studentInfo.Student.GetUserInfo()} gets {studentInfo.Score} score.";
            return message;
        }
    }
}

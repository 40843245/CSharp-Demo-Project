﻿using AutoMapper_demo8.classes.Entities;
using System;

namespace AutoMapper_demo8.Utilities.NumberHandler
{
    public class GeometricAdjustificationHandler: INumberHandlerBase
    {
        private int _upperLimit;
        private int _lowerLimit;

        public GeometricAdjustificationHandler(
            int upperLimit,
            int lowerLimit
        )
        {
            Swapper.TryToSwap(ref upperLimit, ref lowerLimit);
            this._upperLimit = upperLimit;
            this._lowerLimit = lowerLimit;
        }
        public int Adjust(StudentInfo studentInfo, int adjustmentFactor)
        {
            int newScore = studentInfo.Score * adjustmentFactor;
            newScore = Clamper.Clamp(newScore,this._lowerLimit,this._upperLimit);
            return newScore;
        }
    }
}

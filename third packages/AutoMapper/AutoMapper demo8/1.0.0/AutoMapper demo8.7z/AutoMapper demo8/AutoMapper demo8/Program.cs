﻿using System;

namespace AutoMapper_demo8
{
    class Program
    {
        static void Main(string[] args)
        {
            DemoClass.DemoClass1.TestMethod1();

            Console.ReadLine();
        }
    }
}

﻿using AutoMapper;
using AutoMapper_demo2.classes;
using AutoMapper_demo2.extensions;
using AutoMapper_demo2.Mapping.Profiles;
using System;

namespace AutoMapper_demo2.demo
{
    public static class DemoClass1
    {
        /// <summary>
        /// static method that illustrate it's troublesome 
        /// to convert from a class to another class without `AutoMapper` package. 
        /// </summary>
        public static void test1()
        {
            User user1 = new User();
            user1.username = "Jay";
            user1.account = "jay30@gmail.com";
            user1.password = "password";

            UserDTO userDTO1 = new UserDTO();
            userDTO1.USERNAME = user1.username;
            userDTO1.ACCOUNT = user1.account;
            userDTO1.PASSWORD = user1.password;

            PrintInfo(user1, userDTO1);
        }

        public static void test4()
        {
            User user1 = new User();
            user1.username = "Jay";
            user1.account = "jay30@gmail.com";
            user1.password = "password";

            IMapper mapper = UserMapper.CrreateMappingTable();
            UserDTO userDTO1 = mapper.Map<User, UserDTO>(user1);
            PrintInfo(user1, userDTO1);
        }
        public static void test5()
        {
            UserDTO userDTO1 = new UserDTO();
            userDTO1.USERNAME = "Jay";
            userDTO1.ACCOUNT = "jay30@gmail.com";
            userDTO1.PASSWORD = "password";

            IMapper mapper = UserMapper.CrreateMappingTable();
            User user1 = mapper.Map<UserDTO, User>(userDTO1);
            PrintInfo(user1, userDTO1);
        }

        public static void test6()
        {
            User user1 = new User();
            user1.birthdate = new DateTime(2001, 1, 1);
            user1.username = "testuser";
            user1.account = "testaccount";
            user1.password = "testpassword";
            UserDTO userDTO1 = new UserDTO();
            userDTO1.AGE = 2;
            IMapper mapper = UserMapper.CrreateMappingTable();
            userDTO1 = mapper.Map<User, UserDTO>(user1);
            PrintInfo(user1, userDTO1);
        }


        private static void PrintInfo(User user, UserDTO userDTO)
        {
            Console.WriteLine(user.GetInfo());
            Console.WriteLine(userDTO.GetInfo());
            Console.ReadLine();
        }
    }
}

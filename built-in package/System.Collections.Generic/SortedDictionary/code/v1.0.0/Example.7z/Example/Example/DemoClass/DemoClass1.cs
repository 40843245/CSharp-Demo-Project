﻿using Example.Extensions.ExtensionMethods.DictionaryExtensionMethods;
using Example.Extensions.ExtensionMethods.SortedDictionaryExtensionMethods;
using Example.Utilities.Comparer;
using System.Reflection;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrate the constructor of `SortedDictionary<TKey,TValue>` class.
        /// </summary>
        public static void TestMethod1()
        {
            Dictionary<string,string> dictionary = new Dictionary<string,string>();
            SortedDictionary<string,string> sortedDictionary = new SortedDictionary<string,string>();
            SortedDictionary<string,string> otherSortedDictionary = new SortedDictionary<string,string>(dictionary);
            SortedDictionary<string , string> sortedDictionaryWithIComparer = new SortedDictionary<string , string>(new NumericStringComparer()); 
            SortedDictionary<string , string> otherSortedDictionaryWithIComparer = new SortedDictionary<string , string>(dictionary,new NumericStringComparer()); 
        }

        /// <summary>
        /// prove that
        /// 
        /// + `SortedDictionary<TKey,TValue>` will sort the key
        /// 
        /// while `Dictionary<TKey,TValue>` will NOT.
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Dictionary<int , string> dictionary = new Dictionary<int , string>();
            SortedDictionary<int , string> sortedDictionary = new SortedDictionary<int , string>();

            dictionary.Add(2 , "Eli");
            dictionary.Add(1 , "Nico");
            dictionary.Add(3 , "Kotori");
            dictionary.Add(5 , "Rin");
            dictionary.Add(4 , "Umi");

            Console.WriteLine(dictionary.GetInfo());

            sortedDictionary.Add(2,"Eli");
            sortedDictionary.Add(1,"Nico");
            sortedDictionary.Add(3 , "Kotori");
            sortedDictionary.Add(5 , "Rin");
            sortedDictionary.Add(4 , "Umi");

            Console.WriteLine(sortedDictionary.GetInfo());

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + define and use `IComparer<TKey>` to customize the sort of keys
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            SortedDictionary<string , string> sortedDictionaryWithIComparer = new SortedDictionary<string , string>(new NumericStringComparer());

            sortedDictionaryWithIComparer.Add("2" , "Eli");
            sortedDictionaryWithIComparer.Add("1" , "Nico");
            sortedDictionaryWithIComparer.Add("3" , "Kotori");
            sortedDictionaryWithIComparer.Add("5" , "Rin");
            sortedDictionaryWithIComparer.Add("4" , "Umi");

            Console.WriteLine(sortedDictionaryWithIComparer.GetInfo());

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

﻿using System.Text;

namespace Example.Extensions.ExtensionMethods.SortedDictionaryExtensionMethods
{
    public static class SortedDictionaryExtensionMethods
    {
        public static string GetInfo<TKey,TValue>(
            this SortedDictionary<TKey,TValue> sortedDictionary    
        )
        where TKey: notnull
        {
            StringBuilder stringBuilder = new StringBuilder();

            if(sortedDictionary == null)
            {
                stringBuilder.AppendLine("The sorted dictionary is null");
                return stringBuilder.ToString();
            }

            if(sortedDictionary.Count <= 0)
            {
                stringBuilder.AppendLine("There are no elements in the sorted dictionary");
                return stringBuilder.ToString();
            }

            stringBuilder.AppendFormat("There are {0} elements in the sorted dictionary\n" , sortedDictionary.Count);
            foreach( var entry in sortedDictionary)
            {
                string key = entry.Key.ToString();
                string value = entry.Value?.ToString();
                value = ( value != null ? $"`{value}`" : "null");
                stringBuilder.AppendFormat("The key `{0}` has {1}.\n", key, value);
            }
            return stringBuilder.ToString();
        }
    }
}

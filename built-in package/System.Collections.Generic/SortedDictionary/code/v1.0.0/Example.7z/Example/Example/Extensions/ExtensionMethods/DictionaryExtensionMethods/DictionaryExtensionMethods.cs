﻿using System.Text;

namespace Example.Extensions.ExtensionMethods.DictionaryExtensionMethods
{
    public static class DictionaryExtensionMethods
    {
        public static string GetInfo<TKey,TValue>(
            this Dictionary<TKey,TValue> dictionary    
        )
        where TKey: notnull
        {
            StringBuilder stringBuilder = new StringBuilder();

            if(dictionary == null)
            {
                stringBuilder.AppendLine("The dictionary is null");
                return stringBuilder.ToString();
            }

            if(dictionary.Count <= 0)
            {
                stringBuilder.AppendLine("There are no elements in the dictionary");
                return stringBuilder.ToString();
            }

            stringBuilder.AppendFormat("There are {0} elements in the dictionary\n",dictionary.Count);
            foreach( var entry in dictionary)
            {
                string key = entry.Key.ToString();
                string value = entry.Value?.ToString();
                value = ( value != null ? $"`{value}`" : "null");
                stringBuilder.AppendFormat("The key `{0}` has {1}.\n", key, value);
            }
            return stringBuilder.ToString();
        }
    }
}

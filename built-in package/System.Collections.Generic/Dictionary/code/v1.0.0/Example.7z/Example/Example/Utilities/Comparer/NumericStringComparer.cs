﻿using System;
using System.Collections.Generic;

namespace Example.Utilities.Comparer
{
    /// <summary>
    /// compare two strings with numeric order.
    /// </summary>
    public class NumericStringComparer : IComparer<string>
    {
        public int Compare(string x , string y)
        {
            // Handle nulls first: null is considered less than any non-null string
            if(x == null && y == null)
            {
                return 0;
            }
            if(x == null)
            {
                return -1;
            }
            if(y == null)
            {
                return 1;
            }

            // Try to parse both strings as integers
            if(int.TryParse(x , out int numX) && int.TryParse(y , out int numY))
            {
                return numX.CompareTo(numY); // Compare as integers
            }

            // If one or both are not integers, try to parse as doubles (for floats/decimals)
            if(double.TryParse(x , out double dblX) && double.TryParse(y , out double dblY))
            {
                return dblX.CompareTo(dblY); // Compare as doubles
            }

            // Fallback: If neither can be parsed as a number, use standard string comparison.
            // StringComparison.Ordinal is generally fastest and good for culture-invariant comparisons.
            return String.Compare(x , y , StringComparison.Ordinal);
        }
    }
}
﻿using Example.Extensions.ExtensionMethods;
using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Utilities.Comparer;
using System.Reflection;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrate the constructor of `Dictionary<TKey,TValue>` class.
        /// </summary>
        public static void TestMethod1()
        {
            Dictionary<string , string> dictionary = new Dictionary<string , string>();
            Dictionary<string , string> otherDictionary = new Dictionary<string , string>(dictionary);
            Dictionary<string , string> dictionaryWithIEqualityComparer = new Dictionary<string , string>(new NumericStringEqualityComparer());
            Dictionary<string , string> otherDictionaryWithIEqualityComparer = new Dictionary<string , string>(dictionary , new NumericStringEqualityComparer());
            Dictionary<string , string> dictionaryWithCapacity = new Dictionary<string , string>(4);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + iterate all entries (`KeyValuePair<TKey,TValue>` type) in a dictionary. 
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            Dictionary<string , string> dictionary = new Dictionary<string , string>();
            Dictionary<string , string> otherDictionary = new Dictionary<string , string>(dictionary);

            otherDictionary.Add("Yazawa" , "Nico");

            int counter = 1;

            ///* ---- Example 1 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.Write(dictionary.GetInfo());
            counter++;

            ///* ---- Example 2 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.Write(otherDictionary.GetInfo());
            counter++;

            Console.WriteLine("End {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + get `Keys` and `Values` in a dictionary.
        /// 
        /// + also prove that the `Keys` and `Values` is reflected to dictionary.
        /// 
        /// That is, even one store `dictionary.Keys` to a variable, 
        /// 
        /// after `dictionary` changes, the variable will also changed.
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string formattingString = "{0} {1}\n";
            List<string> textList = new List<string>();
            string text;

            Dictionary<string , string> dictionary = new Dictionary<string , string>();
            dictionary.Add("Yazawa" , "Nico");
            dictionary.Add("Ayase" , "Eli");
            dictionary.Add("Minami" , "Kotori");

            Dictionary<string , string>.KeyCollection keys = dictionary.Keys;
            Dictionary<string , string>.ValueCollection values = dictionary.Values;

            textList = keys.Apply(
                key => string.Format(formattingString , "First Name:" , key.ToString())
            );
            text = string.Join("" , textList);
            Console.WriteLine(text);

            textList = values.Apply(
                value => string.Format(formattingString , "Last Name:" , value.ToString())
            );
            text = string.Join("" , textList);
            Console.WriteLine(text);

            dictionary.Add("Sonoda" , "Umi");

            Console.WriteLine("After adding (\"Sonoda\" \"Umi\") to dictionary,");

            textList = keys.Apply(
                key => string.Format(formattingString , "First Name:" , key.ToString())
            );
            text = string.Join("" , textList);
            Console.WriteLine(text);

            textList = values.Apply(
                value => string.Format(formattingString , "Last Name:" , value.ToString())
            );
            text = string.Join("" , textList);
            Console.WriteLine(text);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate some commonly used operation in `Dictionary<TKey,TValue>` class.
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string key = string.Empty;
            string value;
            bool isValueExist = false;

            Dictionary<string , string> dictionary = new Dictionary<string , string>();
            dictionary.Add("Yazawa" , "Nico");

            Dictionary<string , string>.KeyCollection keys = dictionary.Keys;
            Dictionary<string , string>.ValueCollection values = dictionary.Values;

            Console.WriteLine(dictionary.GetInfo());

            dictionary.Add("Ayase" , "Eli");

            Console.WriteLine("After adding (\"Ayase\" \"Eli\") to dictionary,");

            Console.WriteLine(dictionary.GetInfo());

            dictionary.TryAdd("Yazawa" , "Nico");

            Console.WriteLine("After try to add (\"Yazawa\" \"Nico\") to dictionary,");

            Console.WriteLine(dictionary.GetInfo());

            dictionary.Remove("Ayase");

            Console.WriteLine("After removing (\"Ayase\" key) from dictionary,");

            Console.WriteLine(dictionary.GetInfo());

            key = "Yazawa";
            isValueExist = dictionary.TryGetValue(key , out value);
            if(isValueExist)
            {
                Console.WriteLine("The key `{0}` has value `{1}`" , key , value);
            }
            else
            {
                Console.WriteLine("The key `{0}` does NOT exist" , key);
            }

            key = "Ayase";
            isValueExist = dictionary.TryGetValue(key , out value);
            if(isValueExist)
            {
                Console.WriteLine("The key `{0}` has value `{1}`" , key , value);
            }
            else
            {
                Console.WriteLine("The key `{0}` does NOT exist" , key);
            }

            dictionary.Clear();

            Console.WriteLine("After clearing all key-value pairs of dictionary,");

            key = "Yazawa";
            isValueExist = dictionary.TryGetValue(key , out value);
            if(isValueExist)
            {
                Console.WriteLine("The key `{0}` has value `{1}`" , key , value);
            }
            else
            {
                Console.WriteLine("The key `{0}` does NOT exist" , key);
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + check the dictionary contains specified key
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string key;

            Dictionary<string , string> dictionary = new Dictionary<string , string>();

            dictionary.Add("Yazawa" , "Nico");
            dictionary.Add("Ayase" , "Eli");
            dictionary.Add("Minami" , "Kotori");

            key = "Yazawa";
            if(dictionary.ContainsKey(key))
            {
                Console.WriteLine("The {0} key exists in the dictionary" , key);
            }
            else
            {
                Console.WriteLine("The {0} key deos NOT exist in the dictionary" , key);
            }

            key = "Ai";
            if(dictionary.ContainsKey(key))
            {
                Console.WriteLine("The {0} key exists in the dictionary" , key);
            }
            else
            {
                Console.WriteLine("The {0} key deos NOT exist in the dictionary" , key);
            }

            Console.WriteLine("End {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + check the dictionary contains specified value
        /// </summary>
        public static void TestMethod6()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string value;

            Dictionary<string , string> dictionary = new Dictionary<string , string>();

            dictionary.Add("Yazawa" , "Nico");
            dictionary.Add("Ayase" , "Eli");
            dictionary.Add("Minami" , "Kotori");

            value = "Nico";
            if(dictionary.ContainsValue(value))
            {
                Console.WriteLine("The {0} value exists in the dictionary" , value);
            }
            else
            {
                Console.WriteLine("The {0} value deos NOT exist in the dictionary" , value);
            }

            value = "Ai";
            if(dictionary.ContainsValue(value))
            {
                Console.WriteLine("The {0} value exists in the dictionary" , value);
            }
            else
            {
                Console.WriteLine("The {0} value deos NOT exist in the dictionary" , value);
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + count the number of entries of dictionary.
        /// </summary>
        public static void TestMethod7()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Dictionary<string , string> dictionaryWithCapacity = new Dictionary<string , string>(4);

            dictionaryWithCapacity.Add("Yazawa" , "Nico");
            dictionaryWithCapacity.Add("Ayase" , "Eli");
            dictionaryWithCapacity.Add("Minami" , "Kotori");

            Console.WriteLine("Current count:{0}" , dictionaryWithCapacity.Count);

            dictionaryWithCapacity.Add("Sonoda" , "Umi");

            Console.WriteLine("Current count:{0}" , dictionaryWithCapacity.Count);

            dictionaryWithCapacity.Add("Hoshizora" , "Rin");

            Console.WriteLine("Current count:{0}" , dictionaryWithCapacity.Count);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + manage capacity of dictionary.
        /// </summary>
        public static void TestMethod8()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            int ensuredCapacity;
            /// instaniate a dictionary with intial capacity as 3
            Dictionary<string , string> dictionaryWithCapacity = new Dictionary<string , string>(3);

            dictionaryWithCapacity.Add("Yazawa" , "Nico");
            dictionaryWithCapacity.Add("Ayase" , "Eli");
            dictionaryWithCapacity.Add("Minami" , "Kotori");

            ensuredCapacity = dictionaryWithCapacity.EnsureCapacity(5);

            Console.WriteLine("The capacity is set to be a number at least {0}" , ensuredCapacity);

            dictionaryWithCapacity.TrimExcess();

            dictionaryWithCapacity.Add("Sonoda" , "Umi");
            dictionaryWithCapacity.Add("Hoshizora" , "Rin");

            /// trim capacity to number of entries of `dictionaryWithCapacity`.
            /// ensure no more capacities are unused.
            dictionaryWithCapacity.TrimExcess(dictionaryWithCapacity.Count);

            dictionaryWithCapacity.Add("Nishikino" , "Maki");

            ensuredCapacity = dictionaryWithCapacity.EnsureCapacity(2);

            Console.WriteLine("The capacity is set to be a number at least {0}" , ensuredCapacity);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + get current equality comparer (return value is type of `IEqualityComparer<T>` or its dervied class)
        /// </summary>
        /// <remarks>
        /// If no equality comparer is specified, it will use default comparer --[EqualityComparer<T>.Default](https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.equalitycomparer-1.default?view=net-8.0)
        /// </remarks>
        public static void TestMethod9()
        {

            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            Dictionary<string , string> dictionary = new Dictionary<string , string>();
            Dictionary<int , string> otherDictionary = new Dictionary<int , string>();
            Dictionary<string , string> dictionaryWithIEqualityComparer = new Dictionary<string , string>(new NumericStringEqualityComparer());
            Dictionary<string , int> otherDictionaryWithIEqualityComparer = new Dictionary<string , int>(new NumericStringEqualityComparer());

            int counter = 1;

            ///* ---- Example 1 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.WriteLine("Equality comparer that currently used of instance named `dictionary` :{0}" , dictionary.Comparer);
            counter++;

            ///* ---- Example 2 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.WriteLine("Equality comparer that currently used of instance named  `otherDictionary`:{0}" , otherDictionary.Comparer);
            counter++;

            ///* ---- Example 3 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.WriteLine("Equality comparer that currently used of instance named `dictionaryWithIEqualityComparer` :{0}" , dictionaryWithIEqualityComparer.Comparer);
            counter++;

            ///* ---- Example 4 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.WriteLine("Equality comparer that currently used of instance named `otherDictionaryWithIEqualityComparer` :{0}" , otherDictionaryWithIEqualityComparer.Comparer);
            counter++;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate 
        /// 
        /// + the default behaviour of default equality comparer (`EqualityComparer<T>.Default`).
        /// 
        /// + how to customize the equality comparer (to compare two keys are same)
        /// 
        /// through defining a class that implements `IEqualityComparer<T>` and implements its all method.  
        /// </summary>
        public static void TestMethod10()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Dictionary<string , string> dictionary = new Dictionary<string , string>();
            Dictionary<string , string> dictionaryWithIEqualityComparer = new Dictionary<string , string>(new NumericStringEqualityComparer());

            string keyString;

            bool isKeyExist = false;

            int counter = 1;

            ///* ---- Example 1 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.WriteLine("///* ---- About operation of `dictionary` ---- *///");

            keyString = "-2";
            isKeyExist = dictionary.TryAdd(keyString , "-5");
            if(isKeyExist) 
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully",keyString,keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "2abc";
            isKeyExist =  dictionary.TryAdd(keyString , "5abc");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            Console.WriteLine(dictionary.GetInfo());

            counter++;

            ///* ---- Example 2 ---- *///
            Console.WriteLine("///* ---- Example {0} ---- *///" , counter);
            Console.WriteLine("///* ---- About operation of `dictionaryWithIEqualityComparer` ---- *///");

            keyString = "2";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "2";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "2abc";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "2.0";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "2.0abc";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "2.0abc";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "0";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "0.0";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "-0";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "-0cb23";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "0.bc";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            keyString = "0..1abc";
            isKeyExist = dictionaryWithIEqualityComparer.TryAdd(keyString , "5");
            if(isKeyExist)
            {
                Console.WriteLine("The key `{0}` with type `{1}` does NOT exist and adding to dictionary successfully" , keyString , keyString.GetType());
            }
            else
            {
                Console.WriteLine("The key `{0}` with type `{1}` does exists and thus cause to add to dictionary with failure" , keyString , keyString.GetType());
            }

            Console.WriteLine(dictionaryWithIEqualityComparer.GetInfo());

            counter++;
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

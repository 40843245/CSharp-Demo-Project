﻿// See https://aka.ms/new-console-template for more information

using Example.DemoClass;

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod1();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod2();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod3();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod4();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod5();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod6();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod7();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod8();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

//Console.WriteLine("---------------------------------");
//DemoClass1.TestMethod9();
//Console.ReadLine();
//Console.WriteLine("---------------------------------");

Console.WriteLine("---------------------------------");
DemoClass1.TestMethod10();
Console.ReadLine();
Console.WriteLine("---------------------------------");


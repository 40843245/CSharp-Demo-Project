﻿using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace Example.Utilities.Comparer
{
    public class NumericStringEqualityComparer : IEqualityComparer<string>
    {

        // Helper method to extract the numeric prefix from a string
        // Returns true if a numeric part is found, and outputs the double value.
        // Returns false otherwise.
        private bool TryGetNumericPrefix(string? s , out double numericValue)
        {
            numericValue = 0.0;
            if(string.IsNullOrEmpty(s))
            {
                return false;
            }

            // Find the end of the numeric part
            int i = 0;
            // Handle optional leading sign
            if(s.Length > 0 && (s [ 0 ] == '-' || s [ 0 ] == '+'))
            {
                i++;
            }

            // Scan for digits and a single decimal point
            bool hasDecimal = false;
            while(i < s.Length)
            {
                if(char.IsDigit(s [ i ]))
                {
                    i++;
                }
                else if(s [ i ] == '.' && !hasDecimal)
                {
                    hasDecimal = true;
                    i++;
                }
                else
                {
                    break; // Non-numeric character found
                }
            }

            string numericPart = s.Substring(0 , i);

            // Use invariant culture for parsing to ensure consistent results
            if(double.TryParse(numericPart , NumberStyles.Float , CultureInfo.InvariantCulture , out numericValue))
            {
                return true;
            }

            return false;
        }

        public bool Equals(string? x , string? y)
        {
            if(ReferenceEquals(x , y)) return true; // Both null or same instance
            if(x == null || y == null) return false; // One is null, the other isn't

            // Try to extract numeric prefix from both
            bool xHasNumeric = TryGetNumericPrefix(x , out double numX);
            bool yHasNumeric = TryGetNumericPrefix(y , out double numY);

            if(xHasNumeric && yHasNumeric)
            {
                // Both have numeric prefixes, compare them as doubles
                return numX.Equals(numY);
            }
            else if(!xHasNumeric && !yHasNumeric)
            {
                // Neither has a numeric prefix, fall back to ordinal string comparison
                return String.Equals(x , y , StringComparison.Ordinal);
            }
            // One has a numeric prefix, the other doesn't. They are not equal.
            return false;
        }

        public int GetHashCode([DisallowNull] string obj)
        {

            if(obj == null)
            {
                // Following IEqualityComparer contract, if Equals(null, null) is true,
                // then GetHashCode(null) should be consistent.
                // However, GetHashCode is marked [DisallowNull], so obj should not be null.
                // If it somehow is, this will prevent NullReferenceException.
                return 0; // A common hash code for null or non-existent values
            }

            // Get the numeric prefix for hashing
            if(TryGetNumericPrefix(obj , out double numericValue))
            {
                // Hash based on the numeric value
                // Using a consistent hash for doubles is important
                // double.GetHashCode() is generally good enough
                return numericValue.GetHashCode();
            }
            
            // Fallback: Use standard string hash code for non-numeric strings
            return StringComparer.Ordinal.GetHashCode(obj);
        }
    }
}

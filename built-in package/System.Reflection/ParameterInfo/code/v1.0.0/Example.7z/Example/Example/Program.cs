﻿using System;

namespace Example
{
    class Program
    {
        static void Main(string [ ] args)
        {
            //Console.WriteLine("-------------------------------------");
            //DemoClass.DemoClass1.TestMethod1();
            //Console.WriteLine("-------------------------------------");
            //Console.ReadLine();

            //Console.WriteLine("-------------------------------------");
            //DemoClass.DemoClass1.TestMethod2();
            //Console.WriteLine("-------------------------------------");
            //Console.ReadLine();

            //Console.WriteLine("-------------------------------------");
            //DemoClass.DemoClass1.TestMethod3();
            //Console.WriteLine("-------------------------------------");
            //Console.ReadLine();

            //Console.WriteLine("-------------------------------------");
            //DemoClass.DemoClass1.TestMethod4();
            //Console.WriteLine("-------------------------------------");
            //Console.ReadLine();

            Console.WriteLine("-------------------------------------");
            DemoClass.DemoClass1.TestMethod5();
            Console.WriteLine("-------------------------------------");
            Console.ReadLine();
        }
    }
}

﻿using System;

namespace Example.Classes.CustomModifiersExample
{
    public class MyClass
    {
        // A method with a parameter that has a required custom modifier.
        // In C#, you typically don't apply these directly in source code.
        // They are usually emitted by the compiler for specific scenarios,
        // like interop or advanced type system features.
        // For demonstration, we'll simulate a type that *would* have a required modifier.
        // > [!IMPORTANT] It's very difficult to create a C# source that directly
        // >
        // >
        // > produces a modreq for a parameter without using a language
        // > that explicitly supports it or by manipulating IL directly.
        // >
        // The example below is more about *how to read* it if it exists.
        public void MyMethod(int someParameter)
        {
            Console.WriteLine($"MyMethod called with: {someParameter}");
        }
    }
}

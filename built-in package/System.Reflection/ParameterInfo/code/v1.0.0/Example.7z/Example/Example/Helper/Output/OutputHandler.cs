﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

namespace Example.Helper.Output
{
    public static class OutputHandler
    {

        public static void DisplayCustomAttributeData(IList<CustomAttributeData> attributes)
        {
            foreach(CustomAttributeData cad in attributes)
            {
                Console.WriteLine("   {0}" , cad);
                Console.WriteLine("      Constructor: '{0}'" , cad.Constructor);

                Console.WriteLine("      Constructor arguments:");
                foreach(CustomAttributeTypedArgument cata
                    in cad.ConstructorArguments)
                {
                    DisplayValueOrArray(cata);
                }

                Console.WriteLine("      Named arguments:");
                foreach(CustomAttributeNamedArgument cana
                    in cad.NamedArguments)
                {
                    Console.WriteLine("         MemberInfo: '{0}'" ,
                        cana.MemberInfo);
                    DisplayValueOrArray(cana.TypedValue);
                }
            }
        }

        private static void DisplayValueOrArray(CustomAttributeTypedArgument customAttributeTypedArgument)
        {
            if(customAttributeTypedArgument.Value.GetType() == typeof(ReadOnlyCollection<CustomAttributeTypedArgument>))
            {
                Console.WriteLine("         Array of '{0}':" , customAttributeTypedArgument.ArgumentType);

                foreach(CustomAttributeTypedArgument cataElement in
                    (ReadOnlyCollection<CustomAttributeTypedArgument>)customAttributeTypedArgument.Value)
                {
                    Console.WriteLine("             Type: '{0}'  Value: '{1}'" ,
                        cataElement.ArgumentType , cataElement.Value);
                }
            }
            else
            {
                Console.WriteLine("         Type: '{0}'  Value: '{1}'" ,
                    customAttributeTypedArgument.ArgumentType , customAttributeTypedArgument.Value);
            }
        }


        // Displays the custom attributes applied to the specified member.
        public static void DisplayAttributes(int indentationLevel , MemberInfo memberInfo)
        {
            // Get the set of custom attributes; if none exist, just return.
            object [ ] attributes = memberInfo.GetCustomAttributes(false);
            if(attributes.Length == 0) 
            { 
                return; 
            }

            // Display the custom attributes applied to this member.
            Display(indentationLevel + 1 , "Attributes:");
            foreach(object o in attributes)
            {
                Display(indentationLevel + 2 , "{0}" , o.ToString());
            }
        }

        // Display a formatted string indented by the specified amount.
        public static void Display(
            int indentationLevel , 
            string format , 
            params object [ ] param
        )
        {
            Console.Write(new string(' ' , indentationLevel * 2));
            Console.WriteLine(format , param);
        }

        // Display a formatted string indented by the specified amount with different color.
        public static void DisplayWithColor(
            int indentationLevel ,
            ConsoleColor backgroundColor,
            ConsoleColor originalBackgroundColor,
            string format , 
            params object [ ] param
        )
        {
            Console.BackgroundColor = originalBackgroundColor;

            Console.Write(new string(' ' , indentationLevel * 2));
            int paramLength = param.Length;
            string seperator = param [ 0 ].ToString();
            string newLine = param [ 1 ].ToString();
            string tab = param [ 2 ].ToString();
            string space = param [ 3 ].ToString();

            string formattingString = string.Empty;
            string subStr = string.Empty;

            int indexOfFirstOccurrence = -1;
            int indexOfPrevOccurrence = 0;

            for(int i=3+1;i<paramLength;i++)
            {
                formattingString = "{" + i + "}";
                indexOfFirstOccurrence = format.IndexOf(formattingString);

                /// In `{1}{2}{0}{3}Parameter={4}`, 
                /// print formatted string from `{1}{2}{0}{3}Parameter=` in Console 
                /// with `backgroundColor`as its background color
                subStr = format.Substring(
                    indexOfPrevOccurrence,
                    indexOfFirstOccurrence- indexOfPrevOccurrence
                );

                Console.BackgroundColor = originalBackgroundColor;

                Console.Write(subStr,seperator,newLine,tab,space);

                /// In `{1}{2}{0}{3}Parameter={4}`, 
                /// print formatted string from `{4}` in Console 
                /// with `backgroundColor`as its background color
                Console.BackgroundColor = backgroundColor;

                Console.Write(param[i]);

                Console.BackgroundColor = originalBackgroundColor;

                /// update the flags that is used as variables
                indexOfPrevOccurrence = indexOfFirstOccurrence + formattingString.Length;
            }

            Console.BackgroundColor = originalBackgroundColor;
        }
    }
}

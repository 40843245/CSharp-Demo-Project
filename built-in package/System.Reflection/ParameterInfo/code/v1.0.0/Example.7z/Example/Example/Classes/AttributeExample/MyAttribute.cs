﻿using System;

namespace Example.Classes.AttributeExample
{
    // Define a custom attribute with one named parameter.
    [AttributeUsage(AttributeTargets.Parameter)]
    public class MyAttribute : Attribute
    {
        private string myName;
        public MyAttribute(string name)
        {
            myName = name;
        }
        public string Name
        {
            get
            {
                return myName;
            }
        }
    }
}

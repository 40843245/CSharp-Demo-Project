﻿namespace Example.Classes.AttributeExample
{
    // Define a class with a method that has three parameters. Apply
    // MyAttribute to one parameter, MyDerivedAttribute to another, and
    // no attributes to the third.
    public class MyClass1
    {
        public void MyMethod(
            [MyAttribute("This is an example parameter attribute")]
        int i ,
            [MyDerivedAttribute("This is another parameter attribute")]
        int j ,
            int k)
        {
            return;
        }
    }
}

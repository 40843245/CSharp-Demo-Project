﻿using System;

namespace Example.Classes.AttributeExample
{
    [AttributeUsage(AttributeTargets.Parameter)]
    public class MyDerivedAttribute : MyAttribute
    {
        public MyDerivedAttribute(string name) : base(name) { }
    }
}

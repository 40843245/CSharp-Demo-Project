﻿using System;
using System.IO;

namespace Example.Helper.FilePath
{
    public static class FilePathHandler
    {
        public static class FileFullPathHandler
        {
            public static string GetExportedMessageFullPath(
                string methodName    
            )
            {
                string guid = Guid.NewGuid().ToString();
                string fileExtension = ".log";
                string fileName = $@"Output in {methodName} method";

                string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                string projectRootDirectory = Directory.GetParent(baseDirectory).Parent.Parent.FullName;

                string fileDirectory =
                    Path.Combine(
                        projectRootDirectory ,
                        "AppData" ,
                        "Output" ,
                        "Console"
                    );

                string fileFullPath =
                    Path.Combine(
                        fileDirectory ,
                        $@"{fileName}_{guid}{fileExtension}"
                    );

                return fileFullPath;
            }
        }
    }
}

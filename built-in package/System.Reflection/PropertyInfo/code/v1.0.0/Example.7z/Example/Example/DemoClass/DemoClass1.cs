﻿using Example.Bean;
using Example.Generics.Repository;
using Example.Helpers.Classes;
using Example.Utilities.Output;
using System;
using System.Collections.Generic;
using System.Reflection;

using static Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods.HighOrderFunctionsExtensionMethods;

using static Example.Extensions.ExtensionMethods.MethodInfoExtensionMethods.GenericMethodExtensionMethods;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// get all methods info of specific current `Type`.
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Type [ ] types = new Type [ ]
            {
                typeof(GenericRepository<Company>),
                typeof(IGenericRepository<Company>),

            };

            for(int i = 0; i < types.Length; i++)
            {
                Console.WriteLine(@"///* --------------- Example {0} --------------- *///" , i + 1);

                Type type = types [ i ];
                MethodInfo [ ] methodInfos = type.GetMethods();

                List<string> textList = new List<string>();
                int counter = 0;
                string formattingString = "{0}th {1}:{2}";
                string text = string.Empty;

                textList = methodInfos.Apply<MethodInfo , string>(
                    methodInfo =>
                    {
                        var result = string.Empty;
                        if(methodInfo is MethodInfo nonNullMethodInfo)
                        {
                            result = string.Format(
                            formattingString ,
                            counter ,
                            "methodInfo.Name:" ,
                            nonNullMethodInfo.Name
                        );
                            counter++;
                            return result;
                        }
                        result = string.Format(
                                formattingString ,
                                counter ,
                                "methodInfo is" ,
                                "null"
                            );
                        counter++;
                        return result;
                    }
                );

                text = string.Join(System.Environment.NewLine , textList);
                Console.WriteLine(type.Name);
                Console.WriteLine(text);

                Console.WriteLine();
            }
        }

        /// <summary>
        /// illustrate how to get specific method info of current type.
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call" , MethodBase.GetCurrentMethod().Name);

            Type stringType = typeof(string);
            MethodInfo substringMethodInfo =
                stringType.GetMethod(
                    "Substring" ,
                    new Type [ ] { typeof(int) , typeof(int) }
                );

            string message = "Hello World";
            object result = substringMethodInfo.Invoke(message , new object [ ] { 3 , 2 });
            Console.WriteLine(
                "{0} with arguments {1} {2} returns {3}." ,
                substringMethodInfo ,
                3 ,
                2 ,
                result
            );
        }

        /// <summary>
        /// illustrate how to create delegate with current method (in `MethodInfo` type).
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Type type;
            string methodToFind;
            BindingFlags bindingFlags;
            MethodInfo methodInfo;

            string text = string.Empty;
            int counter = 1;

            ///* --------------- Example 1 --------------- *///
            Console.WriteLine(@"///* --------------- Example {0} --------------- *///" , counter);

            type = typeof(Greeting);
            methodToFind = "Say";
            
            methodInfo = type.GetMethod(methodToFind);

            if(methodInfo != null)
            {
                text = string.Format("There are such method {0} found in {1} type" , methodToFind , type.FullName);
                Person personNico = new Person()
                {
                    Id = 1 ,
                    FirstName = "Yazawa" ,
                    LastName = "Nico" ,
                };

                Greeting greetingToNico =
                    new Greeting(
                        personNico,
                        "Welcome"
                    );

                Greeting.SayDelegate sayDelegate =
                    (Greeting.SayDelegate)methodInfo.CreateDelegate(
                        typeof(Greeting.SayDelegate) ,
                        greetingToNico
                    );

                sayDelegate();
            }
            else
            {
                text = string.Format("There are no such method {0} found in {1} type" , methodToFind , type.FullName);
            }

            Console.WriteLine(text);
            Console.WriteLine();
            counter++;

            ///* --------------- Example 2 --------------- *///
            Console.WriteLine(@"///* --------------- Example {0} --------------- *///" , counter);

            type = typeof(Greeting);
            methodToFind = "StaticSay";

            methodInfo = type.GetMethod(methodToFind);

            if(methodInfo != null)
            {
                text = string.Format("There are such method {0} found in {1} type" , methodToFind , type.FullName);
                Person personNico = new Person()
                {
                    Id = 1 ,
                    FirstName = "Yazawa" ,
                    LastName = "Nico" ,
                };

                Greeting.StaticSayDelegate staticSayDelegate =
                    (Greeting.StaticSayDelegate)methodInfo.CreateDelegate(
                        typeof(Greeting.StaticSayDelegate) ,
                        null
                    );

                staticSayDelegate(personNico,"Welcome");
            }
            else
            {
                text = string.Format("There are no such method {0} found in {1} type" , methodToFind , type.FullName);
            }

            Console.WriteLine(text);
            Console.WriteLine();
            counter++;

        }

        /// <summary>
        /// illustrate how to get the method info on the direct or indirect base class in which the method represented by this instance was first declared
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Type t = typeof(DerivedClass);
            MethodInfo m, mb;
            string [ ] methodNames = { "ToString", "Equals", "InterfaceImpl",
                               "Method1", "Method2", "Method3" };

            foreach(var methodName in methodNames)
            {
                m = t.GetMethod(methodName);
                mb = m.GetBaseDefinition();
                Console.WriteLine("{0}.{1} --> {2}.{3}" , m.ReflectedType.Name ,
                                  m.Name , mb.ReflectedType.Name , mb.Name);
            }
        }

        /// <summary>
        /// illustrate how to 
        /// 
        /// + make a method into a generic method
        /// + get the method definition from a generic method
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string text = string.Empty;
            Type ex = typeof(OutputHandler);
            MethodInfo mi = ex.GetMethod("Generic");

            text = mi.GetGenericMethodInfo();
            Console.WriteLine(text);

            MethodInfo miConstructed = mi.MakeGenericMethod(typeof(int));

            text = miConstructed.GetGenericMethodInfo();
            Console.WriteLine(text);

            MethodInfo miDef = miConstructed.GetGenericMethodDefinition();
            Console.WriteLine("\r\nThe definition is the same: {0}" ,
                miDef == mi);

            text = miDef.GetGenericMethodInfo();
            Console.WriteLine(text);
        }
    }
}

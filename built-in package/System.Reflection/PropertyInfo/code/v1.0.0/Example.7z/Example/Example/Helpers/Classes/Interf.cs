﻿namespace Example.Helpers.Classes
{
    public interface Interf
    {
        string InterfaceImpl(int n);
    }
}

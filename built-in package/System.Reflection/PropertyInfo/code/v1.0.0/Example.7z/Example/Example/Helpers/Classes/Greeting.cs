﻿using Example.Bean;
using System;

namespace Example.Helpers.Classes
{
    public class Greeting
    {
        public Person Person { get;}

        public DateTime GreetingAt { get;}

        public string GreetingMessage { get; }


        public delegate void SayDelegate();
        public delegate void StaticSayDelegate(Person person,string greetingMessage);

        public Greeting(
            Person person,
            string greetingMessage
        )
        {
            GreetingAt = DateTime.Now;
            Person = person;
            GreetingMessage = greetingMessage;
        }
        public void Say()
        {
            Console.WriteLine("{0} {1}",GreetingMessage, Person);
        }
        
        public static void StaticSay(
            Person person,
            string greetingMessage
        )
        {
            Console.WriteLine("{0} {1}" , greetingMessage , person);
        }
    }
}

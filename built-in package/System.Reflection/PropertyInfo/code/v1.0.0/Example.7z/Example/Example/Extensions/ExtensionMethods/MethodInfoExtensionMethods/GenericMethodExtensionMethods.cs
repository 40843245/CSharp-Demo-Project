﻿using System;
using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.MethodInfoExtensionMethods
{
    public static class GenericMethodExtensionMethods
    {
        public static string GetGenericMethodInfo(
            this MethodInfo methodInfo
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("\r\n{0}\n" , methodInfo);

            stringBuilder.AppendFormat("\tIs this a generic method definition? {0}\n" ,
                methodInfo.IsGenericMethodDefinition);

            stringBuilder.AppendFormat("\tIs it a generic method? {0}\n" ,
                methodInfo.IsGenericMethod);

            stringBuilder.AppendFormat("\tDoes it have unassigned generic parameters? {0}\n" ,
                methodInfo.ContainsGenericParameters);

            // If this is a generic method, display its type arguments.
            //
            if(methodInfo.IsGenericMethod)
            {
                Type [ ] typeArguments = methodInfo.GetGenericArguments();

                stringBuilder.AppendFormat("\tList type arguments ({0}):\n" ,
                    typeArguments.Length);

                foreach(Type tParam in typeArguments)
                {
                    // IsGenericParameter is true only for generic type
                    // parameters.
                    //
                    if(tParam.IsGenericParameter)
                    {
                        stringBuilder.AppendFormat("\t\t{0}  parameter position {1}" +
                            "\n\t\t   declaring method: {2}\n" ,
                            tParam ,
                            tParam.GenericParameterPosition ,
                            tParam.DeclaringMethod);
                    }
                    else
                    {
                        stringBuilder.AppendFormat("\t\t{0}\n" , tParam);
                    }
                }
            }
            return stringBuilder.ToString();
        }
    }
}

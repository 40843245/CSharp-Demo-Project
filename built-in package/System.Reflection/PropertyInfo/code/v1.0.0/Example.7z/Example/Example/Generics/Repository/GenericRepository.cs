﻿namespace Example.Generics.Repository
{
    public class GenericRepository<TBean> : IGenericRepository<TBean>
        where TBean : class
    {
        public void DeleteOne(TBean bean)
        {
            throw new System.NotImplementedException();
        }

        public void GetFirstOrNull(TBean bean)
        {
            throw new System.NotImplementedException();
        }

        public void InsertOne(TBean bean)
        {
            throw new System.NotImplementedException();
        }

        public void UpdateOne(TBean bean)
        {
            throw new System.NotImplementedException();
        }
    }
}

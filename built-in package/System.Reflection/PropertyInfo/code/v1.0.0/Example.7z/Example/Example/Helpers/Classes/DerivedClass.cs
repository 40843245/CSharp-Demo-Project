﻿using System;

namespace Example.Helpers.Classes
{
    public class DerivedClass : BaseClass, Interf
    {
        public string InterfaceImpl(int n)
        {
            return n.ToString("N");
        }

        public override void Method2()
        {
            Console.WriteLine("Derived.Method2");
        }

        public new void Method3()
        {
            Console.WriteLine("Derived.Method3");
        }
    }
}

﻿using System.Reflection;

namespace Example.Bean
{
    [DefaultMember("Lowerbound")]
    public class Volume
    {
        public int Lowerbound { get; set; }
        public int Upperbound { get; set; }
        public int Loudness { get; set; }

    }
}

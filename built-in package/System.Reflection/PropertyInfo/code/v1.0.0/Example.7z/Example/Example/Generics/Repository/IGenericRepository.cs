﻿namespace Example.Generics.Repository
{
    public interface IGenericRepository<TBean> 
        where TBean: class
    {
       void GetFirstOrNull(TBean bean);
       void InsertOne(TBean bean);
       void DeleteOne(TBean bean);
       void UpdateOne(TBean bean);
    }
}

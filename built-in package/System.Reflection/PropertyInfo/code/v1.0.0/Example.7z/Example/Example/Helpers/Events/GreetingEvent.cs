﻿namespace Example.Helpers.Events
{
    public class GreetingEvent
    {
        public delegate void GoodMorningEventHandler(string message);
        public event GoodMorningEventHandler goodMorningEvent;
        public void RaiseGoodMorningEvent(string message)
        {
            goodMorningEvent?.Invoke($"Good Morning, {message}");
        }

        public delegate void GoodAfternoonEventHandler(string message);
        private event GoodAfternoonEventHandler goodAfternoonEvent;
        public void RaiseAfternoonEvent(string message)
        {
            goodAfternoonEvent?.Invoke($"Good Afternoon, {message}");
        }

        public delegate void GoodEveningEventHandler(string message);
        protected event GoodEveningEventHandler goodEveningEvent;
        public void RaiseGoodEveningEvent(string message)
        {
            goodEveningEvent?.Invoke($"Good Evening, {message}");
        }
    }
}

﻿namespace Example.Generics.Service
{
    public abstract class GenericService
    {
        public abstract void RedirectTo(string url);
    }
}

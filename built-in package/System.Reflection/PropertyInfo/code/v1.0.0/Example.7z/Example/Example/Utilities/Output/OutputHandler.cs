﻿using System;

namespace Example.Utilities.Output
{
    public class OutputHandler
    {
        public static void Generic<T>(T message)
        {
            Console.WriteLine("\r\nHere it is: {0}" , message);
        }
    }
}

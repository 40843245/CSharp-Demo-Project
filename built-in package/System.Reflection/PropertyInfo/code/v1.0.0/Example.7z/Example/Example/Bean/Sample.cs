﻿namespace Example.Bean
{
    public class Sample
    {
        public int Value { get; set; }
    }
}

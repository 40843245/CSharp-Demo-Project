﻿namespace Example.Bean
{
    public class Company
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}

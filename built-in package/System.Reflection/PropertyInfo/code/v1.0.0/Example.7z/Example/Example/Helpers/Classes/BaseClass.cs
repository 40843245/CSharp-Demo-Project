﻿using System;

namespace Example.Helpers.Classes
{
    public class BaseClass
    {
        public override string ToString()
        {
            return "Base";
        }

        public virtual void Method1()
        {
            Console.WriteLine("Method1");
        }

        public virtual void Method2()
        {
            Console.WriteLine("Method2");
        }

        public virtual void Method3()
        {
            Console.WriteLine("Method3");
        }
    }
}

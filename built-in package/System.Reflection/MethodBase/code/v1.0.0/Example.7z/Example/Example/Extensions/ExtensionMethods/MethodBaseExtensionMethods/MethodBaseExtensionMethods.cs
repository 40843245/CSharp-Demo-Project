﻿using Example.Extensions.ExtensionMethods.RuntimeMethodBodyExtensionMethods;
using Example.Utilities.Indentation;
using System.Reflection;
using System.Text;

using static Example.Extensions.ExtensionMethods.TypesExtensionMethods.TypesExtensionMethods;

namespace Example.Extensions.ExtensionMethods.MethodBaseExtensionMethods
{
    public static class MethodBaseExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0 , ' ' , '+');
        public static string GetInfo(
            this MethodBase methodBase ,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat("Current Method Name: {0}" , methodBase.Name);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Declaring Type: {0}" , methodBase.DeclaringType);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Member Type: {0}" , methodBase.MemberType);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Reflected Type: {0}" , methodBase.ReflectedType);
            stringBuilder.AppendLine();

            // Removed the problematic line as 'MethodBase' does not have a 'ReturnType' property.
            // If you need the return type of the method, you should use 'MethodInfo' instead of 'MethodBase'.
            // Example:
            MethodInfo methodInfo = methodBase as MethodInfo;
            if(methodInfo != null)
            {
                stringBuilder.AppendFormat("Return Type: {0}" , methodInfo.ReturnType);
                stringBuilder.AppendLine();
            }

            stringBuilder.AppendFormat("Is Static: {0}" , methodBase.IsStatic);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Virtual: {0}" , methodBase.IsVirtual);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Public: {0}" , methodBase.IsPublic);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Private: {0}" , methodBase.IsPrivate);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Family: {0}" , methodBase.IsFamily);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Assembly: {0}" , methodBase.IsAssembly);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Constructor: {0}" , methodBase.IsConstructor);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Generic Method: {0}" , methodBase.IsGenericMethod);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Generic Method Definition: {0}" , methodBase.IsGenericMethodDefinition);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Abstract: {0}" , methodBase.IsAbstract);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Final: {0}" , methodBase.IsFinal);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is HideBySig: {0}" , methodBase.IsHideBySig);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is SpecialName: {0}" , methodBase.IsSpecialName);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is SecurityCritical: {0}" , methodBase.IsSecurityCritical);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is SecuritySafeCritical: {0}" , methodBase.IsSecuritySafeCritical);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is SecurityTransparent: {0}" , methodBase.IsSecurityTransparent);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Is Defined: {0}" , methodBase.IsDefined(typeof(ObsoleteAttribute) , false));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Method Handle: {0}" , methodBase.MethodHandle);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Calling Convention: {0}" , methodBase.CallingConvention);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Metadata Token: {0}" , methodBase.MetadataToken);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Module: {0}" , methodBase.Module);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Get Method Implementation Flags by accessing `MethodImplementationFlags`: {0}" , methodBase.MethodImplementationFlags);
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat("Get Method Implementation Flags by invoking: `GetMethodImplementationFlags()` instance method: {0}" , methodBase.GetMethodImplementationFlags());

            stringBuilder.AppendFormat("Attributes: {0}" , methodBase.Attributes);
            stringBuilder.AppendLine();

            stringBuilder.AppendLine("Get Parameters:");
            stringBuilder.Append(ParameterInfosExtensionMethods.ParameterInfosExtensionMethods.GetInfo(methodBase.GetParameters() , indentationLevel + 1));

            stringBuilder.AppendLine("Get Generic Arguments:");
            stringBuilder.Append(TypesExtensionMethods.TypesExtensionMethods.GetInfo(methodBase.GetGenericArguments() , indentationLevel + 1));

            stringBuilder.AppendLine("Get Method Body:");
            stringBuilder.Append(MethodBodyExtensionMethods.GetInfo(methodBase.GetMethodBody() , indentationLevel + 1));

            stringBuilder.AppendLine("Get Custom Attributes:");
            stringBuilder.Append(ObjectsExtensionMethods.ObjectsExtensionMethods.GetInfo(
                methodBase.GetCustomAttributes(false) , indentationLevel + 1));

            stringBuilder.AppendLine("Get Custom Attributes (Obsolete):");
            stringBuilder.Append(ObjectsExtensionMethods.ObjectsExtensionMethods.GetInfo(
                methodBase.GetCustomAttributes(typeof(ObsoleteAttribute) , false) , indentationLevel + 1));

            stringBuilder.AppendLine("Get Custom Attributes (Obsolete):");
            stringBuilder.Append(CustomAttributeDatasExtensionMethods.CustomAttributeDatasExtensionMethods.GetInfo(methodBase.GetCustomAttributesData() , indentationLevel + 1));

            return stringBuilder.ToString();
        }
    }
}

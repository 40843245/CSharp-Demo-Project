﻿using static Example.Extensions.ExtensionMethods.StringExtensionMethods.StringExtensionMethods;

namespace Example.Utilities.Indentation
{
    public class IndentationHandler
    {
        private int _indentationLevel;
        public int IndentationLevel {
            get
            {
                return this._indentationLevel;
            }
            set
            {
                this._indentationLevel = value >= 0 ? value : 0;
            }
        }

        public char IndentationText { get; }
        public char LabelChar { get; }

        public IndentationHandler(
            int indentationLevel = 0 ,
            char indentationText = ' ',
            char labelChar = '+'
        )
        {
            IndentationLevel = indentationLevel;
            IndentationText = IsValidIndentationText(indentationText) ? indentationText : ' ';
            LabelChar = IsValidLabelChar(labelChar) ? labelChar : '+' ;
        }

        private bool IsValidLabelChar(char labelChar)
        {
            return labelChar == '+' ||
                   labelChar == '-' ||
                   labelChar == '*'
            ;
        }

        private bool IsValidIndentationText(char indentationText)
        {
            return !IsValidLabelChar(indentationText) &&
                   indentationText != '\0' && 
                   indentationText != '\n'
            ;
        }
        public void Indent(int indentationLevel = 1) => IndentationLevel += indentationLevel;

        public void UnIndent(int indentationLevel = 1) => IndentationLevel -= indentationLevel;

        public string GetIndentedMessage(string message)
        {
            return $"{IndentationText.ToString().Repeat(IndentationLevel)} {LabelChar} {message}";
        }

        public string GetIndentedMessage(string message, params object [ ] args)
        {
            return string.Format(GetIndentedMessage(message) , args);
        }
    }
}

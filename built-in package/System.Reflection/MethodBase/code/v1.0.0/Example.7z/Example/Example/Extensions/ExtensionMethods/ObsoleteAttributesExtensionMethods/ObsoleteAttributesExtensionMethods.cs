﻿using Example.Extensions.ExtensionMethods.ObsoleteAttributeExtensionMethods;
using Example.Utilities.Indentation;
using System.Text;

using static Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods.HighOrderFunctionsExtensionMethods;

namespace Example.Extensions.ExtensionMethods.ObsoleteAttributesExtensionMethods
{
    public static class ObsoleteAttributesExtensionMethods
    {

        public static string GetInfo(
            this IEnumerable<ObsoleteAttribute> obsoleteAttributes ,
            int indentationLevel = 0
        )
        {
            List<string> textList;

            StringBuilder stringBuilder = new StringBuilder();

            textList = obsoleteAttributes.Apply<ObsoleteAttribute , string>(
                obsoleteAttribute => obsoleteAttribute.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(System.Environment.NewLine , textList));

            return stringBuilder.ToString();
        }
    }
}

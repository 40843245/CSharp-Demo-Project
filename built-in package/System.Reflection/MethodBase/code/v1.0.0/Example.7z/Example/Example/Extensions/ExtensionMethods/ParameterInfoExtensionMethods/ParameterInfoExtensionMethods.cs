﻿using Example.Utilities.Indentation;
using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.ParameterInfoExtensionMethods
{
    public static class ParameterInfoExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0 , ' ' , '+');

        public static string GetInfo(
            this ParameterInfo parameterInfo,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Parameter: {0}" ,parameterInfo?.Name??"null"));
            stringBuilder.AppendLine();

           stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Type:{0}",parameterInfo?.ParameterType?.Name ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Has Default Value:{0}" , parameterInfo?.HasDefaultValue ?? false));
            stringBuilder.AppendLine();

            if (parameterInfo!=null && parameterInfo.HasDefaultValue)
            {
                stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Default Value:{0}", parameterInfo?.DefaultValue?.ToString() ?? "null"));
                stringBuilder.AppendLine();
            }

            return stringBuilder.ToString();
        }
    }
}

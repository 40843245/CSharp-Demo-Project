﻿using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Extensions.ExtensionMethods.MemberInfoExtensionMethods;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.MemberInfosExtensionMethods
{
    public static class MemberInfosExtensionMethods
    {
        public static string GetInfo(
            this IEnumerable<MemberInfo> memberInfos,
            int indentationLevel = 0
        )
        {
            List<string> textList = new List<string>();

            StringBuilder stringBuilder = new StringBuilder();
            
            textList = memberInfos.Apply<MemberInfo,string>(
                memberInfo => memberInfo.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(Environment.NewLine, textList));

            return stringBuilder.ToString();
        }
    }
}

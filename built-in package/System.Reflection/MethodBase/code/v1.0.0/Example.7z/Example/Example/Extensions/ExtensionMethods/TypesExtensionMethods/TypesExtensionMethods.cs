﻿using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Extensions.ExtensionMethods.TypeExtensionMethods;
using System.Collections.Generic;
using System.Text;

namespace Example.Extensions.ExtensionMethods.TypesExtensionMethods
{
    public static class TypesExtensionMethods
    {
        public static string GetInfo(
            this IEnumerable<Type> types,
            int indentationLevel = 0
        )
        {
            List<string> textList = new List<string>();

            StringBuilder stringBuilder = new StringBuilder();
            
            textList = types.Apply<Type, string>(
                type => type.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(Environment.NewLine, textList));
            
            return stringBuilder.ToString();
        }
    }
}

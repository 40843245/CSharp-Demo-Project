﻿using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Extensions.ExtensionMethods.LocalVariableInfoExtensionMethods;
using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.LocalVariableInfosExtensionMethods
{
    public static class LocalVariableInfosExtensionMethods
    {
        public static string GetInfo(
            this IEnumerable<LocalVariableInfo> localVariableInfos ,
            int indentationLevel = 0
        )
        {
            List<string> textList;
            
            StringBuilder stringBuilder = new StringBuilder();

            textList = localVariableInfos.Apply<LocalVariableInfo , string>(
                localVariableInfo => localVariableInfo.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(System.Environment.NewLine, textList));

            return stringBuilder.ToString();
        }
    }
}

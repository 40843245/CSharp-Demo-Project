﻿using Example.Beans;
using System;
using System.Collections.Generic;

namespace Example.Behaviors.Restaurant
{
    public class RestaurantBase
    {
        public required string Name { get; init; }
        public required string Location { get; init; }

        public List<Order> Orders { get; set; } = new List<Order>();

        public virtual void PlaceOrder(Order order)
        {
            string orderInfo = string.Empty;
            if(order == null)
            {
               orderInfo = "No order information provided.";
            }
            else
            {
                orderInfo = $"{order.CustomerName} places order at {Location}.\nOrder information:\n";
                foreach (var item in order.Items)
                {
                    if(item != null)
                    {
                        orderInfo += $"{item.ToString()}\n";
                    }
                }
                Orders.Add(order);
            }
            Console.Write(orderInfo);   
        }

        public virtual void PlaceOrder()
        {
            Console.WriteLine($"Welcome to {Name} Restaurant at {Location}!");
            Console.WriteLine("Please place your order at the counter.");
        }

        public virtual void PrintOrders()
        {
            if (Orders.Count == 0)
            {
                Console.WriteLine("No orders have been placed yet.");
                return;
            }
            Console.WriteLine($"Orders at {Name} Restaurant at {Location}:");
            foreach (var order in Orders)
            {
                Console.WriteLine(order.ToString());
            }
        }
    }
}

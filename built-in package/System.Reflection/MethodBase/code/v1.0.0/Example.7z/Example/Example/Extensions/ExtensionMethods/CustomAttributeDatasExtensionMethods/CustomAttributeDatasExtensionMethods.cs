﻿using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Extensions.ExtensionMethods.ObjectExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Example.Extensions.ExtensionMethods.CustomAttributeDatasExtensionMethods
{
    public static class CustomAttributeDatasExtensionMethods
    {
        public static string GetInfo(
            this IEnumerable<CustomAttributeData> customAttributeDatas,
            int indentationLevel = 0
        )
        {
            List<string> textList = new List<string>();

            StringBuilder stringBuilder = new StringBuilder();

            textList = customAttributeDatas.Apply<CustomAttributeData, string>(
                customAttributeData => customAttributeData.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(Environment.NewLine, textList));

            return stringBuilder.ToString();
        }
    }
}

﻿using System.Collections.Generic;
using System.Text;
using System.Runtime.CompilerServices;
using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Extensions.ExtensionMethods.MethodImplAttributeExtensionMethods;

namespace Example.Extensions.ExtensionMethods.MethodImplAttributesExtensionMethods
{
    public static class MethodImplAttributesExtensionMethods
    {
        public static string GetInfo(
            this IEnumerable<MethodImplAttribute> methodImplAttributes,
            int indentationLevel = 0
        )
        {
            List<string> textList = new List<string>();

            StringBuilder stringBuilder = new StringBuilder();
            
            textList = methodImplAttributes.Apply<MethodImplAttribute, string>(
                methodImplAttribute => methodImplAttribute.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(System.Environment.NewLine, textList));

            return stringBuilder.ToString();
        }
    }
}

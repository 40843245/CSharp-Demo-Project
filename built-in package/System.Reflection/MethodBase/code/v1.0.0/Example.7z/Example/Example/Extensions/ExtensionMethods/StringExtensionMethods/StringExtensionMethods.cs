﻿using System.Text;

using static Example.Extensions.ExtensionMethods.StringBuilderExtensionMethods.AppendExtensionMethods;

namespace Example.Extensions.ExtensionMethods.StringExtensionMethods
{
    public static class StringExtensionMethods
    {
        public static string Repeat(
            this string stringToRepeat,
            int times = 1
        )
        {
            // test whether the use case given `times` parameter is invalid or not. 
            if(times <= 0)
            {
                return string.Empty;
            }

            // test whether the use case given `times` parameter is a trivial use case.
            // If it is, we don't execute the following code, saving time when running.
            if(times == 1)
            {
                return stringToRepeat;
            }

            // core part
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(stringToRepeat,times); // no compiler error due to extension methods that is overloaded.
            return stringBuilder.ToString();
        }
    }
}

﻿using Example.Utilities.Indentation;
using System.Text;

namespace Example.Extensions.ExtensionMethods.MethodImplAttributeExtensionMethods
{
    public static class MethodImplAttributeExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');

        public static string GetInfo(
            this System.Runtime.CompilerServices.MethodImplAttribute methodImplAttribute,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Value: {0}", methodImplAttribute.Value));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("TypeId: {0}", methodImplAttribute.TypeId?.ToString() ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("IsDefaultAttribute: {0}", methodImplAttribute.IsDefaultAttribute()));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

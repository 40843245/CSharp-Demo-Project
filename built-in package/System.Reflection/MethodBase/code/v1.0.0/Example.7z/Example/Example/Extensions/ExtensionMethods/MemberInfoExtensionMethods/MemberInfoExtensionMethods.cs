﻿using Example.Utilities.Indentation;
using System.Text;

namespace Example.Extensions.ExtensionMethods.MemberInfoExtensionMethods
{
    public static class MemberInfoExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');

        public static string GetInfo(
            this System.Reflection.MemberInfo memberInfo,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Name: {0}", memberInfo.Name));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Declaring Type: {0}", memberInfo.DeclaringType?.Name ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Member Type: {0}", memberInfo.MemberType));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

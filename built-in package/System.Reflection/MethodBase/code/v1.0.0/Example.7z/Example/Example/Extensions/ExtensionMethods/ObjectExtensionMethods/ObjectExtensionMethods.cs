﻿using Example.Utilities.Indentation;
using System.Text;

namespace Example.Extensions.ExtensionMethods.ObjectExtensionMethods
{
    public static class ObjectExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');  

        public static string GetInfo(
            this object obj, 
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;
            if (obj == null)
            {
                return indentationHandler.GetIndentedMessage("Object is null");
            }
            StringBuilder stringBuilder = new StringBuilder();
            
            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Object Type:{0}" ,obj.GetType().Name));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Object Type:{0}" , obj.ToString()));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

﻿using Example.Utilities.Indentation;
using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.LocalVariableInfoExtensionMethods
{
    public static class LocalVariableInfoExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');
        public static string GetInfo(
            this LocalVariableInfo localVariableInfo,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Local Variable Type: {0}" , localVariableInfo?.LocalType?.FullName ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Local Variable Index: {0}" , localVariableInfo?.LocalIndex.ToString() ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("IsPinned: {0}" , localVariableInfo?.IsPinned.ToString()??"null"));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

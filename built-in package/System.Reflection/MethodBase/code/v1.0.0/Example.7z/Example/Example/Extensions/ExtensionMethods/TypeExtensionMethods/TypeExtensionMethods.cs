﻿using Example.Utilities.Indentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example.Extensions.ExtensionMethods.TypeExtensionMethods
{
    public static class TypeExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');

        public static string GetInfo(
            this Type type,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;
            
            StringBuilder stringBuilder = new StringBuilder();
            
            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Name: {0}", type.Name));
            stringBuilder.AppendLine();
            
            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Full Name: {0}", type.FullName ?? "null"));
            stringBuilder.AppendLine();
            
            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Namespace: {0}", type.Namespace ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Assembly: {0}", type?.Assembly?.FullName ??"null"));
            
            stringBuilder.AppendLine();
            return stringBuilder.ToString();
        }
    }
}

﻿using Example.Beans;

namespace Example.Behaviors.Restaurant
{
    public class BuffetRestuarant:RestaurantBase
    {
        new public void PlaceOrder(Order order)
        {
            if(order == null)
            {
                Console.WriteLine("No order information provided.");
                return;
            }

            Console.WriteLine($"Welcome to {Name} Buffet Restuarantat {Location}!");
            Console.WriteLine("You will be able to enjoy the these meal:");
            foreach (var item in order.Items)
            {
                if(item != null)
                {
                    Item nonNullableItem = item; // Ensure item is not null
                    Console.WriteLine($"- {nonNullableItem.ProductName}");
                }
            }

            Orders.Add(order);
        }    
    }
}

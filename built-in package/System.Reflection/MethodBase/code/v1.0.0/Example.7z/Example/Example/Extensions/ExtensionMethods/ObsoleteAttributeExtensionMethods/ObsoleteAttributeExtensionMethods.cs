﻿using Example.Utilities.Indentation;
using System.Text;

namespace Example.Extensions.ExtensionMethods.ObsoleteAttributeExtensionMethods
{
    public static class ObsoleteAttributeExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0,' ', '+');
        public static string GetInfo(
            this ObsoleteAttribute obsoleteAttribute,
            int indentationLevel = 0
        )
        {
            indentationHandler .IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Message: {0}" , obsoleteAttribute?.Message??"null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Is Error: {0}" , obsoleteAttribute?.IsError.ToString()??"null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("TypeId: {0}" , obsoleteAttribute?.TypeId?.ToString() ?? "null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("IsDefaultAttribute: {0}" , obsoleteAttribute.IsDefaultAttribute()));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("DiagnosticId: {0}" , obsoleteAttribute?.DiagnosticId ?? "null"));
            stringBuilder.AppendLine();
         
            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("UrlFormat: {0}" , obsoleteAttribute?.UrlFormat??"null"));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

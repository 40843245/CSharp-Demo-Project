﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example.Extensions.ExtensionMethods.CustomAttributeDataExtensionMethods
{
    internal class CustomAttributeDataExtensionMethods
    {
    }
}

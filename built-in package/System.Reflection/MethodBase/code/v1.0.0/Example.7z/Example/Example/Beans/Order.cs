﻿using System.Collections.Generic;
using System.Text;

namespace Example.Beans
{
    public class Order
    {
        public required int OrderId { get; init; }
        public required string CustomerName { get; init; }
        public required List<Item> Items { get; set; }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"Order ID: {OrderId}");
            stringBuilder.AppendLine($"Customer Name: {CustomerName}");
            if((Items?.Count ?? 0 ) <= 0)
            {
                stringBuilder.AppendLine("No items in this order.");
            }
            else
            {
                int itemsCount = Items?.Count?? 0;
                stringBuilder.AppendFormat("There are {0} items in this order:\n", itemsCount);
                for(int i = 0;i < itemsCount;i++)
                {
                    Item item = Items[i];
                    if(item==null)
                    {
                        continue;
                    }
                    stringBuilder.AppendFormat("Info about {0}th Item:\n", i + 1);
                    stringBuilder.AppendFormat("\t{0}\n",item.ToString());
                }
            }
            return stringBuilder.ToString();
        }
    }
}

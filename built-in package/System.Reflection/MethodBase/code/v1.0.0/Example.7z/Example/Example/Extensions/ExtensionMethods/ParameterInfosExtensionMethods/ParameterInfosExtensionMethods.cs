﻿using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using Example.Extensions.ExtensionMethods.ParameterInfoExtensionMethods;
using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.ParameterInfosExtensionMethods
{
    public static class ParameterInfosExtensionMethods
    {
        public static string GetInfo(
            this IEnumerable<ParameterInfo> parameterInfos,
            int indentationLevel = 0
        )
        {
            List<string> textList = new List<string>();

            StringBuilder stringBuilder = new StringBuilder();
            
            textList = parameterInfos.Apply<ParameterInfo, string>(
                parameterInfo => parameterInfo.GetInfo(indentationLevel + 1)
            );

            stringBuilder.AppendLine(string.Join(System.Environment.NewLine, textList));
            return stringBuilder.ToString();
        }
    }
}

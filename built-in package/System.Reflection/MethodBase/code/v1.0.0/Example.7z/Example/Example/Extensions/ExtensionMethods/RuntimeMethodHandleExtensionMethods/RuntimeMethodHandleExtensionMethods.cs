﻿using Example.Utilities.Indentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example.Extensions.ExtensionMethods.RuntimeMethodHandleExtensionMethods
{
    public static class RuntimeMethodHandleExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');
        public static string GetInfo(
            this RuntimeMethodHandle runtimeMethodHandle,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Value: {0}" , runtimeMethodHandle.Value));
            stringBuilder.AppendLine();

            // Display the method's metadata token.
            // The metadata token is a unique identifier for the method.
            // It is used by the CLR to identify the method at runtime.
            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Metadata Token: {0}" , runtimeMethodHandle.GetHashCode()));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Metadata Token: {0}" , runtimeMethodHandle.GetFunctionPointer()));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

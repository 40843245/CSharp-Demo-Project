﻿using Example.Utilities.Indentation;
using System.Text;

namespace Example.Extensions.ExtensionStructs.PointerExtensionStructs
{
    public static class PointerExtensionStructs
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');

        public static string GetPointerInfo<T>(
            this T pointer,
            int indentationLevel = 0
        ) where T : unmanaged
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Pointer Type: {0}" , typeof(T)?.FullName??"null"));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Pointer Size: {0} bytes" , System.Runtime.InteropServices.Marshal.SizeOf(typeof(T))));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

﻿using Example.Beans;
using Example.Behaviors.Restaurant;
using System;
using System.Reflection;
using System.Text;
using static Example.Extensions.ExtensionMethods.MethodBaseExtensionMethods.MethodBaseExtensionMethods;

namespace Example.DemoClass
{
    public class DemoClass1
    {
        /// <summary>
        /// illustrate how to get current running method info.
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to 
        /// 
        /// + get declaring type of current running method
        /// 
        /// + get member type of current running method
        /// 
        /// + get reflected type of current running method 
        /// 
        /// + get return type of current running method
        /// 
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            MethodBase currentMethod = MethodBase.GetCurrentMethod(); // will return current method Info
            Type declaringType = currentMethod.DeclaringType; // will return the class the defines of current method (here is `DemoC;ass1`)

            MemberTypes memberType = currentMethod.MemberType; // will return an enum that represents type of member of current method.

            Type reflectedType = currentMethod.ReflectedType; // will return the type that is reflected by current method.

            // Removed the problematic line as 'MethodBase' does not have a 'ReturnType' property.
            // If you need the return type of the method, you should use 'MethodInfo' instead of 'MethodBase'.
            // Example:
            MethodInfo methodInfo = currentMethod as MethodInfo;

            Console.WriteLine("Current Method Name: {0}" , currentMethod.Name);
            Console.WriteLine("Which class declares this member? {0}" , declaringType?.Name ?? "null");
            Console.WriteLine("Id that representing the type of member: {0}" , memberType);

            if(methodInfo != null)
            {
                Console.WriteLine("Return Type of {0} method: {1}" , methodInfo.Name,methodInfo.ReturnType.FullName);
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            
            Order orderNico = new Order
            {
                OrderId = 1,
                CustomerName = "Yazawa Nico",
                Items = new List<Item>
                {
                    new Item { ItemId = 1, ProductName = "Pizza", Price = 9.99d },
                    new Item { ItemId = 2,ProductName = "Pasta", Price = 7.99d },
                },
            };

            Order orderAi = new Order
            {
                OrderId = 2 ,
                CustomerName = "Ai" ,
                Items = new List<Item>
                {
                    new Item { ItemId = 1, ProductName = "strawberry milk", Price = 9.0d },
                },
            };

            RestaurantBase pizzaRestaurantInNewYorkCity = new RestaurantBase
            {
                Name = "New York Pizza Restaurant",
                Location = "New York City",
            };

            BuffetRestuarant buffetRestuarantInLasVegas = new BuffetRestuarant
            {
                Name = "Buffet Paradise",
                Location = "Las Vegas",
            };

            string overloadedMethodName = "PlaceOrder";
            Type pizzaRestaurantInNewYorkCityType = pizzaRestaurantInNewYorkCity.GetType();
            MethodInfo [ ] methodInfos = pizzaRestaurantInNewYorkCityType.GetMethods(BindingFlags.Public | BindingFlags.Instance);

            Console.WriteLine("------ List the overloads of {0} in the derived class {1} ------", overloadedMethodName,typeof(BuffetRestuarant).FullName);
            foreach(MethodInfo methodInfo in pizzaRestaurantInNewYorkCityType.GetMethods())
            {
                if(methodInfo.Name.Equals(overloadedMethodName)) 
                { 
                    Console.WriteLine(
                        "Overloaded method {0}: {1}  IsHideBySig = {2}, DeclaringType = {3}" ,
                        overloadedMethodName,
                        methodInfo , 
                        methodInfo.IsHideBySig , 
                        methodInfo.DeclaringType
                    ); 
                }
            }

            Console.WriteLine(
                "------ Call the overloads of {0} available in derived class {1} ------",
                overloadedMethodName,
                typeof(BuffetRestuarant).FullName
            );

            Console.ForegroundColor = ConsoleColor.Green;

            buffetRestuarantInLasVegas.PlaceOrder(orderNico);
            buffetRestuarantInLasVegas.PlaceOrder(orderAi);
            buffetRestuarantInLasVegas.PlaceOrder(); // call the overload without parameter

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine(
                "------ Call the overloads of {0} available in base class {1} ------" ,
                overloadedMethodName ,
                typeof(RestaurantBase).FullName
            );

            pizzaRestaurantInNewYorkCity = buffetRestuarantInLasVegas;

            Console.ForegroundColor = ConsoleColor.Green;

            pizzaRestaurantInNewYorkCity.PlaceOrder(orderNico);
            pizzaRestaurantInNewYorkCity.PlaceOrder(orderAi);
            pizzaRestaurantInNewYorkCity.PlaceOrder(); // call the overload without parameter

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine(
                "------------ Order List in {0}, which is a {1} --------------------",
                buffetRestuarantInLasVegas.Name,
                buffetRestuarantInLasVegas.GetType() == typeof(BuffetRestuarant) ? "Buffet Restuarant" : "Normal Restaurant"
            );

            Console.ForegroundColor = ConsoleColor.Green;

            buffetRestuarantInLasVegas.PrintOrders();

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine(
                "------------ Order List in {0}, which is a {1} --------------------" ,
                pizzaRestaurantInNewYorkCity.Name ,
                pizzaRestaurantInNewYorkCity.GetType() == typeof(BuffetRestuarant) ? "Buffet Restuarant" : "Normal Restaurant"
            );

            Console.ForegroundColor = ConsoleColor.Green;

            pizzaRestaurantInNewYorkCity.PrintOrders();

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
        /// <summary>
        /// illustrate 
        /// 
        /// + how to get current method info 
        /// 
        /// using reflection 
        /// 
        /// (by invoking `MethodBase.GetCurrentMethod()`)
        /// 
        /// + properties and methods in `MethodBase` class.
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string infoText = string.Empty;
            
            infoText = MethodBase.GetCurrentMethod().GetInfo();

            Console.WriteLine(infoText);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

﻿namespace Example.Beans
{
    public class Item
    {
        public required int ItemId { get; init; }
        public required string ProductName { get; init; }
        private double _price; 
        public required double Price 
        {
            get
            {
                return _price;
            }
            init
            {
                if(value < 0.0d)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), "Price cannot be negative.");
                }
                _price = (double)value;
            } 
        }

        public override string ToString()
        {
            return $"Item ID: {ItemId}, Product: {ProductName}, Price: {Price}";
        }
    }
}

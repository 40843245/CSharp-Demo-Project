﻿using Example.Extensions.ExtensionMethods.LocalVariableInfosExtensionMethods;
using Example.Utilities.Indentation;
using System.Text;

namespace Example.Extensions.ExtensionMethods.RuntimeMethodBodyExtensionMethods
{
    public static class MethodBodyExtensionMethods
    {
        public static IndentationHandler indentationHandler = new IndentationHandler(0, ' ', '+');
        public static string GetInfo(
            this System.Reflection.MethodBody methodBody,
            int indentationLevel = 0
        )
        {
            indentationHandler.IndentationLevel = indentationLevel;

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Local Variables Count: {0}" , methodBody.LocalVariables.Count));
            stringBuilder.AppendLine();

            stringBuilder.AppendFormat(indentationHandler.GetIndentedMessage("Max Stack Size: {0}" , methodBody.MaxStackSize));
            stringBuilder.AppendLine();

            stringBuilder.Append(methodBody.LocalVariables.GetInfo(indentationLevel + 1));
            stringBuilder.AppendLine();

            return stringBuilder.ToString();
        }
    }
}

﻿using System.Text;

namespace Example.Extensions.ExtensionMethods.StringBuilderExtensionMethods
{
    public static class AppendExtensionMethods
    {
        /// <summary>
        /// > [!NOTE]
        /// > NOTE that
        /// >
        /// > Since `StringBuilder` is a reference type,
        /// > 
        /// > the `stringBuilder` extension parameter is reflect to origin one.
        /// >
        /// > i.e. when `stringBuilder` extension parameter is modified, the original one is also modified.
        /// 
        /// </summary>
        /// <param name="stringBuilder"></param>
        /// <param name="stringToRepeat"></param>
        /// <param name="times"></param>
        public static void Append(
            this StringBuilder stringBuilder,
            string stringToRepeat,
            int times
        )
        {
            for(int i = 0; i < times; i++) {
                stringBuilder.Append(stringToRepeat);
            }
        }
    }
}

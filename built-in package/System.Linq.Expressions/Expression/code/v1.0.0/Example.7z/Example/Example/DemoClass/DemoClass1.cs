﻿using Example.Utilities.Equals;
using Example.Utilities.Generator;
using Example.Utilities.Visitor;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.BinaryExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.UnaryExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.ConditionalExpressionsExtensionMethods;
using Example.Utilities.Expressions;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Func<int , bool> delegateFunction1 = i => i < 5; // a delegate function.
           
            for(int i = 0; i < 10;i++) 
            {
                Console.WriteLine("delegateFunction1({0}) = {1}" , i , delegateFunction1(i));
            }

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.
            Func<int , bool> delegateFunction2 = expression1.Compile(); // compile it, making it as an delegate function.

            Console.WriteLine();
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("delegateFunction2({0}) = {1}" , i , delegateFunction2(i));
            }
        }

        /// <summary>
        /// Compare two delegate function are referentially equal.
        /// 
        /// First delegate function is directly initialized.
        /// 
        /// While, second delegate function is made from an expression in form of an expression tree.
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression parameterExpression = Expression.Parameter(typeof(bool) , "result");

            Func<int , bool> delegateFunction1 = i => i < 5; // a delegate function.

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.
            Func<int , bool> delegateFunction1FromExpression1 = expression1.Compile(); // compile it, making it as an delegate function.

            Func<int , bool> delegateFunction2 = i => i < 5; // a delegate function.

            Func<int , bool> delegateFunction2FromExpression1 = expression1.Compile(); // compile it, making it as an delegate function.

            Expression<Func<int , bool>> expression2 = i => i < 5; // represents a delegate function in form of an expression tree.
            Func<int , bool> delegateFunction1FromExpression2 = expression2.Compile(); // compile it, making it as an delegate function.

            Func<int , bool> delegateFunction2FromExpression2 = expression2.Compile(); // compile it, making it as an delegate function.

            int counter = 1;

            Console.WriteLine("In {0}th comparison" , counter);
            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction2 ,
                "delegate function"
            );
            counter++;

            Console.WriteLine("In {0}th comparison",counter);
            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction1FromExpression1 ,
                "delegate function"
            );
            counter++;

            Console.WriteLine("In {0}th comparison" , counter);
            EqualMessageOutput.PrintInfo(
                delegateFunction1FromExpression1 ,
                delegateFunction2FromExpression1 ,
                "delegate function"
            );
            counter++;

            List<BinaryExpression> binaryExpressionForReferenceEqual = new List<BinaryExpression>();

            List<BinaryExpression> binaryExpressionForReferenceNotEqual = new List<BinaryExpression>();

            binaryExpressionForReferenceEqual.Add(Expression.ReferenceEqual(expression1,expression2));

            binaryExpressionForReferenceNotEqual.Add(Expression.ReferenceNotEqual(expression1,expression2));

            Console.WriteLine("About `binaryExpressionForReferenceEqual`");
            binaryExpressionForReferenceEqual.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);   
                }
            );
            Console.WriteLine();

            Console.WriteLine("About `binaryExpressionForReferenceNotEqual`");
            binaryExpressionForReferenceNotEqual.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                }
            );
            Console.WriteLine();

        }

        /// <summary>
        /// Compare two delegate function are referentially equal.
        /// 
        /// First delegate function and second delegate function is made from an expression in form of an expression tree. But made with different `Compile` instance method call. 
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.

            Func<int , bool> delegateFunction1 = expression1.Compile(); // compile it, making it as an delegate function.
            Func<int , bool> delegateFunction2 = expression1.Compile(); // compile it, making it as an delegate function.

            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction2 ,
                "delegate function"
            );
        }

        /// <summary>
        /// Compare two delegate function are referentially equal.
        /// 
        /// First delegate function and second delegate function is made from an expression in form of an expression tree. But made with different `Compile` instance method call. 
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.

            Func<int , bool> delegateFunction1 = expression1.Compile(false); // not compile it, using other way to make it as an delegate function.
            Func<int , bool> delegateFunction2 = expression1.Compile(false); // not compile it, using other way to make it as an delegate function.

            EqualMessageOutput.PrintInfo(
                delegateFunction1,
                delegateFunction2,
                "delegate function"
            );
        }

        /// <summary>
        /// referentially equal check
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.

            Func<int , bool> delegateFunction1 = expression1.Compile(false); // compile it, making it as an delegate function.
            Func<int , bool> delegateFunction2 = delegateFunction1; // points to first delegate function,

            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction2 ,
                "delegate function"
            );
        }

        /// <summary>
        /// illustrate to check the `Expression` with boolean data type is true or false.
        /// </summary>
        public static void TestMethod6()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression expressionConstantTrue = Expression.Constant(true);
            Expression expressionConstantFalse = Expression.Constant(false);

            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                Expression.IsTrue(
                    expressionConstantTrue
                )
            );

            unaryExpressions.Add(
                Expression.IsTrue(
                    expressionConstantFalse
                )
            );

            unaryExpressions.Add(
                Expression.IsFalse(
                    expressionConstantTrue
                )
            );

            unaryExpressions.Add(
                Expression.IsFalse(
                    expressionConstantFalse
                )
            );

            unaryExpressions.ForEach(
                (unaryExpression) => 
                {
                    string infoText = unaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                }
            );
        }

        /// <summary>
        /// illustrate to check given string that start with `Cat`. 
        /// </summary>
        public static void TestMethod7()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression textParam = Expression.Parameter(typeof(string) , "text");

            Expression startWithCatExpression = Expression.Constant("start with cat");
            Expression notStartWithCatExpression = Expression.Constant("not start with cat");


            MethodInfo isNullOrEmptyMethod = typeof(string).GetMethod("IsNullOrEmpty" , new [ ] { typeof(string) });
            MethodInfo startsWithMethod = typeof(string).GetMethod("StartsWith" , new [ ] { typeof(string) });


            Expression startWithCatCondition = Expression.AndAlso(
                Expression.Not(Expression.Call(isNullOrEmptyMethod , textParam)) , 
                Expression.Call(textParam , startsWithMethod , Expression.Constant("Cat"))
            );

            List<ConditionalExpression> conditionalExpressions = new List<ConditionalExpression>();

            string [ ] textArray = new string [ ]
            {
                string.Empty,
                "Cat",
                "CatShabo",
                "Spy x family",
                "PurismMagica"
            };

            conditionalExpressions.Add(
                Expression.IfThen(
                    startWithCatCondition,
                    startWithCatExpression
                )
            );

            conditionalExpressions.Add(
                Expression.IfThenElse(
                    startWithCatCondition ,
                    startWithCatExpression,
                    notStartWithCatExpression
                )
           );


            conditionalExpressions.ForEach(
                (conditionalExpression) =>
                {
                    string infoText = conditionalExpression.GetInfo();
                    Console.WriteLine(infoText);
                    Console.WriteLine();

                    LambdaExpression lambdaExpression = Expression.Lambda(
                                                conditionalExpression ,
                                                new List<ParameterExpression>() { textParam }
                                            );

                    var delegateFunction = lambdaExpression.Compile();
                    Console.WriteLine("---- new round ----");
                    foreach(string text in textArray)
                    {
                        Console.WriteLine("delegateFunction.DynamicInvoke({0}):{1}" , text , delegateFunction.DynamicInvoke(text));
                    }
                }
            );
        }

        /// <summary>
        /// illustrate assignment operations.  
        /// </summary>
        public static void TestMethod8()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            List<BinaryExpression> binaryExpressions = new List<BinaryExpression>();

            binaryExpressions.Add(
                Expression.Assign(
                    Expression.Variable(typeof(int) , "x") ,
                    Expression.Constant(42)
                )
            );

            Console.WriteLine("About `binaryExpressions`");
            binaryExpressions.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                }
            );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate mathematically operations.  
        /// </summary>
        public static void TestMethod9()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression intParameterExpression1 = Expression.Parameter(typeof(int) , "arg");
            UnaryExpression doubleParameterExpression1 = Expression.Convert(intParameterExpression1 , typeof(double));

            ParameterExpression doubleParameterExpression2 = Expression.Parameter(typeof(double) , "arg");

            ParameterExpression intVariable1 = Expression.Variable(typeof(int) , "returnValue");
            ParameterExpression doubleVariable1 = Expression.Variable(typeof(double) , "returnValue");

            List<Expression> expressionsToTest = new List<Expression>();
            
            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that add 1 to the parameter value.
                Expression.Add(
                    intParameterExpression1 ,
                    Expression.Constant(1)
                )
           );

            expressionsToTest.Add(
               // This expression represents a lambda expression
               // that add 1 to the parameter value.
               Expression.AddAssign(
                   intParameterExpression1 ,
                   Expression.Constant(1)
               )
          );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that subtract 1 to the parameter value.
                Expression.Subtract(
                    intParameterExpression1 ,
                    Expression.Constant(1)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that subtract 1 to the parameter value.
                Expression.SubtractAssign(
                    intParameterExpression1 ,
                    Expression.Constant(1)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that mutliply by 2 to the parameter value.
                Expression.Multiply(
                    intParameterExpression1 ,
                    Expression.Constant(2)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that mutliply by 2 to the parameter value.
                Expression.MultiplyAssign(
                    intParameterExpression1 ,
                    Expression.Constant(2)
                )
           );


            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that divided by 5 to the parameter value.
                Expression.Divide(
                    intParameterExpression1 ,
                    Expression.Constant(5)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that divided by 5 to the parameter value.
                Expression.DivideAssign(
                    intParameterExpression1 ,
                    Expression.Constant(5)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that modulo 4 to the parameter value.
                Expression.Modulo(
                    intParameterExpression1 ,
                    Expression.Constant(4)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that modulo 4 to the parameter value.
                Expression.ModuloAssign(
                    intParameterExpression1 ,
                    Expression.Constant(4)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that power of 4 to the parameter value.
                Expression.Power(
                    doubleParameterExpression1 ,
                    Expression.Constant(4d)
                )
           );

            expressionsToTest.Add(
               // This expression represents a lambda expression
               // that power of 4 to the parameter value.
               Expression.Block(
                    new [ ] { doubleVariable1 } , // Declare doubleVariable1 as a local variable
                    Expression.Assign(doubleVariable1 , doubleParameterExpression1) , // Initialize it
                    Expression.PowerAssign(doubleVariable1 , Expression.Constant(4d)) , // Perform the operation
                    doubleVariable1 // The last expression in the block is its return value
                )
           );

            expressionsToTest.ForEach(
                (expressionToTest) =>
                {
                    LambdaExpression lambdaExpression = Expression.Lambda(
                        expressionToTest ,
                        new List<ParameterExpression>() { intParameterExpression1 }
                    );
                    var delegateFunction = lambdaExpression.Compile();

                    Console.WriteLine("delegateFunction.DynamicInvoke({0}):{1}" , 2 , delegateFunction.DynamicInvoke(2));
                }
            );
        }

        /// <summary>
        /// illustrate how to use BinaryExpression to do bitwise or logical operations.  
        /// </summary>
        public static void TestMethod10()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression parameterExpression = Expression.Parameter(typeof(int) , "arg");

            ParameterExpression iParam = Expression.Parameter(typeof(int) , "i");
            ParameterExpression jParam = Expression.Parameter(typeof(int) , "j");
            ParameterExpression xParam = Expression.Parameter(typeof(int) , "x");

            MethodInfo writeLineMethod = typeof(Console).GetMethod("WriteLine" , new [ ] { typeof(string) });
            MethodInfo stringFormatMethod = typeof(string).GetMethod("Format" , new [ ] { typeof(string) , typeof(object) });

            Expression<Func<int , bool>> lambdaExpression1 = Expression.Lambda<Func<int , bool>>(
                    Expression.Block(
                        // Expression for Console.WriteLine($"i:{i}")
                        Expression.Call(
                            writeLineMethod ,
                            Expression.Call(
                                stringFormatMethod ,
                                Expression.Constant("i:{0}") ,
                                Expression.Convert(iParam , typeof(object)) // Convert int to object for string.Format
                            )
                        ) ,
                        // Expression for return i > 0; (the result of the block)
                        Expression.GreaterThan(iParam , Expression.Constant(0))
                    ),
                    iParam
            );

            Expression<Func<int , bool>> lambdaExpression2 = Expression.Lambda<Func<int , bool>>(
                    Expression.Block(
                        // Expression for Console.WriteLine($"j:{j}")
                        Expression.Call(
                            writeLineMethod ,
                            Expression.Call(
                                stringFormatMethod ,
                                Expression.Constant("j:{0}") ,
                                Expression.Convert(jParam , typeof(object)) // Convert int to object for string.Format
                            )
                        ) ,
                        // Expression for return j <= 0; (the result of the block)
                        Expression.LessThanOrEqual(jParam , Expression.Constant(0))
                    ) ,
                    jParam
            );

            // Prepare for Parameter Rebinding
            // We need to tell our rebinder to replace 'iParam' and 'jParam'
            // with the new 'xParam' in their respective bodies.
            var parameterMap = new Dictionary<ParameterExpression , ParameterExpression>
            {
                { lambdaExpression1.Parameters[0], xParam }, // Map iParam to xParam
                { lambdaExpression2.Parameters[0], xParam }  // Map jParam to xParam
            };

            // Parameter Rebinding
            var parameterRebinder = new ParameterRebinder(parameterMap);

            // Rebind the Bodies
            Expression body1Rebound = parameterRebinder.Visit(lambdaExpression1.Body);
            Expression body2Rebound = parameterRebinder.Visit(lambdaExpression2.Body);

            List<BinaryExpression> binaryExpressions = new List<BinaryExpression>();
            
            List<Expression<Func<int , bool>>> delegateExpressions = new List<Expression<Func<int , bool>>>();

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `AND` operation (without short circuit) to the parameter value.
                Expression.And(
                    parameterExpression ,
                    Expression.Constant(1)
                )
           );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `AND` operation (without short circuit) to the parameter value.
                Expression.AndAssign(
                    parameterExpression ,
                    Expression.Constant(2)
                )
           );


            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `OR` operation (without short circuit) to the parameter value.
                Expression.Or(
                    parameterExpression ,
                    Expression.Constant(1)
                )
           );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `OR` operation (without short circuit) to the parameter value.
                Expression.OrAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
           );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `XOR` operation (without short circuit) to the parameter value.
                Expression.ExclusiveOr(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `XOR` operation (without short circuit) to the parameter value.
                Expression.ExclusiveOrAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise left-shift operation (without short circuit) to the parameter value.
                Expression.LeftShift(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise left-shift operation (without short circuit) to the parameter value.
                Expression.LeftShiftAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise right-shift operation (without short circuit) to the parameter value.
                Expression.RightShift(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise right-shift operation (without short circuit) to the parameter value.
                Expression.RightShiftAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            delegateExpressions.Add(
                // This expression represents a lambda expression
                // that do logical `AND` operation (with short circuit) to the parameter value.
                Expression.Lambda<Func<int , bool>>(
                     Expression.AndAlso(
                        body1Rebound ,
                        body2Rebound
                     ) ,
                     xParam // The new lambda's single parameter
                )
           );

            delegateExpressions.Add(
                // This expression represents a lambda expression
                // that do logical `OR` operation (with short circuit) to the parameter value.
                Expression.Lambda<Func<int , bool>>(
                     Expression.OrElse(
                        body1Rebound ,
                        body2Rebound
                     ) ,
                     xParam // The new lambda's single parameter
                )
           );

            Console.WriteLine("About `binaryExpressions`");
            binaryExpressions.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                    LambdaExpression lambdaExpression = Expression.Lambda(
                                                            binaryExpression ,
                                                            new List<ParameterExpression>() { parameterExpression }
                                                        );
                    var compiledDelegateExpression = lambdaExpression.Compile();
                    Console.WriteLine("---- new round ----");
                    for(int i = -5; i <= 5; i++) 
                    { 
                        var result = compiledDelegateExpression.DynamicInvoke(i);                  
                        Console.WriteLine("compiledDelegateExpression.DynamicInvoke({0}):{1}",i,result);
                    }
                }
            );
            Console.WriteLine();

            Console.WriteLine("About `delegateExpressions`");
            delegateExpressions.ForEach(
               (delegateExpression) =>
               {
                   var compiledDelegateExpression =  delegateExpression.Compile();
                   Console.WriteLine("---- new round ----");
                   for(int i=-5;i<=5;i++) 
                   {
                       var result = compiledDelegateExpression.DynamicInvoke(i);
                       Console.WriteLine("compiledDelegateExpression.DynamicInvoke({0}):{1}" , i , result);
                   }
               }
           );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate bitwise or logical operation with `UnaryExpression`.
        /// </summary>
        public static void TestMethod11()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            int constant = 42;

            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise one's complementation (without short circuit) to the parameter value.
                Expression.OnesComplement(
                    Expression.Constant(constant)
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise two's complementation (without short circuit) to the parameter value.
                Expression.Not(
                    Expression.Constant(constant)
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do arithmetic negation operation (without short circuit) to the parameter value.
                Expression.Negate(
                    Expression.Constant(constant)
                )
            );

            Console.WriteLine("About `unaryExpressions`");
            unaryExpressions.ForEach(
                (unaryExpression) =>
                {
                    string infoText = unaryExpression.GetInfo();
                    Console.WriteLine(infoText);

                    LambdaExpression lambdaExpression = 
                        Expression.Lambda<Func<int>>(
                            unaryExpression
                        );

                    Console.WriteLine("executimg the expression`{0}` with argument `{1}` will get result `{2}`" ,lambdaExpression.ToString(),constant,lambdaExpression.Compile().DynamicInvoke());
                }
            );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate prefix/postfix increment/decrement operation.
        /// </summary>
        public static void TestMethod12()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression intParameterExpression1 = Expression.Parameter(typeof(int) , "x");

            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do prefix increment to the parameter value.
                Expression.PreIncrementAssign(
                    intParameterExpression1
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do postfix increment to the parameter value.
                Expression.PostIncrementAssign(
                    intParameterExpression1
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do prefix decrement to the parameter value.
                Expression.PreDecrementAssign(
                    intParameterExpression1
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do postfix decrement to the parameter value.
                Expression.PostDecrementAssign(
                    intParameterExpression1
                )
            );

            int counter = 0;
            Console.WriteLine("About `unaryExpressions`");
            unaryExpressions.ForEach(
                (unaryExpression) =>
                {
                    int constants = 10;
                    var lambdaExpression = Expression.Lambda<Func<int , int>>(unaryExpression , intParameterExpression1);
                    Console.WriteLine("---- In {0}th round ----",counter);
                    string infoText = unaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                    Console.WriteLine();
                    Console.WriteLine("Compile the expression:`{0}`, then execute it with argument value `{1}` will gets `{2}`.", lambdaExpression.ToString(),constants,lambdaExpression.Compile()(constants));
                    Console.WriteLine("---- End of {0}th round ----" , counter);
                    counter++;
                }
            );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate how to compare two expression with data type `System.Int32`.
        /// </summary>
        public static void TestMethod13()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ExpressionsOutput.CompareExpressionAndOutput(40,40);
            ExpressionsOutput.CompareExpressionAndOutput(45,42);
            ExpressionsOutput.CompareExpressionAndOutput(42,45);
        }

        /// <summary>
        /// illustrate how to create an expression about a condition.
        /// </summary>
        public static void TestMethod14()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string [ ] textArray = new string [ ]
            {
                string.Empty,
                "Cat",
                "CatShabo",
                "Spy x family",
                "PurismMagica"
            };

            ParameterExpression parameterExpression = Expression.Parameter(typeof(string) , "arg");

            Expression<Func<string , string>> capatalize = text => text.ToUpper();
            Expression<Func<string , string>> uncapatalize = text => text.ToLower();

            Expression<Func<string , bool>> startWithCatLambda = text => string.IsNullOrEmpty(text)== false && text.StartsWith("Cat") ;

            List<ConditionalExpression> conditionalExpressions = new List<ConditionalExpression>();

            // To use startWithCatLambda as the condition, we need to apply it to our 'arg' parameter.
            // We do this by invoking its body with the 'arg' parameter.

            // 1. Get the body of the startWithCatLambda
            Expression conditionBody = startWithCatLambda.Body;

            // 2. Identify the parameter of the startWithCatLambda (the 'text' in text => ...)
            ParameterExpression startWithCatParameter = startWithCatLambda.Parameters [0];

            // 3. Create a parameter replacer visitor to replace 'text' with 'arg' in the condition body
            ParameterReplacer visitor = new ParameterReplacer(startWithCatParameter, parameterExpression);
            Expression actualCondition = visitor.Visit(conditionBody);

            // --- "True" Part (IfTrue) ---
            // 1. Get the body of the capatalize lambda
            Expression capatalizeBody = capatalize.Body;

            // 2. Identify the parameter of the capatalize lambda
            ParameterExpression capatalizeParameter = capatalize.Parameters [ 0 ];

            // 3. Create a parameter replacer for the capatalize body
            ParameterReplacer capatalizeVisitor = new ParameterReplacer(capatalizeParameter , parameterExpression);
            Expression actualCapatalizeBody = capatalizeVisitor.Visit(capatalizeBody);

            // --- "False" Part (IfFalse) ---
            // 1. Get the body of the uncapatalize lambda
            Expression uncapatalizeBody = uncapatalize.Body;

            // 2. Identify the parameter of the uncapatalize lambda
            ParameterExpression uncapatalizeParameter = uncapatalize.Parameters [ 0 ];

            // 3. Create a parameter replacer for the uncapatalize body
            ParameterReplacer uncapatalizeVisitor = new ParameterReplacer(uncapatalizeParameter , parameterExpression);
            Expression actualUncapatalizeBody = uncapatalizeVisitor.Visit(uncapatalizeBody);

            conditionalExpressions.Add(
                Expression.Condition(
                    actualCondition ,
                    actualCapatalizeBody ,  // Use the transformed body
                    actualUncapatalizeBody // Use the transformed body
                )
           );

            
            conditionalExpressions.ForEach(
                (conditionalExpression) =>
                {
                    LambdaExpression lambdaExpression = Expression.Lambda(
                        conditionalExpression,
                        new List<ParameterExpression>() { parameterExpression }
                    );
                    var delegateFunction = lambdaExpression.Compile();

                    foreach(string text in textArray)
                    {
                        Console.WriteLine("delegateFunction.DynamicInvoke({0}):{1}" , text , delegateFunction.DynamicInvoke(text));
                    }
                }
            );
        }

        /// <summary>
        /// illustrate writing data about expression info as debug info with `DebugInfoGenerator` in `NLog` third package. 
        /// </summary>
        public static void TestMethod15()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            DebugInfoGenerator debugInfoGenerator = new DebugErrorInfoGenerator();

            ParameterExpression parameterExpression = Expression.Parameter(typeof(int) , "arg");

            // This expression represents a lambda expression
            // that adds 1 to the parameter value.
            LambdaExpression lambdaExpression = Expression.Lambda(
                Expression.Add(
                    parameterExpression ,
                    Expression.Constant(1)
                ) ,
                new List<ParameterExpression>() { parameterExpression }
            );

            string sourceFileFullPath = $@"/AppData/User.cs";
            SymbolDocumentInfo document = Expression.SymbolDocument(sourceFileFullPath);

            DebugInfoExpression debugInfoExpression = Expression.DebugInfo(
                document: document ,
                startLine: 5 ,
                startColumn: 1 ,
                endLine: 5 ,
                endColumn: 10
            );

            debugInfoGenerator.MarkSequencePoint(lambdaExpression , 0 , debugInfoExpression);
        }
    }
}

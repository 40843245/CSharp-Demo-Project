﻿using System.Linq.Expressions;
using System.Text;

namespace Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods
{
    public static class BinaryExpressionsExtensionMethods
    {
        public static string GetInfo(
            this BinaryExpression binaryExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("binaryExpression.Left:{0}\n" , binaryExpression.Left);
            stringBuilder.AppendFormat("binaryExpression.Right:{0}\n" , binaryExpression.Right);
            stringBuilder.AppendFormat("binaryExpression.IsLifted:{0}\n" , binaryExpression.IsLifted);
            stringBuilder.AppendFormat("binaryExpression.IsLiftedToNull:{0}\n" , binaryExpression.IsLiftedToNull);
            return stringBuilder.ToString();
        }
    }

    public static class UnaryExpressionsExtensionMethods
    {
        public static string GetInfo(
            this UnaryExpression unaryExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("unaryExpression.IsLifted:{0}\n" , unaryExpression.IsLifted);
            stringBuilder.AppendFormat("unaryExpression.IsLiftedToNull:{0}\n" , unaryExpression.IsLiftedToNull);
            stringBuilder.AppendFormat("unaryExpression.Operand:{0}\n" , unaryExpression.Operand);
            return stringBuilder.ToString();
        }
    }

    public static class ConditionalExpressionsExtensionMethods
    {
        public static string GetInfo(
            this ConditionalExpression conditionalExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("conditionalExpression.Test:{0}\n" , conditionalExpression.Test);
            stringBuilder.AppendFormat("conditionalExpression.IfTrue:{0}\n" , conditionalExpression.IfTrue);
            stringBuilder.AppendFormat("conditionalExpression.IfFalse:{0}\n" , conditionalExpression.IfFalse);
            return stringBuilder.ToString();
        }
    }
}

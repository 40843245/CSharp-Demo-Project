﻿using System;
using System.Linq.Expressions;

namespace Example.Utilities.Expressions
{
    public static class ExpressionsOutput
    {
        public static void CompareExpressionAndOutput(
            int leftValue,
            int rightValue
        )
        {
            Expression expressionConstantLeftValue = Expression.Constant(leftValue);
            Expression expressionConstantRightValue = Expression.Constant(rightValue);
            
            BinaryExpression equalExpression = Expression.Equal(
                expressionConstantLeftValue ,
                expressionConstantRightValue
            );

            BinaryExpression notEqualExpression = Expression.NotEqual(
                expressionConstantLeftValue ,
                expressionConstantRightValue
            );

            BinaryExpression lessThanExpression = Expression.LessThan(
                expressionConstantLeftValue ,
                expressionConstantRightValue
            );

            BinaryExpression lessThanOrEqualToExpression = Expression.LessThanOrEqual(
                expressionConstantLeftValue ,
                expressionConstantRightValue
            );

            BinaryExpression greaterThanExpression = Expression.GreaterThan(
                expressionConstantLeftValue ,
                expressionConstantRightValue
            );


            BinaryExpression greaterThanOrEqualToExpression = Expression.GreaterThanOrEqual(
                expressionConstantLeftValue ,
                expressionConstantRightValue
            );

            Console.WriteLine("Let's compare {0} and {1}",leftValue,rightValue);
            // The following statement first creates an expression tree,
            // then compiles it, and then executes it.
            Console.WriteLine("Is {0} equal to {1}? {2}" , leftValue , rightValue , Expression.Lambda<Func<bool>>(equalExpression).Compile()());

            Console.WriteLine("Is {0} not equal to {1}? {2}" , leftValue , rightValue , Expression.Lambda<Func<bool>>(notEqualExpression).Compile()());

            Console.WriteLine("Is {0} less than {1}? {2}" , leftValue , rightValue , Expression.Lambda<Func<bool>>(lessThanExpression).Compile()());

            Console.WriteLine("Is {0} less than or equal to {1}? {2}" , leftValue , rightValue , Expression.Lambda<Func<bool>>(lessThanOrEqualToExpression).Compile()());

            Console.WriteLine("Is {0} greater than {1}? {2}" , leftValue , rightValue , Expression.Lambda<Func<bool>>(greaterThanExpression).Compile()());

            Console.WriteLine("Is {0} greater than or equal to {1}? {2}" , leftValue , rightValue , Expression.Lambda<Func<bool>>(greaterThanExpression).Compile()());

            Console.WriteLine();
        }
    }
}

﻿using System;

namespace Example.Utilities.Equals
{
    public static class EqualMessageOutput
    {
        public static void PrintInfo(
            object object1, 
            object object2,
            string objectTypeName
        )
        {
            bool isEqual = object.Equals(object1 , object2);
            bool isReferentiallyEqual = object.ReferenceEquals(object1 , object2);
            Console.WriteLine($"Are these {objectTypeName}s equal? {isEqual}");

            Console.WriteLine($"Are these {objectTypeName}s referentially equal? {isReferentiallyEqual}");
        }
    }
}

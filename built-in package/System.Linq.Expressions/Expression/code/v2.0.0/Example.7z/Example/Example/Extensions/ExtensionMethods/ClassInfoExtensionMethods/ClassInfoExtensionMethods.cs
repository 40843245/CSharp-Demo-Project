﻿using System.Reflection;
using System.Text;

namespace Example.Extensions.ExtensionMethods.ClassInfoExtensionMethods
{
    public static class MethodInfoExtensionMethods
    {
        public static string GetInfo(
            this MethodInfo methodInfo
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            MethodAttributes methodAttributes = methodInfo.Attributes;

            stringBuilder.AppendLine("Info about it's attributes:");
            stringBuilder.Append(methodAttributes.GetInfo());
            stringBuilder.AppendFormat("Name:{0}\n" , methodInfo.Name);

            return stringBuilder.ToString();
        }
    }

    public static class MethodAttributesExtensionMethods
    {
        public static string GetInfo(
            this MethodAttributes methodAttributes
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("The type of attribute:{0}\n",methodAttributes.GetType().Name);
            return stringBuilder.ToString();
        }
    }

    public static class MemberInfoExtensionMethods 
    {
        public static string GetInfo
        (
          this MemberInfo memberInfo
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("Name:{0}\n" , memberInfo.Name);

            return stringBuilder.ToString();
        }
    }

}

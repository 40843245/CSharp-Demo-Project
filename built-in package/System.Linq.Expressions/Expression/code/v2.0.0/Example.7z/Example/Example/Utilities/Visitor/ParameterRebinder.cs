﻿using System.Collections.Generic;
using System.Linq.Expressions;

namespace Example.Utilities.Visitor
{
    public class ParameterRebinder : ExpressionVisitor
    {
        private readonly Dictionary<ParameterExpression , ParameterExpression> _map;

        public ParameterRebinder(Dictionary<ParameterExpression , ParameterExpression> map)
        {
            _map = map ?? new Dictionary<ParameterExpression , ParameterExpression>();
        }

        // This method is called for each ParameterExpression encountered during the visit.
        protected override Expression VisitParameter(ParameterExpression p)
        {
            // If the parameter is in our map, return its replacement.
            if(_map.TryGetValue(p , out ParameterExpression replacement))
            {
                return replacement;
            }
            // Otherwise, return the original parameter.
            return base.VisitParameter(p);
        }
    }
}

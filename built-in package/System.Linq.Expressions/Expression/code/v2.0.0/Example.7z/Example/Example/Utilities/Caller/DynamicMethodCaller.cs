﻿namespace Example.Utilities.Caller
{
    public class DynamicMethodCaller
    {
        public string Greet(
            string name
        )
        {
            return $"Hello, {name}!";
        }
    }
}

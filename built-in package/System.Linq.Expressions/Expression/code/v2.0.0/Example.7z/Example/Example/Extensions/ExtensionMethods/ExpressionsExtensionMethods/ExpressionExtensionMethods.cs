﻿using Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using static Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods.HighOrderFunctionsExtensionMethods;

using static Example.Extensions.ExtensionMethods.ClassInfoExtensionMethods.MethodInfoExtensionMethods;

using static Example.Extensions.ExtensionMethods.ClassInfoExtensionMethods.MemberInfoExtensionMethods;

using System.Reflection;

namespace Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods
{
    public static class ExpressionsExtensionMethods
    {
        public static string GetSimpleInfo(
            this Expression expression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine(expression.Type.ToString());
            stringBuilder.AppendLine(expression.NodeType.ToString());
            stringBuilder.AppendLine(expression.CanReduce.ToString());
            return stringBuilder.ToString();
        }
    }

    public static class InvocationExpressionExtensionMethods
    {
        public static string GetInfo(
            this InvocationExpression invocationExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            List<string> textList = new List<string>();
            string formattingString = "{0}th {1}:{2}";
            int counter = 0;

            var arguments = invocationExpression.Arguments;

            counter = 0;
            textList = arguments.Apply<Expression , string>(
                argument =>
                {
                    var result = 
                        string.Format(
                            formattingString,
                            counter,
                            "argument",
                            argument.GetSimpleInfo()
                        );
                    counter++;
                    return result;
                }
            );
            stringBuilder.AppendLine(invocationExpression.ToString());
            stringBuilder.AppendFormat("Expression that are applied:\n{0}\n",invocationExpression.Expression.GetSimpleInfo());
            stringBuilder.AppendFormat("There are {0} arguments.\n",arguments.Count);
            stringBuilder.Append(string.Join(System.Environment.NewLine,textList));
            stringBuilder.Append(arguments.Count > 0 ? System.Environment.NewLine : string.Empty);
            stringBuilder.AppendLine(invocationExpression.CanReduce.ToString());
            return stringBuilder.ToString();
        }
    }
    public static class BinaryExpressionsExtensionMethods
    {
        public static string GetInfo(
            this BinaryExpression binaryExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("binaryExpression.Left:{0}\n" , binaryExpression.Left);
            stringBuilder.AppendFormat("binaryExpression.Right:{0}\n" , binaryExpression.Right);
            stringBuilder.AppendFormat("binaryExpression.IsLifted:{0}\n" , binaryExpression.IsLifted);
            stringBuilder.AppendFormat("binaryExpression.IsLiftedToNull:{0}\n" , binaryExpression.IsLiftedToNull);
            return stringBuilder.ToString();
        }
    }

    public static class UnaryExpressionsExtensionMethods
    {
        public static string GetInfo(
            this UnaryExpression unaryExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("unaryExpression.IsLifted:{0}\n" , unaryExpression.IsLifted);
            stringBuilder.AppendFormat("unaryExpression.IsLiftedToNull:{0}\n" , unaryExpression.IsLiftedToNull);
            stringBuilder.AppendFormat("unaryExpression.Operand:{0}\n" , unaryExpression.Operand);
            return stringBuilder.ToString();
        }
    }

    public static class ConditionalExpressionsExtensionMethods
    {
        public static string GetInfo(
            this ConditionalExpression conditionalExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("conditionalExpression.Test:{0}\n" , conditionalExpression.Test);
            stringBuilder.AppendFormat("conditionalExpression.IfTrue:{0}\n" , conditionalExpression.IfTrue);
            stringBuilder.AppendFormat("conditionalExpression.IfFalse:{0}\n" , conditionalExpression.IfFalse);
            return stringBuilder.ToString();
        }
    }

    public static class BlockExpressionsExtensionMethods
    {
        public static string GetInfo(
            this BlockExpression blockExpression
        )
        {
            StringBuilder stringBuilder = new StringBuilder();
            List<string> textList = new List<string>();
            string formattingString = "{0}th {1}:`{2}`";
            int counter = 0;
            var variables = blockExpression.Variables;
            var expressions = blockExpression.Expressions;

            counter = 0;
            textList = variables.Apply<ParameterExpression , string>(
                variable =>
                {
                    var result = string.Format(formattingString , counter , "variable" , variable.ToString());
                    counter++;
                    return result;
                }
            );
            stringBuilder.Append(string.Join(System.Environment.NewLine , textList));

            counter = 0;
            textList = expressions.Apply<Expression , string>(
                expression =>
                {
                    var result = string.Format(formattingString , counter , "expression" , expression.ToString());
                    counter++;
                    return result;
                }
            );
            stringBuilder.Append(string.Join(System.Environment.NewLine,textList));

            
            stringBuilder.AppendFormat("{0}\n" , blockExpression.ToString());
            return stringBuilder.ToString();
        }
    }

    public static class DefaultExpressionsExtensionMethods
    {
        public static string GetInfo<TDefaultExpression>(
            this DefaultExpression defaultExpression
        )
        {
            var compiledDelegateFunction = Expression.Lambda<Func<TDefaultExpression>>(defaultExpression).Compile(); // TDefaultExpression MUST be primitive data, otherwise, it will throw an exception at runtime.
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("{0}\n" , defaultExpression.ToString());
            stringBuilder.AppendFormat("{0}\n" , compiledDelegateFunction()); 
            return stringBuilder.ToString();
        }
    }

    public static class CatchBlocksExtensionMethods
    {
        public static string GetSimpleInfo(
            this CatchBlock catchBlock
        )
        {
            var compiledDelegateFunction = Expression.Lambda<Func<object>>(catchBlock.Body).Compile();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine(catchBlock.Test.Name);
            stringBuilder.AppendLine(compiledDelegateFunction.ToString());
            return stringBuilder.ToString();
        }
    }

    public static class TryCatchExpressionsExtensionMethods
    {
        public static string GetInfo(
            this TryExpression tryExpression
        )
        {
            var handlers = tryExpression.Handlers;
            var compiledDelegateFunction = Expression.Lambda<Func<string>>(tryExpression).Compile();
            StringBuilder stringBuilder = new StringBuilder();

            List<string> textList = new List<string>();
            string formattingString = "{0}th {1}:{2}";
            int counter = 0;

            counter = 0;
            textList = handlers.Apply<CatchBlock , string>(
                handler =>
                {
                    var result = string.Format(formattingString , counter , "handler" , handler?.GetSimpleInfo());
                    counter++;
                    return result;
                }
            );
            
            stringBuilder.AppendFormat("{0}\n" , tryExpression.ToString());
            stringBuilder.AppendFormat("Body:{0}\n" , tryExpression.Body.GetSimpleInfo());
            stringBuilder.AppendFormat("Its Fault:{0}\n" , tryExpression.Fault?.GetSimpleInfo());
            stringBuilder.AppendFormat("It has {0} handlers.\n",handlers.Count);
            stringBuilder.Append(string.Join(System.Environment.NewLine , textList));
            stringBuilder.Append(handlers.Count > 0 ? System.Environment.NewLine : string.Empty);
            stringBuilder.AppendFormat("Finally Block:{0}\n" , tryExpression.Finally?.GetSimpleInfo());
            stringBuilder.AppendLine("After executing the compiled delegate function,");
            stringBuilder.AppendFormat("{0}\n" , compiledDelegateFunction.Invoke());
            return stringBuilder.ToString();
        }
    }

    public static class MemberExpressionsExtensionMethods 
    {
        public static string GetInfo(
            this MemberExpression memberExpression    
        )
        {
            StringBuilder stringBuilder = new StringBuilder();

            Expression expression = memberExpression.Expression;
            MemberInfo memberInfo = memberExpression.Member;

            stringBuilder.AppendFormat("Expression:{0}\n" , expression.ToString());
            stringBuilder.AppendLine("Info about the member:");
            stringBuilder.Append(memberInfo.GetInfo());

            return stringBuilder.ToString();
        }
    }
}

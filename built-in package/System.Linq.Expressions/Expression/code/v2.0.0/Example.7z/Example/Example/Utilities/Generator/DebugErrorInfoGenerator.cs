﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using static Example.Extensions.ExtensionMethods.HighOrderFunctionsExtensionMethods.HighOrderFunctionsExtensionMethods;

namespace Example.Utilities.Generator
{
    public class DebugErrorInfoGenerator : DebugInfoGenerator
    {
        private static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();

        public string Message { get; set; } = string.Empty;

        public override void MarkSequencePoint(
            LambdaExpression lambdaExpression, 
            int ilOffset , 
            DebugInfoExpression sequencePoint
        )
        {
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                string stringFromstringBuilder = string.Empty;
                List<string> textList = new List<string>();
                string text = string.Empty;
                int counter = 0;
                var formattingString = "{0}th parameter: {1}";

                var parameters = lambdaExpression.Parameters;
                textList = parameters.Apply(
                  (parameter) => {
                      counter++;
                      var result = string.Format(formattingString, counter, parameter.ToString());
                      return result;
                  }
                );

                text = string.Join(System.Environment.NewLine,textList);

                stringBuilder.Append(text);

                text = string.Empty;
                textList.Clear();
                counter = 0;
                formattingString = "lambdaExpression.ReturnType.FullName: {0}";

                text = string.Format(formattingString,lambdaExpression.ReturnType.FullName);

                stringBuilder.Append(text);

                stringFromstringBuilder = stringBuilder.ToString();
                Message = stringFromstringBuilder;    
            }
            catch(Exception ex)
            {
                Logger.Error(ex , "Goodbye cruel world");
            }
        }

        public void LoggerInfo()
        {
            Logger.Info(Message);
        }

        public void LoggerError()
        {
            Logger.Error(Message);
        }

        public void Clear()
        {
            Message = string.Empty;
        }
    }
}

﻿using System.Linq.Expressions;
using System.Text;

namespace Example.Utilities.Visitor
{
    public class ExpressionLogger : ExpressionVisitor
    {
        private StringBuilder _log = new StringBuilder();
        private int _indentationLevel = 0;

        private void Indent() => _indentationLevel++;
        private void Unindent() => _indentationLevel--;
        private void AppendLine(string message) => _log.AppendLine($"{new string(' ' , _indentationLevel * 2)}{message}");

        public string Log => _log.ToString();

        // Override methods for specific expression types you want to visit
        protected override Expression VisitBinary(BinaryExpression node)
        {
            AppendLine($"Visiting BinaryExpression: NodeType = {node.NodeType}");
            Indent();
            AppendLine($"Left:");
            Visit(node.Left); // Recursively visit the left operand
            AppendLine($"Right:");
            Visit(node.Right); // Recursively visit the right operand
            Unindent();
            return node; // Return the original node or a modified one
        }

        protected override Expression VisitConstant(ConstantExpression node)
        {
            AppendLine($"Visiting ConstantExpression: Value = {node.Value}, Type = {node.Type}");
            return node;
        }

        protected override Expression VisitParameter(ParameterExpression node)
        {
            AppendLine($"Visiting ParameterExpression: Name = {node.Name}, Type = {node.Type}");
            return node;
        }

        protected override Expression VisitLambda<T>(Expression<T> node)
        {
            AppendLine($"Visiting LambdaExpression: Parameters = {string.Join(", " , node.Parameters)}, ReturnType = {node.ReturnType}");
            Indent();
            AppendLine($"Body:");
            Visit(node.Body); // Visit the body of the lambda
            Unindent();
            return node;
        }

        protected override Expression VisitMethodCall(MethodCallExpression node)
        {
            AppendLine($"Visiting MethodCallExpression: Method = {node.Method.Name}");
            Indent();
            if(node.Object != null)
            {
                AppendLine("Object:");
                Visit(node.Object);
            }
            if(node.Arguments.Count > 0)
            {
                AppendLine("Arguments:");
                foreach(var arg in node.Arguments)
                {
                    Visit(arg);
                }
            }
            Unindent();
            return node;
        }
    }
}

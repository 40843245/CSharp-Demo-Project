﻿namespace Example.Globals.GlobalsFullPath
{
    public static class GlobalsFileFullPath
    {
        public static readonly string NLOG_FILE_FULL_PATH = $@"/AppData/log.txt"; 
    }
}

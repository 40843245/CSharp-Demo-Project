﻿using System;
using System.Linq.Expressions;

namespace Example.Utilities.Expressions
{
    public class PostIncrementExpression : Expression
    {
        public new ParameterExpression Variable { get; }
        //public ParameterExpression Variable { get; }

        public PostIncrementExpression(ParameterExpression variable)
        {
            Variable = variable;
        }

        public override ExpressionType NodeType => Variable.NodeType; 
        public override Type Type => Variable.Type;

        public override bool CanReduce => Variable.CanReduce;

        public override Expression Reduce()
        {
            // 1. Create a temporary variable to store the original value
            ParameterExpression temp = Expression.Variable(Variable.Type , "temp");

            // 2. Create the block expression
            return Expression.Block(
                new [ ] { temp } , // Declare the temporary variable
                Expression.Assign(temp , Variable) , // Assign current 'x' to 'temp'
                Expression.Assign(Variable , Expression.Add(Variable , Expression.Constant(1))) , // x = x + 1
                temp // The result of the expression is the original value of x (stored in temp)
            );
        }
    }
}

﻿using Example.Utilities.Equals;
using Example.Utilities.Generator;
using Example.Utilities.Visitor;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using Example.Utilities.Expressions;

using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.BinaryExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.UnaryExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.ConditionalExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.DefaultExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.BlockExpressionsExtensionMethods;
using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.TryCatchExpressionsExtensionMethods;

using static Example.Extensions.ExtensionMethods.ExpressionsExtensionMethods.InvocationExpressionExtensionMethods;

using Example.AppData;
using Example.Utilities.Caller;
using Microsoft.CSharp.RuntimeBinder;
using Binder = Microsoft.CSharp.RuntimeBinder.Binder;
using Example.Bean;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Func<int , bool> delegateFunction1 = i => i < 5; // a delegate function.
           
            for(int i = 0; i < 10;i++) 
            {
                Console.WriteLine("delegateFunction1({0}) = {1}" , i , delegateFunction1(i));
            }

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.
            Func<int , bool> delegateFunction2 = expression1.Compile(); // compile it, making it as an delegate function.

            Console.WriteLine();
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("delegateFunction2({0}) = {1}" , i , delegateFunction2(i));
            }
        }

        /// <summary>
        /// Compare two delegate function are referentially equal.
        /// 
        /// First delegate function is directly initialized.
        /// 
        /// While, second delegate function is made from an expression in form of an expression tree.
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression parameterExpression = Expression.Parameter(typeof(bool) , "result");

            Func<int , bool> delegateFunction1 = i => i < 5; // a delegate function.

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.
            Func<int , bool> delegateFunction1FromExpression1 = expression1.Compile(); // compile it, making it as an delegate function.

            Func<int , bool> delegateFunction2 = i => i < 5; // a delegate function.

            Func<int , bool> delegateFunction2FromExpression1 = expression1.Compile(); // compile it, making it as an delegate function.

            Expression<Func<int , bool>> expression2 = i => i < 5; // represents a delegate function in form of an expression tree.
            Func<int , bool> delegateFunction1FromExpression2 = expression2.Compile(); // compile it, making it as an delegate function.

            Func<int , bool> delegateFunction2FromExpression2 = expression2.Compile(); // compile it, making it as an delegate function.

            int counter = 1;

            Console.WriteLine("In {0}th comparison" , counter);
            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction2 ,
                "delegate function"
            );
            counter++;

            Console.WriteLine("In {0}th comparison",counter);
            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction1FromExpression1 ,
                "delegate function"
            );
            counter++;

            Console.WriteLine("In {0}th comparison" , counter);
            EqualMessageOutput.PrintInfo(
                delegateFunction1FromExpression1 ,
                delegateFunction2FromExpression1 ,
                "delegate function"
            );
            counter++;

            List<BinaryExpression> binaryExpressionForReferenceEqual = new List<BinaryExpression>();

            List<BinaryExpression> binaryExpressionForReferenceNotEqual = new List<BinaryExpression>();

            binaryExpressionForReferenceEqual.Add(Expression.ReferenceEqual(expression1,expression2));

            binaryExpressionForReferenceNotEqual.Add(Expression.ReferenceNotEqual(expression1,expression2));

            Console.WriteLine("About `binaryExpressionForReferenceEqual`");
            binaryExpressionForReferenceEqual.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);   
                }
            );
            Console.WriteLine();

            Console.WriteLine("About `binaryExpressionForReferenceNotEqual`");
            binaryExpressionForReferenceNotEqual.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                }
            );
            Console.WriteLine();

        }

        

        /// <summary>
        /// Compare two delegate function are referentially equal.
        /// 
        /// First delegate function and second delegate function is made from an expression in form of an expression tree. But made with different `Compile` instance method call. 
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.

            Func<int , bool> delegateFunction1 = expression1.Compile(); // compile it, making it as an delegate function.
            Func<int , bool> delegateFunction2 = expression1.Compile(); // compile it, making it as an delegate function.

            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction2 ,
                "delegate function"
            );
        }      

        /// <summary>
        /// Compare two delegate function are referentially equal.
        /// 
        /// First delegate function and second delegate function is made from an expression in form of an expression tree. But made with different `Compile` instance method call. 
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.

            Func<int , bool> delegateFunction1 = expression1.Compile(false); // not compile it, using other way to make it as an delegate function.
            Func<int , bool> delegateFunction2 = expression1.Compile(false); // not compile it, using other way to make it as an delegate function.

            EqualMessageOutput.PrintInfo(
                delegateFunction1,
                delegateFunction2,
                "delegate function"
            );
        }

        /// <summary>
        /// referentially equal check
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression<Func<int , bool>> expression1 = i => i < 5; // represents a delegate function in form of an expression tree.

            Func<int , bool> delegateFunction1 = expression1.Compile(false); // compile it, making it as an delegate function.
            Func<int , bool> delegateFunction2 = delegateFunction1; // points to first delegate function,

            EqualMessageOutput.PrintInfo(
                delegateFunction1 ,
                delegateFunction2 ,
                "delegate function"
            );
        }

        /// <summary>
        /// illustrate to check the `Expression` with boolean data type is true or false.
        /// </summary>
        public static void TestMethod6()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Expression expressionConstantTrue = Expression.Constant(true);
            Expression expressionConstantFalse = Expression.Constant(false);

            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                Expression.IsTrue(
                    expressionConstantTrue
                )
            );

            unaryExpressions.Add(
                Expression.IsTrue(
                    expressionConstantFalse
                )
            );

            unaryExpressions.Add(
                Expression.IsFalse(
                    expressionConstantTrue
                )
            );

            unaryExpressions.Add(
                Expression.IsFalse(
                    expressionConstantFalse
                )
            );

            unaryExpressions.ForEach(
                (unaryExpression) => 
                {
                    string infoText = unaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                }
            );
        }

        /// <summary>
        /// illustrate to check given string that start with `Cat`. 
        /// </summary>
        public static void TestMethod7()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression textParam = Expression.Parameter(typeof(string) , "text");

            Expression startWithCatExpression = Expression.Constant("start with cat");
            Expression notStartWithCatExpression = Expression.Constant("not start with cat");


            MethodInfo isNullOrEmptyMethod = typeof(string).GetMethod("IsNullOrEmpty" , new [ ] { typeof(string) });
            MethodInfo startsWithMethod = typeof(string).GetMethod("StartsWith" , new [ ] { typeof(string) });


            Expression startWithCatCondition = Expression.AndAlso(
                Expression.Not(Expression.Call(isNullOrEmptyMethod , textParam)) , 
                Expression.Call(textParam , startsWithMethod , Expression.Constant("Cat"))
            );

            List<ConditionalExpression> conditionalExpressions = new List<ConditionalExpression>();

            string [ ] textArray = new string [ ]
            {
                string.Empty,
                "Cat",
                "CatShabo",
                "Spy x family",
                "PurismMagica"
            };

            conditionalExpressions.Add(
                Expression.IfThen(
                    startWithCatCondition,
                    startWithCatExpression
                )
            );

            conditionalExpressions.Add(
                Expression.IfThenElse(
                    startWithCatCondition ,
                    startWithCatExpression,
                    notStartWithCatExpression
                )
           );


            conditionalExpressions.ForEach(
                (conditionalExpression) =>
                {
                    string infoText = conditionalExpression.GetInfo();
                    Console.WriteLine(infoText);
                    Console.WriteLine();

                    LambdaExpression lambdaExpression = Expression.Lambda(
                                                conditionalExpression ,
                                                new List<ParameterExpression>() { textParam }
                                            );

                    var delegateFunction = lambdaExpression.Compile();
                    Console.WriteLine("---- new round ----");
                    foreach(string text in textArray)
                    {
                        Console.WriteLine("delegateFunction.DynamicInvoke({0}):{1}" , text , delegateFunction.DynamicInvoke(text));
                    }
                }
            );
        }

        /// <summary>
        /// illustrate assignment operations.  
        /// </summary>
        public static void TestMethod8()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            List<BinaryExpression> binaryExpressions = new List<BinaryExpression>();

            binaryExpressions.Add(
                Expression.Assign(
                    Expression.Variable(typeof(int) , "x") ,
                    Expression.Constant(42)
                )
            );

            Console.WriteLine("About `binaryExpressions`");
            binaryExpressions.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                }
            );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate mathematically operations.  
        /// </summary>
        public static void TestMethod9()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression intParameterExpression1 = Expression.Parameter(typeof(int) , "arg");
            UnaryExpression doubleParameterExpression1 = Expression.Convert(intParameterExpression1 , typeof(double));

            ParameterExpression doubleParameterExpression2 = Expression.Parameter(typeof(double) , "arg");

            ParameterExpression intVariable1 = Expression.Variable(typeof(int) , "returnValue");
            ParameterExpression doubleVariable1 = Expression.Variable(typeof(double) , "returnValue");

            List<Expression> expressionsToTest = new List<Expression>();
            
            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that add 1 to the parameter value.
                Expression.Add(
                    intParameterExpression1 ,
                    Expression.Constant(1)
                )
           );

            expressionsToTest.Add(
               // This expression represents a lambda expression
               // that add 1 to the parameter value.
               Expression.AddAssign(
                   intParameterExpression1 ,
                   Expression.Constant(1)
               )
          );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that subtract 1 to the parameter value.
                Expression.Subtract(
                    intParameterExpression1 ,
                    Expression.Constant(1)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that subtract 1 to the parameter value.
                Expression.SubtractAssign(
                    intParameterExpression1 ,
                    Expression.Constant(1)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that mutliply by 2 to the parameter value.
                Expression.Multiply(
                    intParameterExpression1 ,
                    Expression.Constant(2)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that mutliply by 2 to the parameter value.
                Expression.MultiplyAssign(
                    intParameterExpression1 ,
                    Expression.Constant(2)
                )
           );


            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that divided by 5 to the parameter value.
                Expression.Divide(
                    intParameterExpression1 ,
                    Expression.Constant(5)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that divided by 5 to the parameter value.
                Expression.DivideAssign(
                    intParameterExpression1 ,
                    Expression.Constant(5)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that modulo 4 to the parameter value.
                Expression.Modulo(
                    intParameterExpression1 ,
                    Expression.Constant(4)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that modulo 4 to the parameter value.
                Expression.ModuloAssign(
                    intParameterExpression1 ,
                    Expression.Constant(4)
                )
           );

            expressionsToTest.Add(
                // This expression represents a lambda expression
                // that power of 4 to the parameter value.
                Expression.Power(
                    doubleParameterExpression1 ,
                    Expression.Constant(4d)
                )
           );

            expressionsToTest.Add(
               // This expression represents a lambda expression
               // that power of 4 to the parameter value.
               Expression.Block(
                    new [ ] { doubleVariable1 } , // Declare doubleVariable1 as a local variable
                    Expression.Assign(doubleVariable1 , doubleParameterExpression1) , // Initialize it
                    Expression.PowerAssign(doubleVariable1 , Expression.Constant(4d)) , // Perform the operation
                    doubleVariable1 // The last expression in the block is its return value
                )
           );

            expressionsToTest.ForEach(
                (expressionToTest) =>
                {
                    LambdaExpression lambdaExpression = Expression.Lambda(
                        expressionToTest ,
                        new List<ParameterExpression>() { intParameterExpression1 }
                    );
                    var delegateFunction = lambdaExpression.Compile();

                    Console.WriteLine("delegateFunction.DynamicInvoke({0}):{1}" , 2 , delegateFunction.DynamicInvoke(2));
                }
            );
        }

        /// <summary>
        /// illustrate how to use BinaryExpression to do bitwise or logical operations.  
        /// </summary>
        public static void TestMethod10()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression parameterExpression = Expression.Parameter(typeof(int) , "arg");

            ParameterExpression iParam = Expression.Parameter(typeof(int) , "i");
            ParameterExpression jParam = Expression.Parameter(typeof(int) , "j");
            ParameterExpression xParam = Expression.Parameter(typeof(int) , "x");

            MethodInfo writeLineMethod = typeof(Console).GetMethod("WriteLine" , new [ ] { typeof(string) });
            MethodInfo stringFormatMethod = typeof(string).GetMethod("Format" , new [ ] { typeof(string) , typeof(object) });

            Expression<Func<int , bool>> lambdaExpression1 = Expression.Lambda<Func<int , bool>>(
                    Expression.Block(
                        // Expression for Console.WriteLine($"i:{i}")
                        Expression.Call(
                            writeLineMethod ,
                            Expression.Call(
                                stringFormatMethod ,
                                Expression.Constant("i:{0}") ,
                                Expression.Convert(iParam , typeof(object)) // Convert int to object for string.Format
                            )
                        ) ,
                        // Expression for return i > 0; (the result of the block)
                        Expression.GreaterThan(iParam , Expression.Constant(0))
                    ),
                    iParam
            );

            Expression<Func<int , bool>> lambdaExpression2 = Expression.Lambda<Func<int , bool>>(
                    Expression.Block(
                        // Expression for Console.WriteLine($"j:{j}")
                        Expression.Call(
                            writeLineMethod ,
                            Expression.Call(
                                stringFormatMethod ,
                                Expression.Constant("j:{0}") ,
                                Expression.Convert(jParam , typeof(object)) // Convert int to object for string.Format
                            )
                        ) ,
                        // Expression for return j <= 0; (the result of the block)
                        Expression.LessThanOrEqual(jParam , Expression.Constant(0))
                    ) ,
                    jParam
            );

            // Prepare for Parameter Rebinding
            // We need to tell our rebinder to replace 'iParam' and 'jParam'
            // with the new 'xParam' in their respective bodies.
            var parameterMap = new Dictionary<ParameterExpression , ParameterExpression>
            {
                { lambdaExpression1.Parameters[0], xParam }, // Map iParam to xParam
                { lambdaExpression2.Parameters[0], xParam }  // Map jParam to xParam
            };

            // Parameter Rebinding
            var parameterRebinder = new ParameterRebinder(parameterMap);

            // Rebind the Bodies
            Expression body1Rebound = parameterRebinder.Visit(lambdaExpression1.Body);
            Expression body2Rebound = parameterRebinder.Visit(lambdaExpression2.Body);

            List<BinaryExpression> binaryExpressions = new List<BinaryExpression>();
            
            List<Expression<Func<int , bool>>> delegateExpressions = new List<Expression<Func<int , bool>>>();

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `AND` operation (without short circuit) to the parameter value.
                Expression.And(
                    parameterExpression ,
                    Expression.Constant(1)
                )
           );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `AND` operation (without short circuit) to the parameter value.
                Expression.AndAssign(
                    parameterExpression ,
                    Expression.Constant(2)
                )
           );


            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `OR` operation (without short circuit) to the parameter value.
                Expression.Or(
                    parameterExpression ,
                    Expression.Constant(1)
                )
           );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `OR` operation (without short circuit) to the parameter value.
                Expression.OrAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
           );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `XOR` operation (without short circuit) to the parameter value.
                Expression.ExclusiveOr(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise `XOR` operation (without short circuit) to the parameter value.
                Expression.ExclusiveOrAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise left-shift operation (without short circuit) to the parameter value.
                Expression.LeftShift(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise left-shift operation (without short circuit) to the parameter value.
                Expression.LeftShiftAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise right-shift operation (without short circuit) to the parameter value.
                Expression.RightShift(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            binaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise right-shift operation (without short circuit) to the parameter value.
                Expression.RightShiftAssign(
                    parameterExpression ,
                    Expression.Constant(4)
                )
            );

            delegateExpressions.Add(
                // This expression represents a lambda expression
                // that do logical `AND` operation (with short circuit) to the parameter value.
                Expression.Lambda<Func<int , bool>>(
                     Expression.AndAlso(
                        body1Rebound ,
                        body2Rebound
                     ) ,
                     xParam // The new lambda's single parameter
                )
           );

            delegateExpressions.Add(
                // This expression represents a lambda expression
                // that do logical `OR` operation (with short circuit) to the parameter value.
                Expression.Lambda<Func<int , bool>>(
                     Expression.OrElse(
                        body1Rebound ,
                        body2Rebound
                     ) ,
                     xParam // The new lambda's single parameter
                )
           );

            Console.WriteLine("About `binaryExpressions`");
            binaryExpressions.ForEach(
                (binaryExpression) =>
                {
                    string infoText = binaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                    LambdaExpression lambdaExpression = Expression.Lambda(
                                                            binaryExpression ,
                                                            new List<ParameterExpression>() { parameterExpression }
                                                        );
                    var compiledDelegateExpression = lambdaExpression.Compile();
                    Console.WriteLine("---- new round ----");
                    for(int i = -5; i <= 5; i++) 
                    { 
                        var result = compiledDelegateExpression.DynamicInvoke(i);                  
                        Console.WriteLine("compiledDelegateExpression.DynamicInvoke({0}):{1}",i,result);
                    }
                }
            );
            Console.WriteLine();

            Console.WriteLine("About `delegateExpressions`");
            delegateExpressions.ForEach(
               (delegateExpression) =>
               {
                   var compiledDelegateExpression =  delegateExpression.Compile();
                   Console.WriteLine("---- new round ----");
                   for(int i=-5;i<=5;i++) 
                   {
                       var result = compiledDelegateExpression.DynamicInvoke(i);
                       Console.WriteLine("compiledDelegateExpression.DynamicInvoke({0}):{1}" , i , result);
                   }
               }
           );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate bitwise or logical operation with `UnaryExpression`.
        /// </summary>
        public static void TestMethod11()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            int constant = 42;

            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise one's complementation (without short circuit) to the parameter value.
                Expression.OnesComplement(
                    Expression.Constant(constant)
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do bitwise two's complementation (without short circuit) to the parameter value.
                Expression.Not(
                    Expression.Constant(constant)
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do arithmetic negation operation (without short circuit) to the parameter value.
                Expression.Negate(
                    Expression.Constant(constant)
                )
            );

            Console.WriteLine("About `unaryExpressions`");
            unaryExpressions.ForEach(
                (unaryExpression) =>
                {
                    string infoText = unaryExpression.GetInfo();
                    Console.WriteLine(infoText);

                    LambdaExpression lambdaExpression = 
                        Expression.Lambda<Func<int>>(
                            unaryExpression
                        );

                    Console.WriteLine("executimg the expression`{0}` with argument `{1}` will get result `{2}`" ,lambdaExpression.ToString(),constant,lambdaExpression.Compile().DynamicInvoke());
                }
            );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate prefix/postfix increment/decrement operation.
        /// </summary>
        public static void TestMethod12()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression intParameterExpression1 = Expression.Parameter(typeof(int) , "x");

            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do prefix increment to the parameter value.
                Expression.PreIncrementAssign(
                    intParameterExpression1
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do postfix increment to the parameter value.
                Expression.PostIncrementAssign(
                    intParameterExpression1
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do prefix decrement to the parameter value.
                Expression.PreDecrementAssign(
                    intParameterExpression1
                )
            );

            unaryExpressions.Add(
                // This expression represents a lambda expression
                // that do postfix decrement to the parameter value.
                Expression.PostDecrementAssign(
                    intParameterExpression1
                )
            );

            int counter = 0;
            Console.WriteLine("About `unaryExpressions`");
            unaryExpressions.ForEach(
                (unaryExpression) =>
                {
                    int constants = 10;
                    var lambdaExpression = Expression.Lambda<Func<int , int>>(unaryExpression , intParameterExpression1);
                    Console.WriteLine("---- In {0}th round ----",counter);
                    string infoText = unaryExpression.GetInfo();
                    Console.WriteLine(infoText);
                    Console.WriteLine();
                    Console.WriteLine("Compile the expression:`{0}`, then execute it with argument value `{1}` will gets `{2}`.", lambdaExpression.ToString(),constants,lambdaExpression.Compile()(constants));
                    Console.WriteLine("---- End of {0}th round ----" , counter);
                    counter++;
                }
            );
            Console.WriteLine();
        }

        /// <summary>
        /// illustrate how to compare two expression with data type `System.Int32`.
        /// </summary>
        public static void TestMethod13()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ExpressionsOutput.CompareExpressionAndOutput(40,40);
            ExpressionsOutput.CompareExpressionAndOutput(45,42);
            ExpressionsOutput.CompareExpressionAndOutput(42,45);
        }

        /// <summary>
        /// illustrate how to create an expression about a condition.
        /// </summary>
        public static void TestMethod14()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string [ ] textArray = new string [ ]
            {
                string.Empty,
                "Cat",
                "CatShabo",
                "Spy x family",
                "PurismMagica"
            };

            ParameterExpression parameterExpression = Expression.Parameter(typeof(string) , "arg");

            Expression<Func<string , string>> capatalize = text => text.ToUpper();
            Expression<Func<string , string>> uncapatalize = text => text.ToLower();

            Expression<Func<string , bool>> startWithCatLambda = text => string.IsNullOrEmpty(text)== false && text.StartsWith("Cat") ;

            List<ConditionalExpression> conditionalExpressions = new List<ConditionalExpression>();

            // To use startWithCatLambda as the condition, we need to apply it to our 'arg' parameter.
            // We do this by invoking its body with the 'arg' parameter.

            // 1. Get the body of the startWithCatLambda
            Expression conditionBody = startWithCatLambda.Body;

            // 2. Identify the parameter of the startWithCatLambda (the 'text' in text => ...)
            ParameterExpression startWithCatParameter = startWithCatLambda.Parameters [0];

            // 3. Create a parameter replacer visitor to replace 'text' with 'arg' in the condition body
            ParameterReplacer visitor = new ParameterReplacer(startWithCatParameter, parameterExpression);
            Expression actualCondition = visitor.Visit(conditionBody);

            // --- "True" Part (IfTrue) ---
            // 1. Get the body of the capatalize lambda
            Expression capatalizeBody = capatalize.Body;

            // 2. Identify the parameter of the capatalize lambda
            ParameterExpression capatalizeParameter = capatalize.Parameters [ 0 ];

            // 3. Create a parameter replacer for the capatalize body
            ParameterReplacer capatalizeVisitor = new ParameterReplacer(capatalizeParameter , parameterExpression);
            Expression actualCapatalizeBody = capatalizeVisitor.Visit(capatalizeBody);

            // --- "False" Part (IfFalse) ---
            // 1. Get the body of the uncapatalize lambda
            Expression uncapatalizeBody = uncapatalize.Body;

            // 2. Identify the parameter of the uncapatalize lambda
            ParameterExpression uncapatalizeParameter = uncapatalize.Parameters [ 0 ];

            // 3. Create a parameter replacer for the uncapatalize body
            ParameterReplacer uncapatalizeVisitor = new ParameterReplacer(uncapatalizeParameter , parameterExpression);
            Expression actualUncapatalizeBody = uncapatalizeVisitor.Visit(uncapatalizeBody);

            conditionalExpressions.Add(
                Expression.Condition(
                    actualCondition ,
                    actualCapatalizeBody ,  // Use the transformed body
                    actualUncapatalizeBody // Use the transformed body
                )
           );

            
            conditionalExpressions.ForEach(
                (conditionalExpression) =>
                {
                    LambdaExpression lambdaExpression = Expression.Lambda(
                        conditionalExpression,
                        new List<ParameterExpression>() { parameterExpression }
                    );
                    var delegateFunction = lambdaExpression.Compile();

                    foreach(string text in textArray)
                    {
                        Console.WriteLine("delegateFunction.DynamicInvoke({0}):{1}" , text , delegateFunction.DynamicInvoke(text));
                    }
                }
            );
        }

        /// <summary>
        /// illustrate writing data about expression info as debug info with `DebugInfoGenerator` in `NLog` third package. 
        /// </summary>
        public static void TestMethod15()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            DebugInfoGenerator debugInfoGenerator = new DebugErrorInfoGenerator();

            ParameterExpression parameterExpression = Expression.Parameter(typeof(int) , "arg");

            // This expression represents a lambda expression
            // that adds 1 to the parameter value.
            LambdaExpression lambdaExpression = Expression.Lambda(
                Expression.Add(
                    parameterExpression ,
                    Expression.Constant(1)
                ) ,
                new List<ParameterExpression>() { parameterExpression }
            );

            string sourceFileFullPath = $@"/AppData/User.cs";
            SymbolDocumentInfo document = Expression.SymbolDocument(sourceFileFullPath);

            DebugInfoExpression debugInfoExpression = Expression.DebugInfo(
                document: document ,
                startLine: 5 ,
                startColumn: 1 ,
                endLine: 5 ,
                endColumn: 10
            );

            debugInfoGenerator.MarkSequencePoint(lambdaExpression , 0 , debugInfoExpression);
        }

        /// <summary>
        /// illustrates an expression with default value.
        /// </summary>
        public static void TestMethod16()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string text = string.Empty;

            DefaultExpression boolDefaultExpression = Expression.Default(typeof(bool));
            text = boolDefaultExpression.GetInfo<bool>();
            Console.WriteLine(text);

            DefaultExpression byteDefaultExpression = Expression.Default(typeof(byte));
            text = byteDefaultExpression.GetInfo<byte>();
            Console.WriteLine(text);

            DefaultExpression shortDefaultExpression = Expression.Default(typeof(short));
            text = shortDefaultExpression.GetInfo<short>();
            Console.WriteLine(text);

            DefaultExpression int32DefaultExpression = Expression.Default(typeof(int));
            text = int32DefaultExpression.GetInfo<int>();
            Console.WriteLine(text);

            DefaultExpression longDefaultExpression = Expression.Default(typeof(long));
            text = longDefaultExpression.GetInfo<long>();
            Console.WriteLine(text);

            DefaultExpression ushortDefaultExpression = Expression.Default(typeof(ushort));
            text = ushortDefaultExpression.GetInfo<ushort>();
            Console.WriteLine(text);

            DefaultExpression uintDefaultExpression = Expression.Default(typeof(uint));
            text = uintDefaultExpression.GetInfo<uint>();
            Console.WriteLine(text);

            DefaultExpression ulongDefaultExpression = Expression.Default(typeof(ulong));
            text = ulongDefaultExpression.GetInfo<ulong>();
            Console.WriteLine(text);

            DefaultExpression floatDefaultExpression = Expression.Default(typeof(float));
            text = floatDefaultExpression.GetInfo<float>();
            Console.WriteLine(text);

            DefaultExpression doubleDefaultExpression = Expression.Default(typeof(double));
            text = doubleDefaultExpression.GetInfo<double>();
            Console.WriteLine(text);

            DefaultExpression charDefaultExpression = Expression.Default(typeof(char));
            text = charDefaultExpression.GetInfo<char>();
            Console.WriteLine(text);

            DefaultExpression stringDefaultExpression = Expression.Default(typeof(string));
            text = stringDefaultExpression.GetInfo<string>();
            Console.WriteLine(text);

            /// *---------------------- More complex type --------------------- *///
            
            // *---------------------- About Date and Time --------------------- *//
            DefaultExpression datetTimeDefaultExpression = Expression.Default(typeof(DateTime));
            text = datetTimeDefaultExpression.GetInfo<DateTime>();
            Console.WriteLine(text);

            DefaultExpression timeSpanDefaultExpression = Expression.Default(typeof(TimeSpan));
            text = timeSpanDefaultExpression.GetInfo<TimeSpan>();
            Console.WriteLine(text);

            DefaultExpression timeZoneDefaultExpression = Expression.Default(typeof(TimeZone));
            text = timeZoneDefaultExpression.GetInfo<TimeZone>();
            Console.WriteLine(text);

            // *---------------------- About generics --------------------- *//
            DefaultExpression listStringDefaultExpression = Expression.Default(typeof(List<string>));
            text = listStringDefaultExpression.GetInfo<List<string>>();
            Console.WriteLine(text);

            DefaultExpression listIntDefaultExpression = Expression.Default(typeof(List<int>));
            text = listIntDefaultExpression.GetInfo<List<int>>();
            Console.WriteLine(text);

            DefaultExpression hashSetIntDefaultExpression = Expression.Default(typeof(HashSet<int>));
            text = hashSetIntDefaultExpression.GetInfo<HashSet<int>>();
            Console.WriteLine(text);

            DefaultExpression keyValuePairFromIntToStringSetIntDefaultExpression = Expression.Default(typeof(KeyValuePair<int , string>));
            text = keyValuePairFromIntToStringSetIntDefaultExpression.GetInfo<KeyValuePair<int , string>>();
            Console.WriteLine(text);

            DefaultExpression dictionaryFromIntToStringSetIntDefaultExpression = Expression.Default(typeof(Dictionary<int,string>));
            text = dictionaryFromIntToStringSetIntDefaultExpression.GetInfo<Dictionary<int , string>>();
            Console.WriteLine(text);

            /// DON'T use non predefined type (including 
            /// + primitive type and 
            /// + defined in third package by Microsoft
            /// ) to create an expression with default value.
            //DefaultExpression userClassDefaultExpression = Expression.Default(typeof(User));
            //text = stringDefaultExpression.GetInfo<User>();
            //Console.WriteLine(text);

        }

        /// <summary>
        /// illustrate how to create a dynamic expression.
        /// compile it then execute it. 
        /// </summary>
        public static void TestMethod17()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Type currentClassType = MethodBase.GetCurrentMethod().DeclaringType;

            DynamicMethodCaller dynamicMethodCaller = new DynamicMethodCaller();
            ParameterExpression instanceParam = Expression.Parameter(typeof(object) , "instance");
            ParameterExpression methodNameParam = Expression.Parameter(typeof(string) , "methodName");
            ParameterExpression argsParam = Expression.Parameter(typeof(object [ ]) , "args");

            // Create a C# CallSite for the dynamic operation
            // This is where the magic of the DLR happens.
            // Binder.InvokeMember is used to perform dynamic method invocation.
            CallSiteBinder invokeBinder = Binder.InvokeMember(
                CSharpBinderFlags.None , // No special flags
                "Greet" ,        // This name is used for the method being invoked
                null ,                   // Type arguments for generic methods (none here)
                currentClassType ,        // The context type for the binder
                new CSharpArgumentInfo [ ]
                {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null), // For the instance
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null), // For the method name (treated as constant)
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)  // For the arguments array
                });

            Expression dynamicCallExpression = Expression.Dynamic(
                invokeBinder ,
                typeof(object) , // Return type of the dynamic operation
                Expression.Constant(dynamicMethodCaller , typeof(object)) , // The instance
                Expression.Constant("Greet" , typeof(string)) , // The method name
                Expression.Constant(new object [ ] { "World" } , typeof(object [ ])) // The arguments
            );

            Func<object> dynamicInvoker = Expression.Lambda<Func<object>>(dynamicCallExpression).Compile();

            object result1 = dynamicInvoker.Invoke();
            Console.WriteLine($"Result of Greet: {result1}");
        }

        /// <summary>
        /// illustrate how to create an expression containing a member.
        /// </summary>
        public static void TestMethod18()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Animal horse = new Animal();

            // Create a MemberExpression that represents getting
            // the value of the 'species' field of class 'Animal'.
            MemberExpression memberExpression =
                Expression.Field(
                    Expression.Constant(horse) ,
                    "species");

            Console.WriteLine(memberExpression.ToString());
        }

        /// <summary>
        /// illustrate how to create an expression containing void type.
        /// </summary>
        public static void TestMethod19()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            DefaultExpression emptyExpression = Expression.Empty();

            BlockExpression emptyBlock = Expression.Block(emptyExpression);
            string infoText = emptyBlock.GetInfo();
            Console.WriteLine(infoText);
        }

        /// <summary>
        /// illustrate how to create an expression with `try` block and `catch` block.
        /// </summary>
        public static void TestMethod20()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            TryExpression tryCatchExpression =
                Expression.TryCatch(
                    Expression.Block(
                        Expression.Throw(
                            Expression.Constant(new DivideByZeroException())
                        ),
                        Expression.Constant("Try block")
                    ) ,
                    Expression.Catch(
                        typeof(DivideByZeroException) ,
                        Expression.Constant("Catch block")
                    )
                );

            string infoText = tryCatchExpression.GetInfo();
            Console.WriteLine(infoText);
        }

        /// <summary>
        /// illustrate how to create an expression with `try` block and `finally` block.
        /// 
        /// In this example, one throws an Excpetion in try block and NOT be caught.
        /// 
        /// Thus, when the expression is compiled then is executed, it throws an exception.
        /// </summary>
        public static void TestMethod21()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression variableExpression = Expression.Variable(typeof(string) , "name");

            BinaryExpression assignmentExpression = Expression.Assign(
                variableExpression,
                Expression.Constant("Yazawa Nico")
            );

            BlockExpression blockExpression = Expression.Block(
                new ParameterExpression [ ] { variableExpression },
                assignmentExpression
            );

            TryExpression tryExpression =
                Expression.TryFinally(
                    Expression.Block(
                        Expression.Throw(
                            Expression.Constant(new DivideByZeroException())
                        ) ,
                        Expression.Constant("Try block")
                    ),
                    Expression.Block(
                        blockExpression,
                        Expression.Constant("Finally block")
                    )
                );

            string infoText = tryExpression.GetInfo();
            Console.WriteLine(infoText);
        }

        /// <summary>
        /// illustrate how to create an expression with `try` block and `finally` block.
        /// 
        /// In this example, one does NOT throw exceptions in `try` block.
        /// 
        /// Thus, when the expression is compiled then is executed, 
        /// 
        /// `finally` block will be executed.
        /// </summary>
        public static void TestMethod22()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression nameVariableExpression = Expression.Variable(typeof(string) , "name");

            ParameterExpression reachedVariableExpression = Expression.Variable(typeof(bool) , "reached");

            TryExpression tryExpression =
                Expression.TryFinally(
                    Expression.Block(
                        Expression.Block(
                            new ParameterExpression [ ] { reachedVariableExpression } ,
                            Expression.Assign(
                                reachedVariableExpression ,
                                Expression.Constant(false)
                            )
                        ),
                        Expression.Block(
                            new ParameterExpression [ ] { nameVariableExpression } ,
                            Expression.Assign(
                                nameVariableExpression ,
                                Expression.Constant("Yazawa Nico")
                            )
                        ),
                        Expression.Constant("Try block")
                    ) ,
                    Expression.Block(
                        Expression.Block(
                            new ParameterExpression [ ] { nameVariableExpression } ,
                            Expression.Assign(
                                nameVariableExpression ,
                                Expression.Constant("Ayase Eli")
                            )
                        ),
                        Expression.Block(
                            new ParameterExpression [ ] { reachedVariableExpression } ,
                            Expression.Assign(
                                reachedVariableExpression ,
                                Expression.Constant(true)
                            )
                        ),
                        Expression.Constant("Finally block")
                    )
                );

            string infoText = tryExpression.GetInfo();
            Console.WriteLine(infoText);
        }

        /// <summary>
        /// `Expression.TryCatchFinally` example.
        /// </summary>
        public static void TestMethod23()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            TryExpression tryCatchExpression =
                Expression.TryCatchFinally(
                    Expression.Block(
                        Expression.Throw(Expression.Constant(new DivideByZeroException())) ,
                        Expression.Constant("Try block")
                    ) ,
                    Expression.Call(typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) }) , Expression.Constant("Finally block")) ,
                    Expression.Catch(
                        typeof(DivideByZeroException) ,
                        Expression.Constant("Catch block")
                    )
                );

            // The following statement first creates an expression tree,
            // then compiles it, and then runs it.
            // If the exception is caught,
            // the result of the TryExpression is the last statement
            // of the corresponding catch statement.
            Console.WriteLine(Expression.Lambda<Func<string>>(tryCatchExpression).Compile()());
        }

        /// <summary>
        /// illustrate how to create an expression representing unconditional jump (with `label` and `goto` keyword.
        /// </summary>
        public static void TestMethod24()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            // A label expression of the void type that is the target for Expression.Return().
            LabelTarget returnTarget = Expression.Label();

            // This block contains a GotoExpression that represents a return statement with no value.
            // It transfers execution to a label expression that is initialized with the same LabelTarget as the GotoExpression.
            // The types of the GotoExpression, label expression, and LabelTarget must match.
            BlockExpression blockExpression =
                Expression.Block(
                    Expression.Call(typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) }) , Expression.Constant("Return")) ,
                    Expression.Return(returnTarget) ,
                    Expression.Call(typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) }) , Expression.Constant("Other Work")) ,
                    Expression.Label(returnTarget)
                );

            // The following statement first creates an expression tree,
            // then compiles it, and then runs it.
            Expression.Lambda<Action>(blockExpression).Compile()();
        }

        /// <summary>
        /// illustrate how to create a loop using `Expression.Loop`.
        /// 
        /// The following example will output
        /// 
        /// ```
        /// i=0
        /// i=1
        /// i=2
        /// ```
        /// </summary>
        public static void TestMethod25()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            // 1. Define a ParameterExpression for our loop variable 'i'
            ParameterExpression i = Expression.Variable(typeof(int) , "i");

            // 2. Define a LabelTarget for the loop's break condition
            LabelTarget loopBreak = Expression.Label("loopBreak");

            // 3. Define the loop's initialization (i = 0)
            Expression initializeI = Expression.Assign(i , Expression.Constant(0));

            // 4. Define the loop body
            Expression loopBody = Expression.Block(
                // Print "i=" + i
                Expression.Call(
                    typeof(Console).GetMethod("WriteLine" , new [ ] { typeof(string) }) ,
                    Expression.Call(
                        typeof(string).GetMethod("Concat" , new [ ] { typeof(object) , typeof(object) }) , // Or other overloads as needed
                        Expression.Constant("i=") ,
                        Expression.Convert(i , typeof(object)) // Convert 'i' to object for string.Concat(object, object)
                    )
                ),
                // Postfix Increment to i
                Expression.PostIncrementAssign(i) ,
                // Check condition (i < 3) and break if false
                Expression.IfThen(
                    Expression.GreaterThanOrEqual(i , Expression.Constant(3)) ,
                    Expression.Break(loopBreak)
                )
            );

            // 5. Create the LoopExpression
            LoopExpression loop = Expression.Loop(
                loopBody ,
                loopBreak // Associate the break label with the loop
            );

            // 6. Combine initialization and the loop into a block expression
            BlockExpression fullProgram = Expression.Block(
                new [ ] { i } , // Declare 'i' as a local variable within the block
                initializeI ,
                loop
            );

            // 7. Compile the expression tree into an executable Action
            Action compiledLoop = Expression.Lambda<Action>(fullProgram).Compile();

            // 8. Execute the compiled delegate
            compiledLoop();
        }

        /// <summary>
        /// illustrate how to create an expression representing a method call.
        /// </summary>
        public static void TestMethod26()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            MethodCallExpression methodCallExpression = Expression.Call(
                typeof(Console).GetMethod(
                      "WriteLine",
                      new Type [] { typeof(string) }
                ), 
                Expression.Constant("Hello World")
            );

            Expression.Lambda<Action>(methodCallExpression).Compile()();
        }

        /// <summary>
        /// illustrate how to create an expression about invoking an expression with generic type.
        /// </summary>
        public static void TestMethod27()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            System.Linq.Expressions.Expression<Func<int , int , bool>> largeSumTest =
                (num1 , num2) => (num1 + num2) > 1000;

            // Create an InvocationExpression that represents applying
            // the arguments '539' and '281' to the lambda expression 'largeSumTest'.
            InvocationExpression invocationExpression =
                Expression.Invoke(
                    largeSumTest ,
                    Expression.Constant(539) ,
                    Expression.Constant(281)
                );

            string infoText = invocationExpression.GetInfo();
            Console.WriteLine(infoText);
        }

        /// <summary>
        /// illustrate how to use `Expression.ArrayIndex`.
        /// </summary>
        public static void TestMethod28()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            // 1. Define the array:
            int [ ] myArray = { 10 , 20 , 30 , 40 , 50 };

            // 2. Create an Expression representing the array:
            //    (ConstantExpression for the array instance)
            Expression arrayExpression = Expression.Constant(myArray , typeof(int [ ]));

            // 3. Create an Expression representing the index:
            //    (ConstantExpression for the integer index)
            int index = 2; // We want to access myArray[2], which is 30
            Expression indexExpression = Expression.Constant(index , typeof(int));

            // 4. Use Expression.ArrayIndex to create an expression for array access:
            //    This represents the operation: myArray[index]
            BinaryExpression arrayAccessExpression = Expression.ArrayIndex(arrayExpression , indexExpression);

            // 5. Compile the expression into a delegate:
            //    The delegate will return an int (the value at the specified index).
            Func<int> getArrayElement = Expression.Lambda<Func<int>>(arrayAccessExpression).Compile();

            // 6. Execute the compiled delegate:
            int result = getArrayElement();

            Console.WriteLine($"The value at index {index} is: {result}");

        }

        /// <summary>
        /// illustrate how to use `Expression.ArrayIndex`.
        /// </summary>
        public static void TestMethod29()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            int [ ] myArray = { 10 , 20 , 30 , 40 , 50 };

            // Let's create an expression that takes an array and an index as parameters
            ParameterExpression paramArray = Expression.Parameter(typeof(int [ ]) , "array");
            ParameterExpression paramIndex = Expression.Parameter(typeof(int) , "idx");

            // Create the ArrayIndex expression using the parameters
            BinaryExpression dynamicArrayAccess = Expression.ArrayIndex(paramArray , paramIndex);

            // Create a lambda expression that takes an int[] and an int, and returns an int
            Expression<Func<int [ ] , int , int>> getDynamicArrayElement =
                Expression.Lambda<Func<int [ ] , int , int>>(
                    dynamicArrayAccess ,
                    paramArray ,
                    paramIndex
                );

            // Compile the dynamic expression
            Func<int [ ] , int , int> compiledDynamicAccessor = getDynamicArrayElement.Compile();

            // Use the compiled delegate with different inputs
            int [ ] anotherArray = { 1 , 2 , 3 , 4 , 5 , 6 , 7 };
            Console.WriteLine($"Accessing anotherArray[4]: {compiledDynamicAccessor(anotherArray , 4)}"); 
            Console.WriteLine($"Accessing myArray[0]: {compiledDynamicAccessor(myArray , 0)}");
        }

        /// <summary>
        /// illustrate how to use `Expression.ArrayAccess`.
        /// </summary>
        public static void TestMethod30()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // This parameter expression represents a variable that will hold the two-dimensional array.
            ParameterExpression arrayExpression = Expression.Parameter(typeof(int [ , ]) , "Array");

            // This parameter expression represents a first array index.
            ParameterExpression firstIndexExpression = Expression.Parameter(typeof(int) , "FirstIndex");
            // This parameter expression represents a second array index.
            ParameterExpression secondIndexExpression = Expression.Parameter(typeof(int) , "SecondIndex");

            // The list of indexes.
            List<Expression> indexes = new List<Expression> { firstIndexExpression , secondIndexExpression };

            // This parameter represents the value that will be added to a corresponding array element.
            ParameterExpression valueExpression = Expression.Parameter(typeof(int) , "Value");

            // This expression represents an access operation to a multidimensional array.
            // It can be used for assigning to, or reading from, an array element.
            Expression arrayAccessExpression = Expression.ArrayAccess(
                arrayExpression ,
                indexes
            );

            // This lambda expression assigns a value provided to it to a specified array element.
            // The array, the index of the array element, and the value to be added to the element
            // are parameters of the lambda expression.
            Expression<Func<int [ , ] , int , int , int , int>> lambdaExpression =
                Expression.Lambda<Func<int [ , ] , int , int , int , int>>(
                    Expression.Assign(arrayAccessExpression , Expression.Add(arrayAccessExpression , valueExpression)) ,
                    arrayExpression ,
                    firstIndexExpression ,
                    secondIndexExpression ,
                    valueExpression
            );

            // Print out expressions.
            Console.WriteLine("Array Access Expression:");
            Console.WriteLine(arrayAccessExpression.ToString());

            Console.WriteLine("Lambda Expression:");
            Console.WriteLine(lambdaExpression.ToString());

            Console.WriteLine("The result of executing the lambda expression:");

            // The following statement first creates an expression tree,
            // then compiles it, and then executes it.
            // Parameters passed to the Invoke method are passed to the lambda expression.
            int [ , ] sampleArray = 
                { 
                    {10,  20,   30},
                    {100, 200, 300}
                };
            Console.WriteLine(lambdaExpression.Compile().Invoke(sampleArray , 1 , 1 , 5));

        }

        /// <summary>
        /// illustrate how to use `Expression.ArrayLength`
        /// </summary>
        public static void TestMethod31()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // 1. Define the array:
            int [ ] myArray = { 10 , 20 , 30 , 40 , 50 };

            // 2. Create an Expression representing the array:
            //    (ConstantExpression for the array instance)
            Expression arrayExpression = Expression.Constant(myArray , typeof(int [ ]));

            // 3. Use Expression.ArrayLength to create an expression for getting the array's length:
            //    This represents the operation: myArray.Length
            UnaryExpression arrayLengthExpression = Expression.ArrayLength(arrayExpression);

            // 4. Compile the expression into a delegate:
            //    The delegate will return an int (the length of the array).
            Func<int> getArrayLength = Expression.Lambda<Func<int>>(arrayLengthExpression).Compile();

            // 5. Execute the compiled delegate:
            int result = getArrayLength();

            Console.WriteLine($"The length of the array is: {result}");
        }

        /// <summary>
        /// illustrate how to use `Expression.NewArrayInit`.
        /// </summary>
        public static void TestMethod32()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            List<Expression> trees = new List<Expression>()
            { 
                  Expression.Constant("oak"),
                  Expression.Constant("fir"),
                  Expression.Constant("spruce"),
                  Expression.Constant("alder") 
            };

            // Create an expression tree that represents creating and
            // initializing a one-dimensional array of type string.
            NewArrayExpression newArrayExpression =
                Expression.NewArrayInit(typeof(string) , trees);

            // Output the string representation of the Expression.
            Console.WriteLine(newArrayExpression.ToString());
        }

        /// <summary>
        /// illustrate how to use `Expression.NewArrayBounds`.
        /// </summary>
        public static void TestMethod33()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            // Create an expression tree that represents creating a
            // two-dimensional array of type string with bounds [3,2].
            NewArrayExpression newArrayExpression =
                Expression.NewArrayBounds(
                        typeof(string) ,
                        Expression.Constant(3) ,
                        Expression.Constant(2)
                );

            // Output the string representation of the Expression.
            Console.WriteLine(newArrayExpression.ToString());
        }

        /// <summary>
        /// illustrate how to use `Expression.Quote`.
        /// </summary>
        public static void TestMethod34()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // 1. Define an inner lambda expression:
            //    This lambda takes an int `x` and returns `x * 2`
            Expression<Func<int , int>> multiplyByTwo = x => x * 2;

            Console.WriteLine($"Inner Lambda (C# code): {multiplyByTwo}");

            // 2. Now, let's create an outer expression that *returns* this inner lambda.

            // Correct way using Expression.Quote:
            // We want an outer expression that produces the 'multiplyByTwo' Expression tree.
            // The type of the value returned by the outer expression is Expression<Func<int, int>>.
            Expression<Func<Expression<Func<int , int>>>> outerLambda =
                Expression.Lambda<Func<Expression<Func<int , int>>>>(
                    Expression.Quote(multiplyByTwo)
                );

            Console.WriteLine($"Outer Lambda (with Quote): {outerLambda}");

            // 3. Compile and execute the outer expression:
            Func<Expression<Func<int , int>>> compiledOuterLambda =
                outerLambda.Compile();

            // 4. The result of executing the outer lambda is the *expression tree* itself:
            Expression<Func<int , int>> retrievedInnerExpression = compiledOuterLambda();

            Console.WriteLine($"Retrieved Inner Expression (from compiled outer): {retrievedInnerExpression}");

            // 5. You can then compile and execute the retrieved inner expression:
            Func<int , int> compiledInnerFunction = retrievedInnerExpression.Compile();
            int result = compiledInnerFunction(5);
            Console.WriteLine($"Result of inner expression (5 * 2): {result}"); 
        }

        public static void TestMethod35()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            Animal horse = new Animal();
            horse.species = "Animal";

            MemberExpression propertyExpression = Expression.Property(
                 Expression.Constant(horse),
                 "species"
             );
            Console.WriteLine(Expression.Lambda<Func<int>>(propertyExpression).Compile()());
        }

        /// <summary>
        /// illustrate how to use `Expression.ListInit`.
        /// </summary>
        public static void TestMethod36()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            
            // 1. Define the type of the list we want to create
            Type listType = typeof(List<string>);

            // 2. Get the constructor for List<string> (empty constructor)
            ConstructorInfo listConstructor = listType.GetConstructor(Type.EmptyTypes);

            // 3. Create a NewExpression representing the constructor call
            NewExpression newListaExpression = Expression.New(listConstructor);

            // 4. Get the MethodInfo for the Add method of List<string>
            MethodInfo addMethod = listType.GetMethod("Add" , new Type [ ] { typeof(string) });

            // 5. Create ElementInit objects for each item in the initializer list
            //    Each ElementInit needs the add method and the arguments (the string value)
            ElementInit init1 = Expression.ElementInit(addMethod , Expression.Constant("Apple"));
            ElementInit init2 = Expression.ElementInit(addMethod , Expression.Constant("Banana"));
            ElementInit init3 = Expression.ElementInit(addMethod , Expression.Constant("Cherry"));

            // 6. Create the ListInitExpression
            ListInitExpression listInit = Expression.ListInit(
                newListaExpression ,
                init1 ,
                init2 ,
                init3
            );

            // 7. Compile and execute the expression tree
            //    This creates a delegate that, when invoked, will perform the list initialization.
            Func<List<string>> createList = Expression.Lambda<Func<List<string>>>(listInit).Compile();

            List<string> myList = createList();

            Console.WriteLine("Created List:");
            foreach(string item in myList)
            {
                Console.WriteLine($"- {item}");
            }

            // You can also inspect the expression tree (optional)
            Console.WriteLine("\nExpression Tree (ListInit):");
            Console.WriteLine(listInit.ToString());
        }

        /// <summary>
        /// illustrate how to use `Expression.ListBind`.
        /// </summary>
        public static void TestMethod37()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            // 1. Define the type of the Order class
            Type orderType = typeof(Order);

            // 2. Get MemberInfo for the 'Items' property
            PropertyInfo itemsProperty = orderType.GetProperty("Items");
            if(itemsProperty == null)
            {
                Console.WriteLine("Error: 'Items' property not found on Order class.");
                return;
            }

            // 3. Get the MethodInfo for the 'Add' method of List<string>
            MethodInfo addMethod = typeof(List<string>).GetMethod("Add" , new Type [ ] { typeof(string) });
            if(addMethod == null)
            {
                Console.WriteLine("Error: 'Add' method not found on List<string>.");
                return;
            }

            // 4. Create ElementInit objects for each item to be added to the 'Items' list
            ElementInit item1Init = Expression.ElementInit(addMethod , Expression.Constant("Laptop"));
            ElementInit item2Init = Expression.ElementInit(addMethod , Expression.Constant("Mouse"));

            // 5. Create the MemberListBinding for the 'Items' property
            // This represents the "Items = { ... }" part of the object initializer
            MemberListBinding itemsListBinding = Expression.ListBind(
                itemsProperty ,
                item1Init ,
                item2Init
            );

            // 6. Create MemberAssignment for other properties (like OrderId and CustomerName)
            // This represents "OrderId = 1" and "CustomerName = 'Alice'"
            MemberAssignment orderIdAssignment = Expression.Bind(
                orderType.GetProperty("OrderId") ,
                Expression.Constant(123)
            );

            MemberAssignment customerNameAssignment = Expression.Bind(
                orderType.GetProperty("CustomerName") ,
                Expression.Constant("Alice")
            );

            // 7. Create a NewExpression for the Order constructor (parameterless)
            NewExpression newOrder = Expression.New(orderType.GetConstructor(Type.EmptyTypes));

            // 8. Combine all bindings into a MemberInitExpression
            // This represents the entire object initializer: new Order { ... }
            MemberInitExpression orderInitializer = Expression.MemberInit(
                newOrder ,
                orderIdAssignment ,
                customerNameAssignment ,
                itemsListBinding // Add the ListBinding here
            );

            // 9. Compile and execute the expression tree
            Func<Order> createOrder = Expression.Lambda<Func<Order>>(orderInitializer).Compile();

            Order myOrder = createOrder();

            // 10. Verify the created object
            Console.WriteLine($"Order ID: {myOrder.OrderId}");
            Console.WriteLine($"Customer Name: {myOrder.CustomerName}");
            Console.WriteLine("Order Items:");
            foreach(var item in myOrder.Items)
            {
                Console.WriteLine($"- {item}");
            }

            Console.WriteLine("\nExpression Tree (MemberInit with ListBind):");
            Console.WriteLine(orderInitializer.ToString());
        }
    
        /// <summary>
        /// illustrate how to use `Expression.MakeBinary`.
        /// </summary>
        public static void TestMethod38()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            
            List<BinaryExpression> binaryExpressions = new List<BinaryExpression>();

            binaryExpressions.Add(
                // Create a BinaryExpression that represents adding 14 from 53.
                Expression.MakeBinary(
                    ExpressionType.Add ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents subtracting 14 from 53.
                Expression.MakeBinary(
                    ExpressionType.Subtract ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents 53 times 14.
                Expression.MakeBinary(
                    ExpressionType.Multiply ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents dividing 53 by 14.
                Expression.MakeBinary(
                    ExpressionType.Divide ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents modulus 53 by 14.
                Expression.MakeBinary(
                    ExpressionType.Modulo ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents raise 53 by 14.
                Expression.MakeBinary(
                    ExpressionType.Power ,
                    Expression.Constant(53d) ,
                    Expression.Constant(14d)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents whether 53 equal to 14 or note.
                Expression.MakeBinary(
                    ExpressionType.Equal ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents whether 53 not equal to 14 or not.
                Expression.MakeBinary(
                    ExpressionType.NotEqual ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents whether 53 greater than 14 or not.
                Expression.MakeBinary(
                    ExpressionType.GreaterThan ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents whether 53 greater than or equal to 14 or not.
                Expression.MakeBinary(
                    ExpressionType.GreaterThanOrEqual ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents whether 53 less than 14 or not.
                Expression.MakeBinary(
                    ExpressionType.LessThan ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.Add(
                // Create a BinaryExpression that represents whether 53 less than or equal to 14 or not.
                Expression.MakeBinary(
                    ExpressionType.LessThanOrEqual ,
                    Expression.Constant(53) ,
                    Expression.Constant(14)
                )
            );

            binaryExpressions.ForEach(
                binaryExpression => Console.WriteLine(binaryExpression.ToString())
            );
        }

        /// <summary>
        /// illustrate how to use `Expression.MakeUnary`.
        /// </summary>
        public static void TestMethod39()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ParameterExpression x = Expression.Variable(typeof(int) , "x"); // int x;
          
            List<UnaryExpression> unaryExpressions = new List<UnaryExpression>();

            unaryExpressions.Add(
                // Create a UnaryExpression that represents 53 + 1
                Expression.MakeUnary(
                    ExpressionType.Increment,
                    Expression.Constant(53),
                    null
                )
            );

            unaryExpressions.Add(
                // Create a UnaryExpression that represents 53 - 1
                Expression.MakeUnary(
                    ExpressionType.Decrement ,
                    Expression.Constant(53) ,
                    null
                )
            );

            unaryExpressions.Add(
                // Create a UnaryExpression that represents ++x
                Expression.MakeUnary(
                    ExpressionType.PreIncrementAssign ,
                    x,
                    null
                )
            );

            unaryExpressions.Add(
                // Create a UnaryExpression that represents x++
                Expression.MakeUnary(
                    ExpressionType.PostIncrementAssign ,
                    x ,
                    null
                )
            );

            unaryExpressions.Add(
                // Create a UnaryExpression that represents --x
                Expression.MakeUnary(
                    ExpressionType.PreDecrementAssign ,
                    x ,
                    null
                )
            );

            unaryExpressions.Add(
                // Create a UnaryExpression that represents x--
                Expression.MakeUnary(
                    ExpressionType.PostDecrementAssign ,
                    x ,
                    null
                )
            );

            unaryExpressions.ForEach(
                unaryExpression => Console.WriteLine(unaryExpression.ToString())
            );
        }

        /// <summary>
        /// illustrates how to use `Expression.MakeTry` with a return value.
        /// </summary>
        public static void TestMethod40()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // 1. Define parameter for the divisor for the lambda function
            ParameterExpression divisorParameter = Expression.Parameter(typeof(int) , "divisor");

            // 2. Define a variable to store the result of the try/catch operations.
            // This variable will hold the final return value of the lambda.
            ParameterExpression resultVariable = Expression.Variable(typeof(int) , "result");

            // 3. Define a label for the overall return of the lambda.
            // This label will be the target for the final return value.
            LabelTarget returnLabel = Expression.Label(typeof(int) , "returnLabel");

            // --- Body of the 'try' block ---
            // The try block will assign the result of the division to resultVariable.
            // It should NOT contain an Expression.Return directly.
            Expression assignResult = Expression.Assign(resultVariable , Expression.Divide(Expression.Constant(100) , divisorParameter));

            Expression tryBody = Expression.Block(
                assignResult // Assign the successful division result to resultVariable
            );

            // --- Body of the 'catch' block (for DivideByZeroException) ---
            // The catch block will handle the exception and assign an error value to resultVariable.
            // It should NOT contain an Expression.Return directly.
            ParameterExpression exParameter = Expression.Parameter(typeof(DivideByZeroException) , "ex");
            Expression catchBody = Expression.Block(
                Expression.Call(
                    null , // static method
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) }) ,
                    Expression.Constant("Caught DivideByZeroException!")
                ) ,
                Expression.Assign(resultVariable , Expression.Constant(0)) // Assign 0 to resultVariable on error
            );

            // Create the CatchBlock for DivideByZeroException
            CatchBlock divideByZeroCatchBlock = Expression.Catch(
                exParameter ,
                catchBody
            );

            // --- Body of the 'finally' block ---
            // The finally block performs cleanup and should NOT contain an Expression.Return.
            // It does not affect the return value of the overall expression.
            Expression finallyBody =
                Expression.Block(
                    Expression.Call(
                        null ,
                        typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) }) ,
                        Expression.Constant("Finally block executed.")
                    )
                );

            // --- Create the TryExpression using MakeTry ---
            // The return type of the TryExpression should match the type of resultVariable.
            TryExpression tryExpression = Expression.MakeTry(
                typeof(int) , // The return type of the try-catch-finally block itself.
                              // This means the block will produce an int value (implicitly resultVariable).
                tryBody ,
                finallyBody , // The finally block
                null ,        // No fault block in this example
                new [ ] { divideByZeroCatchBlock } // The catch blocks
            );

            // Add the label target to the overall block.
            // The overallBlock is the body of the lambda.
            // The last expression in overallBlock determines the lambda's return value.
            BlockExpression overallBlock = Expression.Block(
                new [ ] { resultVariable } , // Variables declared in this block (resultVariable)
                tryExpression ,            // The try-catch-finally structure
                Expression.Label(returnLabel , resultVariable) // The final return point, using the value of resultVariable
            );

            // Compile and execute the expression tree
            // The lambda's return type is int, which matches the type of resultVariable
            // and the LabelTarget.
            Func<int , int> divideFunction = Expression.Lambda<Func<int , int>>(
                overallBlock ,
                divisorParameter
            ).Compile();

            Console.WriteLine("--- Test 1: Successful Division (divisor = 5) ---");
            int result1 = divideFunction(5);
            Console.WriteLine($"Result: {result1}");

            Console.WriteLine("\n--- Test 2: Division by Zero (divisor = 0) ---");
            int result2 = divideFunction(0);
            Console.WriteLine($"Result: {result2}");
        }

        /// <summary>
        /// illustrate how to use `Expression.CatchBlock`.
        /// </summary>
        public static void TestMethod41()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // 1. Define a parameter for the exception.
            // This is equivalent to 'Exception ex' in a C# catch block: catch (Exception ex) { ... }
            ParameterExpression exceptionParameter = Expression.Parameter(typeof(Exception) , "ex");

            // 2. Define the body of the catch block.
            // This is the code that will execute when the exception is caught.
            // For this example, we'll just print the exception message to the console.
            MethodInfo writeLineMethod = typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) });

            // Access the Message property of the caught exception: ex.Message
            MemberExpression exceptionMessage = Expression.Property(exceptionParameter , "Message");

            // Call Console.WriteLine(ex.Message)
            Expression catchBody =
                Expression.Block(
                    typeof(int) ,
                    new List<Expression>()
                    {
                        Expression.Call(
                            typeof(string).GetMethod("Concat" , new [ ] { typeof(object) , typeof(object) }) , // Or other overloads as needed
                            Expression.Constant("catch DivideByZeroException error!") ,
                            Expression.Convert(exceptionMessage , typeof(object))
                        ),
                        Expression.Constant(0)
                    }
                );

            CatchBlock generalCatchBlock = Expression.Catch(
                exceptionParameter, // The type of exception to catch and the variable to hold it
                catchBody           // The expression to execute when this exception is caught
            );

            Console.WriteLine("Successfully created a CatchBlock using Expression.Catch.");
            Console.WriteLine($"  Exception Type: {generalCatchBlock.Test.Name}");
            Console.WriteLine($"  Exception Parameter: {generalCatchBlock.Variable.Name}");
            Console.WriteLine($"  Catch Body Type: {generalCatchBlock.Body.Type.Name}");

            // --- Example of how this CatchBlock would be used in a TryExpression ---

            // Define a variable for the result of the try block
            ParameterExpression resultVar = Expression.Variable(typeof(int) , "result");

            // Try body: A simple division that might throw an exception
            Expression tryBody = Expression.Block(
                Expression.Assign(resultVar , Expression.Divide(Expression.Constant(10) , Expression.Constant(0))) // Division by zero
            );

            // Finally body (optional for this example, but good practice)
            Expression finallyBody = Expression.Call(
                null ,
                writeLineMethod ,
                Expression.Constant("Finally block executed.")
            );

            // Create the TryExpression using Expression.MakeTry
            TryExpression tryExpression = Expression.MakeTry(
                typeof(int) , // Return type of the try expression
                tryBody ,
                finallyBody ,
                null , // No fault block
                new [ ] { generalCatchBlock } // Include our created CatchBlock
            );

            // Overall block for the lambda
            BlockExpression overallBlock = Expression.Block(
                new [ ] { resultVar } , // Declare resultVar within this block's scope
                tryExpression ,
                resultVar // The last expression in the block determines its return value
            );

            // Compile and execute the expression tree
            Console.WriteLine("\nCompiling and executing a lambda with the CatchBlock...");
            Func<int> compiledLambda = Expression.Lambda<Func<int>>(overallBlock).Compile();

            try
            {
                int result = compiledLambda();
                Console.WriteLine($"Lambda execution result: {result}");
            }
            catch(Exception ex)
            {
                Console.WriteLine($"An unexpected exception occurred during lambda execution: {ex.Message}");
            }
        }

        /// <summary>
        /// illustrate how to inherit `Expression` and implement `Expression.Reduce` virtual method.
        /// </summary>
        public static void TestMethod42()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            
            ParameterExpression x = Expression.Parameter(typeof(int) , "x");

            PostIncrementExpression postIncrementX = new PostIncrementExpression(x);

            var compiledX = Expression.Lambda<Func<int , int>>(x,x).Compile();

            //To create an lambda expression by `Expression.Lambda`, the expression MUST be reduced.
            // this will throw exception. `postIncrementX` is NOT reduced.
            //var compilePostIncrementX = Expression.Lambda<Func<int , int>>(postIncrementX,x).Compile();

            var compileReducedPostIncrementX = Expression.Lambda<Func<int , int>>(postIncrementX.Reduce(),x).Compile();

            Console.WriteLine("compiledX:{0}" , compiledX.ToString());
            Console.WriteLine("compileReducedPostIncrementX:{0}" , compileReducedPostIncrementX.ToString());
        }

        /// <summary>
        /// illustrate how to use `Expression.Switch`.
        /// </summary>
        public static void TestMethod43()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // 1. Define a parameter for the switch statement (the value being switched on)
            ParameterExpression value = Expression.Parameter(typeof(string) , "value");

            // 2. Define labels for the 'break' equivalent within the switch cases
            //    (though for simple return types, the result variable handles it)
            LabelTarget returnLabel = Expression.Label(typeof(string));

            // 3. Create the default case for the switch
            Expression defaultBody = Expression.Constant("Unknown value" , typeof(string));

            // 4. Create the switch cases
            SwitchCase case1 = Expression.SwitchCase(
                Expression.Constant("Value is 1") , // Body of the case
                Expression.Constant("1", typeof(string))             // Test value for the case
            );

            SwitchCase case2 = Expression.SwitchCase(
                Expression.Constant("Value is 2") ,
                Expression.Constant("2", typeof(string))
            );

            SwitchCase case3 = Expression.SwitchCase(
                Expression.Constant("Value is 3") ,
                Expression.Constant("3", typeof(string))
            );

            // 5. Construct the Switch expression
            Expression switchExpression = Expression.Switch(
                value ,             // The value being switched on
                defaultBody ,       // The default case expression
                case1 ,             // The individual switch cases
                case2 ,
                case3
            );

            // 6. Combine the switch expression with the return label to form a lambda
            //    This lambda will take an integer and return a string.
            Expression<Func<string , string>> lambda = 
                Expression.Lambda<Func<string , string>>(
                    Expression.Block(
                        switchExpression ,
                        Expression.Label(returnLabel , Expression.Constant("Default Fallback")) // Fallback if no return is hit
                    ) ,
                    value
            );

            // 7. Compile the expression tree into an executable delegate
            Func<string , string> compiledSwitch = lambda.Compile();

            string [ ] datas = new string [ ]
            {
                "-1",
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "NAN",
                "Spy x family"
            };

            foreach (string data in datas)
            {
                Console.WriteLine($"compiledSwitch({data}):{compiledSwitch(data)}");
            }
        }

        /// <summary>
        /// illustrate how to use `Expression.Switch`.
        /// </summary>
        public static void TestMethod44()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // An expression that represents the switch value.
            ConstantExpression switchValue = Expression.Constant(3);

            MethodInfo writeLineMethod = typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(string) });
            // This expression represents a switch statement
            // that has a default case.
            SwitchExpression switchExpression =
                Expression.Switch(
                    switchValue ,
                    Expression.Call(
                                null ,
                                writeLineMethod ,
                                Expression.Constant("Default")
                     ) ,
                     new SwitchCase [ ]
                     {
                        Expression.SwitchCase(
                            Expression.Call(
                                null,
                                writeLineMethod,
                                Expression.Constant("First")
                            ),
                            Expression.Constant(1)
                        ),
                        Expression.SwitchCase(
                            Expression.Call(
                                null ,
                                writeLineMethod ,
                                Expression.Constant("Second")
                            ),
                            Expression.Constant(2)
                        )
                    }    
                );

            // The following statement first creates an expression tree,
            // then compiles it, and then runs it.
            Expression.Lambda<Action>(switchExpression).Compile()();
        }


        /// <summary>
        /// illustrate an expression about nullish coalescing operation (`??`) -- `Expression.Coalesce`.
        /// </summary>
        public static void TestMethod45()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            //* ----------------- Example with a string with null value ----------------------- *//
            // 1. Define an Expression for a potentially null string
            ParameterExpression inputString = Expression.Parameter(typeof(string) , "input");

            // 2. Define an Expression for the default value
            ConstantExpression defaultValue = Expression.Constant("Default Value" , typeof(string));

            // 3. Create the Coalesce Expression: input ?? "Default Value"
            // The first argument to Expression.Coalesce must be nullable.
            // If it's a value type, it needs to be a Nullable<T>.
            // For reference types like string, it's inherently nullable.
            BinaryExpression coalesceExpression = Expression.Coalesce(inputString , defaultValue);

            // 4. Compile the expression into a callable delegate
            Func<string , string> coalesceFunc = Expression.Lambda<Func<string , string>>(coalesceExpression , inputString).Compile();

            // 5. Test cases
            string test1 = "Hello World";
            string result1 = coalesceFunc(test1);
            Console.WriteLine($"Input: \"{test1}\", Result: \"{result1}\"");

            string test2 = null;
            string result2 = coalesceFunc(test2);
            Console.WriteLine($"Input: null, Result: \"{result2}\"");

            //* ----------------- Example with a Nullable<int> ----------------------- *//
            ParameterExpression inputInt = Expression.Parameter(typeof(int?) , "inputInt");
            ConstantExpression defaultInt = Expression.Constant(0 , typeof(int?)); // Must be Nullable<int> for the default as well
            BinaryExpression coalesceIntExpression = Expression.Coalesce(inputInt , defaultInt);
            Func<int? , int?> coalesceIntFunc = Expression.Lambda<Func<int? , int?>>(coalesceIntExpression , inputInt).Compile();

            int? intTest1 = 123;
            int? intResult1 = coalesceIntFunc(intTest1);
            Console.WriteLine($"Input: {intTest1}, Result: {intResult1}"); // Output: Input: 123, Result: 123

            int? intTest2 = null;
            int? intResult2 = coalesceIntFunc(intTest2);
            Console.WriteLine($"Input: null, Result: {intResult2}");
        }

        /// <summary>
        /// illustrate how to create an expression about `unboxing` 
        /// 
        /// `Expression.Unbox`
        /// </summary>
        public static void TestMethod46()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            // 1. Define a parameter expression for an object (representing a boxed value type)
            ParameterExpression boxedValue = Expression.Parameter(typeof(object) , "boxedValue");

            // 2. Define the target value type (e.g., int)
            Type targetType = typeof(int);

            // 3. Create an Unbox expression
            // This expression will unbox 'boxedValue' to an 'int'
            Expression unboxExpression = Expression.Unbox(boxedValue , targetType);

            // 4. Create a Lambda Expression that takes the boxed object and returns the unboxed int
            // The lambda will look something like: (object boxedValue) => (int)boxedValue
            Expression<Func<object , int>> unboxLambda =
                Expression.Lambda<Func<object , int>>(unboxExpression , boxedValue);

            // 5. Compile the lambda expression into an executable delegate
            Func<object , int> unboxDelegate = unboxLambda.Compile();

            // 6. Test the delegate with a boxed integer
            int originalValue = 42;
            object boxedInteger = originalValue; // Implicit boxing

            int unboxedValue = unboxDelegate(boxedInteger);

            Console.WriteLine($"Original value: {originalValue}");
            Console.WriteLine($"Boxed value type: {boxedInteger.GetType()}");
            Console.WriteLine($"Unboxed value: {unboxedValue}");
            Console.WriteLine($"Unboxed value type: {unboxedValue.GetType()}");

            // Example with a different value type (double)
            ParameterExpression boxedDouble = Expression.Parameter(typeof(object) , "boxedDouble");
            Type targetDoubleType = typeof(double);
            Expression unboxDoubleExpression = Expression.Unbox(boxedDouble , targetDoubleType);
            Expression<Func<object , double>> unboxDoubleLambda =
                Expression.Lambda<Func<object , double>>(unboxDoubleExpression , boxedDouble);
            Func<object , double> unboxDoubleDelegate = unboxDoubleLambda.Compile();

            double originalDouble = 3.14;
            object boxedDoubleValue = originalDouble;
            double unboxedDouble = unboxDoubleDelegate(boxedDoubleValue);

            Console.WriteLine($"\nOriginal double: {originalDouble}");
            Console.WriteLine($"Boxed double type: {boxedDoubleValue.GetType()}");
            Console.WriteLine($"Unboxed double: {unboxedDouble}");
            Console.WriteLine($"Unboxed double type: {unboxedDouble.GetType()}");
        }

        /// <summary>
        /// illustrate how to create an expression about `unboxing` 
        /// 
        /// `Expression.Unbox`
        /// 
        /// But unbox the target value with wrong type.
        /// </summary>
        public static void TestMethod47()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // What happens if you try to unbox to the wrong type?
            // This will throw an InvalidCastException at runtime when the delegate is invoked.

            ParameterExpression boxedValue = Expression.Parameter(typeof(object) , "boxedValue");

            int originalValue = 42;
            object boxedInteger = originalValue; // Implicit boxing

            try
            {
                Type wrongTargetType = typeof(string);
                Expression wrongUnboxExpression = Expression.Unbox(boxedValue , wrongTargetType);
                Expression<Func<object , string>> wrongUnboxLambda =
                    Expression.Lambda<Func<object , string>>(wrongUnboxExpression , boxedValue);
                Func<object , string> wrongUnboxDelegate = wrongUnboxLambda.Compile();


                string wrongUnboxedValue = wrongUnboxDelegate(boxedInteger);
                Console.WriteLine($"Wrong unboxed value: {wrongUnboxedValue}");
            }
            catch(InvalidCastException ex)
            {
                Console.WriteLine($"Caught an `InvalidCastException` exception:\n {ex.Message}");
            }
            catch(ArgumentException ex)
            {
                Console.WriteLine($"Caught an `ArgumentException` exception:\n{ex.Message}");
            }
            finally
            {
                Console.WriteLine($"Finished to caught a boxed value: {boxedInteger}");
            }

        }

        /// <summary>
        /// illustrate how to create an expression about `boxing` 
        /// </summary>
        public static void TestMethod48()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            var anonymousInstance = new { Value1 = default(int) , Value2 = default(string) };
            Type anonymousType = anonymousInstance.GetType();

            Expression<Func<object>> directBoxingLambda =
                Expression.Lambda<Func<object>>(
                    Expression.Convert(
                        Expression.New(
                            anonymousType.GetConstructor(new [ ] { typeof(int) , typeof(string) }) ,
                            Expression.Constant(20),
                            Expression.Constant("World")
                         ),
                         typeof(object)
                    )
                );

            Console.WriteLine(directBoxingLambda.Compile().Invoke());
        }

        /// <summary>
        /// illustrate the usage of `Expression.Accept`
        /// </summary>
        public static void TestMethod49()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            // Define a simple expression tree
            Expression<Func<int , int , bool>> filter = (x , y) => (x + y) * 2 > 10 && x < 100;

            Console.WriteLine("Original Expression:");
            Console.WriteLine(filter.ToString());
            Console.WriteLine("\n--- Visiting Expression Tree ---");

            // Create an instance of our custom visitor
            var logger = new ExpressionLogger();

            // The core of the example: Call Accept on the root expression
            // This initiates the traversal process, where the Accept method
            // on each expression node calls the appropriate VisitX method on the visitor.
            logger.Visit(filter); // ExpressionVisitor's Visit method internally uses Accept

            Console.WriteLine("\n--- Traversal Log ---");
            Console.WriteLine(logger.Log);

            Console.WriteLine("\n--- Another Example: Simple arithmetic ---");
            Expression<Func<double , double , double>> calculate = (a , b) => (a * a) + (b / 2);

            var calculatorLogger = new ExpressionLogger();
            calculatorLogger.Visit(calculate);
            Console.WriteLine("\n--- Traversal Log for Calculator ---");
            Console.WriteLine(calculatorLogger.Log);
        }

        /// <summary>
        /// illustrate how to use `Expression.DebugInfo` and `Expression.ClearDebugInfo`.
        /// </summary>
        public static void TestMethod50()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            DebugErrorInfoGenerator debugInfoGenerator = new DebugErrorInfoGenerator();

            ParameterExpression parameterExpression = Expression.Parameter(typeof(int) , "arg");

            // This expression represents a lambda expression
            // that adds 1 to the parameter value.
            LambdaExpression lambdaExpression = Expression.Lambda(
                Expression.Add(
                    parameterExpression ,
                    Expression.Constant(1)
                ) ,
                new List<ParameterExpression>() { parameterExpression }
            );

            string sourceFileFullPath = $@"/AppData/User.cs";
            SymbolDocumentInfo document = Expression.SymbolDocument(sourceFileFullPath);

            DebugInfoExpression debugInfoExpression = Expression.DebugInfo(
                document: document ,
                startLine: 5 ,
                startColumn: 1 ,
                endLine: 5 ,
                endColumn: 10
            );

            debugInfoGenerator.MarkSequencePoint(lambdaExpression , 0 , debugInfoExpression);

            Console.WriteLine("After marking SequencePoint,");
            Console.WriteLine($"Logger Message:{debugInfoGenerator.Message}");
            Console.WriteLine("------------- Calling `LoggerInfo` instance method -------------");
            debugInfoGenerator.LoggerInfo();

            Console.WriteLine("------------- Calling `LoggerError` instance method -------------");
            debugInfoGenerator.LoggerError();
            
            debugInfoGenerator.Clear();

            Console.WriteLine("After clear Logger Message by `Clear` instance method call,");
            Console.WriteLine($"Logger Message:{debugInfoGenerator.Message}");
            Console.WriteLine("------------- Calling `LoggerInfo` instance method -------------");
            debugInfoGenerator.LoggerInfo();

            Console.WriteLine("------------- Calling `LoggerError` instance method -------------");

            debugInfoGenerator.MarkSequencePoint(lambdaExpression , 0 , debugInfoExpression);

            Console.WriteLine("After marking SequencePoint again,");
            Console.WriteLine($"Logger Message:{debugInfoGenerator.Message}");
            Console.WriteLine("------------- Calling `LoggerInfo` instance method -------------");
            debugInfoGenerator.LoggerInfo();

            Console.WriteLine("------------- Calling `LoggerError` instance method -------------");
            debugInfoGenerator.LoggerError();

            DebugInfoExpression clearDebugInfoExpression = Expression.ClearDebugInfo(document);

            Console.WriteLine("The DebugInfoExpression:`{0}`\nis for clearing a sequence point?\n`{1}`" , clearDebugInfoExpression .ToString(), clearDebugInfoExpression.IsClear);

            var clearDebugInfoLambdaExpression = 
                Expression.Lambda(clearDebugInfoExpression);
            clearDebugInfoLambdaExpression.Compile().DynamicInvoke();

            Console.WriteLine("After clear debug info,");
            Console.WriteLine($"Logger Message:{debugInfoGenerator.Message}");
            Console.WriteLine("------------- Calling `LoggerInfo` instance method -------------");
            debugInfoGenerator.LoggerInfo();

            Console.WriteLine("------------- Calling `LoggerError` instance method -------------");
            debugInfoGenerator.LoggerError();
        }

        public static void TestMethod51()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            DebugErrorInfoGenerator debugInfoGenerator = new DebugErrorInfoGenerator();

            ParameterExpression parameterExpression = Expression.Parameter(typeof(int) , "arg");

            // This expression represents a lambda expression
            // that adds 1 to the parameter value.
            LambdaExpression lambdaExpression = Expression.Lambda(
                Expression.Add(
                    parameterExpression ,
                    Expression.Constant(1)
                ) ,
                new List<ParameterExpression>() { parameterExpression }
            );

            string sourceFileFullPath = $@"/AppData/User.cs";
            SymbolDocumentInfo document = Expression.SymbolDocument(sourceFileFullPath);

            DebugInfoExpression debugInfoExpression = Expression.DebugInfo(
                document: document ,
                startLine: 5 ,
                startColumn: 1 ,
                endLine: 5 ,
                endColumn: 10
            );

            var debugInfoLambdaExpression = Expression.Lambda(debugInfoExpression);
            debugInfoLambdaExpression.Compile().DynamicInvoke();
        }
    }
}

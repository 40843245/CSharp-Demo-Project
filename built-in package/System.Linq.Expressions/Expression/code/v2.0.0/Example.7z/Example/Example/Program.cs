﻿using Example.Startup;
using System;


namespace Example
{
    class Program
    {
        static void Main(string [ ] args)
        {
            NLogInitializer.Initialize();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod1();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod2();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod3();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod4();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod5();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod6();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod7();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod8();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod9();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod10();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod11();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod12();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod13();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod14();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod15();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod16();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod17();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod18();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod19();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod20();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod21();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod22();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod23();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod24();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod25();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod26();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
             
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod27();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod28();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod29();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod30();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod31();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod32();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod33();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod35();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod36();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod37();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod38();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod39();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod40();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod41();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod42();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod43();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod44();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod45();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod46();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod47();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod48();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            

            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod49();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod50();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
            
            Console.WriteLine("-----------------------------------------");
            DemoClass.DemoClass1.TestMethod51();
            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();        
        }
    }
}

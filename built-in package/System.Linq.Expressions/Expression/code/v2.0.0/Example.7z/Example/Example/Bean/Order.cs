﻿using System.Collections.Generic;

namespace Example.Bean
{
    public class Order
    {
        public int OrderId { get; set; }
        public List<string> Items { get; set; } = new List<string>(); // Ensure it's initialized
        public string CustomerName { get; set; }
    }
}

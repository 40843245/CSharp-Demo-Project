﻿namespace Example.AppData
{
    public class Animal
    {
        public string species;
    }
}

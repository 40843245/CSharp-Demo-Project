﻿using Example.Globals.GlobalsFullPath;
using NLog;

namespace Example.Startup
{
    public static class NLogInitializer 
    {
        private static string fileName = GlobalsFileFullPath.NLOG_FILE_FULL_PATH;
        public static void Initialize()
        {
            NLog.LogManager.Setup().LoadConfiguration(builder => {
                builder.ForLogger().FilterMinLevel(LogLevel.Info).WriteToConsole();
                builder.ForLogger().FilterMinLevel(LogLevel.Debug).WriteToFile(fileName: fileName);
            });
        }
    }
}

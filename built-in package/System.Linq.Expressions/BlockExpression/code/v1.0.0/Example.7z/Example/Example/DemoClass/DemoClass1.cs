﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using static Example.Extensions.BlockExpressionExtensionMethods;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        public static void TestMethod1()
        {
            BlockExpression blockExpr = Expression.Block(
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("Write" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("Hello ")
                   ) ,
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("World!")
                    ) ,
                Expression.Constant(42)
            );
            StringBuilder stringBuilder = new StringBuilder();
            Console.WriteLine("blockExpr represents C# code:");
            var expressions = blockExpr.Expressions;
            foreach(var expr in expressions)
            {
                stringBuilder.AppendLine(expr.ToString());
            }
            string codeBlockText = stringBuilder.ToString();
            Console.Write(codeBlockText);
        }

        public static void TestMethod2()
        {
            BlockExpression blockExpr = Expression.Block(
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("Write" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("Hello ")
                   ) ,
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("World!")
                    ) ,
                Expression.Constant(42)
            );
            StringBuilder stringBuilder = new StringBuilder();
            Console.WriteLine("blockExpr represents C# code:");
            var expressions = blockExpr.Expressions;
            foreach(var expr in expressions)
            {
                stringBuilder.AppendLine(expr.ToString());
            }
            string codeBlockText = stringBuilder.ToString();
            Console.Write(codeBlockText);
        }

        public static void TestMethod3()
        {
            // Add the following directive to your file:
            // using System.Linq.Expressions;

            // The block expression allows for executing several expressions sequentually.
            // When the block expression is executed,
            // it returns the value of the last expression in the sequence.
            BlockExpression blockExpr = Expression.Block(
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("Write" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("Hello ")
                   ) ,
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("World!")
                    ) ,
                Expression.Constant(42)
            );

            // The following statement first creates an expression tree,
            // then compiles it, returning a delegate function.
            var compiledBlockExpr = Expression.Lambda<Func<int>>(blockExpr).Compile();
            Console.WriteLine("After compiling the block expression:");
            Console.WriteLine(compiledBlockExpr);

            // Then execute it
            var result = compiledBlockExpr();
            
            Console.WriteLine("The return value of the block expression:");
            Console.WriteLine(result);
        }

        public static void TestMethod4()
        {
            BlockExpression blockExpr = Expression.Block(
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("Write" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("Hello ")
                   ) ,
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("World!")
                    ) ,
                Expression.Constant(42)
            );

            Console.WriteLine("The result of executing the expression tree:");
            // The following statement first creates an expression tree,
            // then compiles it, and then executes it.
            var result = Expression.Lambda<Func<int>>(blockExpr).Compile()();

            // Print out the expressions from the block expression.
            Console.WriteLine("The expressions from the block expression:");
            foreach(var expr in blockExpr.Expressions)
            {
                Console.WriteLine(expr.ToString());
            }

            // Print out the result of the tree execution.
            Console.WriteLine("The return value of the block expression:");
            Console.WriteLine(result);
        }

        public static void TestMethod5()
        {
            string welcomeMessage = "Hello ";
            BlockExpression blockExpr = Expression.Block(
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("Write" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant(welcomeMessage)
                   ),
                Expression.Call(
                    null ,
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("World!")
                    ),
                Expression.Constant(42)
            );

            blockExpr.PrintInfo();
        }

        public static void TestMethod6()
        {
            ParameterExpression variable1 = Expression.Variable(typeof(int) , "x");
            ParameterExpression variable2 = Expression.Variable(typeof(string) , "message");
            BlockExpression blockExpr = Expression.Block(
                new [ ] { variable1 , variable2 } ,
                Expression.Assign(variable1 , Expression.Constant(10)) ,
                Expression.Assign(variable2 , Expression.Constant("Hello"))
            );

            blockExpr.PrintInfo();
        }

        public static void TestMethod7()
        {
            ParameterExpression variable1 = Expression.Variable(typeof(int) , "x");
            ParameterExpression variable2 = Expression.Variable(typeof(string) , "message");
            BlockExpression blockExpr = Expression.Block(
                new [ ] { variable1 , variable2 } ,
                Expression.Assign(variable1 , Expression.Constant(10)) ,
                Expression.Assign(variable2 , Expression.Constant("Hello"))
            );

            Console.WriteLine("Before updating the BlockExpression using `Update` instance method call");
            blockExpr.PrintInfo();

            ParameterExpression variable3 = Expression.Variable(typeof(string) , "greetingMessage");

            BinaryExpression expression1 = Expression.Assign(variable3 , Expression.Constant("Hello"));
            
            List<ParameterExpression> newVariables = new List<ParameterExpression>();
            newVariables.AddRange(blockExpr.Variables);
            newVariables.Add(variable3);

            List<Expression> newExpressions = new List<Expression>();
            newExpressions.AddRange(blockExpr.Expressions);
            newExpressions.Add(expression1);

            BlockExpression newBlockExpr = blockExpr.Update(
                newVariables,
                newExpressions
            );

            Console.WriteLine("After updating the BlockExpression using `Update` instance method call");
            newBlockExpr.PrintInfo();
        }

        public static void TestMethod8()
        {
            ParameterExpression variable1 = Expression.Variable(typeof(int) , "x");
            ParameterExpression variable2 = Expression.Variable(typeof(string) , "message");
            BlockExpression blockExpr = Expression.Block(
                new [ ] { variable1 , variable2 } ,
                Expression.Assign(variable1 , Expression.Constant(10)) ,
                Expression.Assign(variable2 , Expression.Constant("Hello"))
            );

            Console.WriteLine("Before updating the BlockExpression using `Update` instance method call");
            blockExpr.PrintInfo();

            Expression expression1 = Expression.Call(
                    null ,
                    typeof(Console).GetMethod("WriteLine" , new Type [ ] { typeof(String) }) ,
                    Expression.Constant("World!")
                );
           
            List<Expression> newExpressions = new List<Expression>();
            newExpressions.AddRange(blockExpr.Expressions);
            newExpressions.Add(expression1);

            BlockExpression newBlockExpr = blockExpr.Update(
                blockExpr.Variables ,
                newExpressions
            );

            Console.WriteLine("After updating the BlockExpression using `Update` instance method call");
            newBlockExpr.PrintInfo();
        }
    }
}

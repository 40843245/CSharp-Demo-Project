﻿using System;
using System.Linq.Expressions;

namespace Example.Extensions
{
    public static class BlockExpressionExtensionMethods
    {
        public static void PrintInfo(
            this BlockExpression blockExpr
        )
        {
            Console.WriteLine($"Result of last expression:{blockExpr.Result}");
            Console.WriteLine($"Variable of theses expressions:");
            var variables = blockExpr.Variables;
            foreach(var variable in variables)
            {
                Console.WriteLine(variable.ToString());
            }
            Console.WriteLine($"Theses expressions:");
            var expressions = blockExpr.Expressions;
            foreach(var expr in expressions)
            {
                Console.WriteLine(expr.ToString());
            }
            Console.WriteLine($"static type of the expression:{blockExpr.Type}");
        }
    }
}

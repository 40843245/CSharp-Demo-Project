﻿using System;
using System.Runtime.InteropServices;

namespace Example.Helper.Keyboard
{
    public static partial class CapsLockHelper
    {
        // Constants for keybd_event
        private const int KEYEVENTF_EXTENDEDKEY = 0x1;
        private const int KEYEVENTF_KEYUP = 0x2;
        private const byte VK_CAPITAL = 0x14; // Virtual Key Code for Caps Lock

        [DllImport("user32.dll" , SetLastError = true)]
        private static extern void keybd_event(byte bVk , byte bScan , uint dwFlags , UIntPtr dwExtraInfo);

        // Import GetKeyState from user32.dll
        [DllImport("user32.dll" , CharSet = CharSet.Auto , ExactSpelling = true , CallingConvention = CallingConvention.Winapi)]
        public static extern short GetKeyState(int keyCode);

        public static bool IsCapsLockOn()
        {
            return (GetKeyState(VK_CAPITAL) & 0x1) == 1;
        }

        public static void PressCapsLock()
        {
            // Press the Caps Lock key
            keybd_event(
                VK_CAPITAL , 
                0x45 , 
                KEYEVENTF_EXTENDEDKEY , 
                UIntPtr.Zero
            );
        }

        public static void ReleaseCapsLock()
        {
            // Release the Caps Lock key
            keybd_event(
                VK_CAPITAL , 
                0x45 , 
                KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP 
                , UIntPtr.Zero
            );
        }
    }
}

﻿using System;

namespace Example.Helper.Cursor
{
    public static class Cursor
    {
        public static void PrintCursorPosition()
        {
            int cursorLeftPosition1, cursorTopPosition1;
            int cursorLeftPosition2, cursorTopPosition2;
            int cursorLeftPosition3, cursorTopPosition3;

            cursorLeftPosition1 = Console.CursorLeft; // get the current cursor left position.
            cursorTopPosition1 = Console.CursorTop; // get the current cursor top position.

            // use unbox techique.
            (cursorLeftPosition2, cursorTopPosition2) = Console.GetCursorPosition(); // get current cursor position as a tuple.

            cursorLeftPosition3 = Console.GetCursorPosition().Left; // get current cursor position as a tuple and then access the zero element named `Left` to get the left position.
            cursorTopPosition3 = Console.GetCursorPosition().Top; // get current cursor position as a tuple and then access first element named `Top` to get the top position.

            Console.WriteLine("Current cursor position: ({0}, {1})" , cursorLeftPosition1 , cursorTopPosition1);

            Console.WriteLine("Current cursor position: ({0}, {1})" , cursorLeftPosition2 , cursorTopPosition2);

            Console.WriteLine("Current cursor position: ({0}, {1})" , cursorLeftPosition3 , cursorTopPosition3);
        }
    }
}

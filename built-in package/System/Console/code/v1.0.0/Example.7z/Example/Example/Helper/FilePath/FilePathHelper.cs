﻿using System;

namespace Example.Helper.FilePath
{
    public static class FilePathHelper
    {
        public static string GetRootDirectory()
        {
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string projectRootDirectory = Directory.GetParent(baseDirectory).Parent.Parent.Parent.FullName;
            return projectRootDirectory;
        }
    }
}

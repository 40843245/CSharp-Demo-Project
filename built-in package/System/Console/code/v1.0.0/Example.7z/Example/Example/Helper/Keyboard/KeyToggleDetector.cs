﻿using Example.Extensions.ExtensionMethods.ConsoleKeyInfoExtensionMethods;
using System;

namespace Example.Helper.Keyboard
{
    public class KeyToggleDetector
    {
        public ConsoleKeyInfo previousKeyInfo { get; set; }
        private Tuple<bool,bool> previousKeyLock{ get; set; }
        public KeyToggleDetector(
            ConsoleKeyInfo keyInfo
        )
        {
            this.UpdatePreviousKeyInfo(keyInfo);
        }

        public void UpdatePreviousKeyInfo(
            ConsoleKeyInfo keyInfo
        )
        {
            previousKeyInfo = keyInfo;
            previousKeyLock = keyInfo.GetLockKeys();
        }
        public bool IsKeyStateChanged(
            ConsoleKeyInfo currentKeyInfo
        ) 
        {
            bool hasSameModifiers = currentKeyInfo.Modifiers == previousKeyInfo.Modifiers;
            bool hasSameLockKeys = currentKeyInfo.GetLockKeys() == previousKeyLock;
            bool hasSameKeyChar = currentKeyInfo.KeyChar == previousKeyInfo.KeyChar;

            return !(hasSameModifiers && hasSameLockKeys && hasSameKeyChar);
        }
    }
}

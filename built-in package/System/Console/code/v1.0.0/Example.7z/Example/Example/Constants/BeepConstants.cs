﻿namespace Example.Constants
{
    public static class BeepConstants
    {
        public const int DEFAULT_FREQUENCY = 440; // Default frequency in Hertz (A4 note)

        public const int DEFAULT_DURATION = 500; // Default duration in milliseconds

        
        public const int MIN_FREQUENCY = 37;
        public const int MAX_FREQUENCY = 32767;
    }
}

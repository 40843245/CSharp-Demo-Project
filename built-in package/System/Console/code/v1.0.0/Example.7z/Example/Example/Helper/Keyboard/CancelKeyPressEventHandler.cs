﻿using System;

namespace Example.Helper.Keyboard
{
    public class CancelKeyPressEventHandler
    {
        public void CancelKeyPressEvent(object  sender , ConsoleCancelEventArgs args)
        {
            Console.WriteLine("CancelKeyPressEvent event triggered.");
            args.Cancel = true;
        }
    }
}

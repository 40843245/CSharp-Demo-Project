﻿using System;

namespace Example.Extensions.ExtensionMethods.ConsoleKeyInfoExtensionMethods
{
    public static partial class ConsoleKeyInfoExtensionMethods
    {
        /// <summary>
        /// get modifiers from ConsoleKeyInfo instance.
        /// </summary>
        /// <param name="keyInfo"></param>
        /// <returns>
        /// a tuple containing three boolean values respectively:
        /// 
        /// + Control modifier state
        /// 
        /// + Alt modifier state
        /// 
        /// + Shift modifier state
        /// </returns>
        public static Tuple<bool , bool , bool> GetModifiers(
            this ConsoleKeyInfo keyInfo
        )
        {
            Tuple<bool , bool , bool> modifiers = new Tuple<bool , bool , bool>(
                (keyInfo.Modifiers == ConsoleModifiers.Control) ,
                (keyInfo.Modifiers == ConsoleModifiers.Alt) ,
                (keyInfo.Modifiers == ConsoleModifiers.Shift)
            );
            return modifiers;
        }

        /// <summary>
        /// get the state of Caps Lock and Number Lock keys.
        /// </summary>
        /// <param name="keyInfo"></param>
        /// <returns>
        /// a tuple containing two boolean values respectively:
        /// 
        /// + caps lock state
        /// 
        /// + number lock state
        /// </returns>
        public static Tuple<bool , bool> GetLockKeys(
            this ConsoleKeyInfo keyInfo
        )
        {
            return new Tuple<bool , bool>(
                Console.CapsLock ,
                Console.NumberLock
            );
        }
    }
}

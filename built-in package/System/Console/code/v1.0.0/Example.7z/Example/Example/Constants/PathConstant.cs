﻿namespace Example.Constants
{
    public static class PathConstant
    {
        public readonly static string ROOT_DIRECTORY = Helper.FilePath.FilePathHelper.GetRootDirectory();

        public readonly static string OUTPUT_DIRECTORY = 
            Path.Combine(
                ROOT_DIRECTORY, 
                "AppData",
                "Output",
                "Console"
            );

        public readonly static string LOG_GUID_FULLPATH =
            Path.Combine(OUTPUT_DIRECTORY,Guid.NewGuid().ToString() + "_log.txt");

        public readonly static string FILE_LIST =
           Path.Combine(OUTPUT_DIRECTORY , "file list.txt");

        public readonly static string TEXT_CONTENT =
            Path.Combine(OUTPUT_DIRECTORY , "text content.txt");
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AKM.Utilities.classes.FileHandler
{
    /// <summary>
    /// utility class that handles file. 
    /// </summary>
    public static class FileHandler
    {
        /// <summary>
        /// copy file from `sourceFileFullPath` to `destinationFileFullPath` (if `destinationFileFullPath` does not exist, it will be created).
        /// 
        /// > [!NOTE]
        /// > NOTE that 
        /// >
        /// > When `destinationFileFullPath` does exist, the file will be overwritten.
        /// 
        /// > [!CAUTION]
        /// >
        /// > `sourceFileFullPath` must be a full path of file.
        /// >
        /// > If `sourceFileFullPath` is not a file (such as it is a directory), it will throw exception.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="destinationFileFullPath"></param>
        public static void Copy(string sourceFileFullPath, string destinationFileFullPath)
        {
            FileHandler.CreateFile(destinationFileFullPath);
            System.IO.File.Copy(sourceFileFullPath, destinationFileFullPath, true);
        }

        /// <summary>
        /// Creates a new file at the specified path if it does not already exist.
        /// </summary>
        /// <remarks>
        /// If a file already exists at the specified path, this method does not overwrite the existing file.
        /// Ensure that the caller has appropriate permissions to create files in the specified directory.
        /// </remarks>
        /// <param name="fileFullPath">The full path, including the file name, where the file should be created.</param>
        public static void CreateFile(string fileFullPath)
        {
            if (System.IO.File.Exists(fileFullPath))
            {
                System.IO.File.Create(fileFullPath);
            }
        }
    }
}
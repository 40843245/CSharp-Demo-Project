﻿using System.Text;

namespace Example.Extensions.ExtensionMethods.ConsoleKeyInfoExtensionMethods
{
    public static partial class ConsoleKeyInfoExtensionMethods
    {
        public static string GetInfo(
            this ConsoleKeyInfo keyInfo
        )
        {
            List<string> textList = new List<string>();
            StringBuilder stringBuilder = new StringBuilder();

            if(Console.CapsLock)
            {
                textList.Add("CapsLock");
            }
            if(Console.NumberLock)
            {
                textList.Add("NumberLock");
            }
            switch(keyInfo.Modifiers)
            {
                    case ConsoleModifiers.Control:
                        textList.Add("Control");
                        goto case ConsoleModifiers.Alt;
                    case ConsoleModifiers.Alt:
                        textList.Add("Alt");
                        goto case ConsoleModifiers.Shift;
                    case ConsoleModifiers.Shift:
                        textList.Add("Shift");
                        break;
                    default:
                        break;
            }
            if(keyInfo.KeyChar != '\0')
            {
                textList.Add(keyInfo.KeyChar.ToString());
            }

            stringBuilder.Append(string.Join("+",textList));
            return stringBuilder.ToString();
        }
    }
}

﻿using AKM.Utilities.classes.FileHandler;
using Example.Constants;
using Example.Extensions.ExtensionMethods.ConsoleKeyInfoExtensionMethods;
using Example.Helper.Cursor;
using Example.Helper.FilePath;
using Example.Helper.Keyboard;
using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrates how to stop executing code programmatically using `Console.ReadLine()` and `Console.ReadKey()` methods. 
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("Pressing an `Enter` key will continue to execute the code, that is stopped by `Console.ReadLine()`.");
            Console.ReadLine();

            Console.WriteLine("Pressing any key will continue to execute the code, that is stopped by `Console.ReadKey()`.");
            Console.ReadKey();

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illstrates how to change the console background color and reset it back to default.
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.BackgroundColor = ConsoleColor.Green;

            Console.WriteLine("This is a test message from {0} method call." , MethodBase.GetCurrentMethod().Name);

            Console.ResetColor();

            Console.WriteLine("This is another test message from {0} method call." , MethodBase.GetCurrentMethod().Name);

            Console.BackgroundColor = ConsoleColor.Red;

            Console.WriteLine("This is a test message with red background from {0} method call." , MethodBase.GetCurrentMethod().Name);

            Console.BackgroundColor = ConsoleColor.Black;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to change the console foreground color and reset it back to default.
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine("This is a test message from {0} method call." , MethodBase.GetCurrentMethod().Name);

            Console.ResetColor();

            Console.WriteLine("This is another test message from {0} method call." , MethodBase.GetCurrentMethod().Name);

            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("This is a test message with red foreground from {0} method call." , MethodBase.GetCurrentMethod().Name);

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrates how to 
        /// 
        /// + get and change the console window size
        /// 
        /// + get and change the console window position
        /// 
        /// + get buffer area size
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("current window height:{0}" , Console.WindowHeight);

            Console.WindowHeight = 40; // set height of window as 40 rows.

            Console.WriteLine("current window height:{0}" , Console.WindowHeight);

            Console.WriteLine("current window width:{0}" , Console.WindowWidth);

            Console.WindowWidth = 50; // set width of window as 50 columns.

            Console.WriteLine("current window width:{0}" , Console.WindowWidth);

            Console.WriteLine("width of buffer area:{0}" , Console.BufferWidth);

            Console.WriteLine("current window left position:{0}" , Console.WindowLeft);

            // Calculate the maximum allowed WindowLeft
            int maxAllowedWindowLeft = Console.BufferWidth - Console.WindowWidth;

            Console.WindowLeft = Math.Max(0 , Math.Min(20 , maxAllowedWindowLeft)); // set x coordinate of window as 20 relative to the initial position of window (if possible).

            Console.WriteLine("current window left position:{0}" , Console.WindowLeft);

            Console.WriteLine("Height of buffer area:{0}" , Console.BufferHeight);

            Console.WriteLine("current window top position:{0}" , Console.WindowLeft);

            // Calculate the maximum allowed WindowTop
            int maxAllowedWindowTop = Console.BufferHeight - Console.WindowHeight;

            Console.WindowTop = Math.Max(0 , Math.Min(20 , maxAllowedWindowTop)); // set y coordinate of window as 20 relative to the initial position of window (if possible).

            Console.WriteLine("current window top position:{0}" , Console.WindowTop);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrates how to get and set the cursor position in the console window.
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.WriteLine("Ready to move cursor to position (10, 10)");

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.SetCursorPosition(10 , 10); // move the cursor to position (10, 10).

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.WriteLine("After moving cursor to position (10, 10)");

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.WriteLine("Ready to move cursor to position (0, 0)");

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.CursorLeft = 0; // move the left position cursor to 0
            Console.CursorTop = 0; // move the left position cursor to 0

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.WriteLine("After moving cursor to position (0, 0)");

            Cursor.PrintCursorPosition(); // print current cursor position.

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrates how to change the visibility of the cursor in the console window.
        /// </summary>
        public static void TestMethod6()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string formattingString = "\nThe cursor is {0}.\nType any text then press Enter. " +
                "Type '+' in the first column to show \n" +
                "the cursor, '-' to hide the cursor, " +
                "or lowercase 'x' to quit:";
            string s;
            bool originalCursorVisibile;
            int originalCursorSize;

            Console.CursorVisible = true; // Initialize the cursor to visible.
            originalCursorVisibile = Console.CursorVisible;
            originalCursorSize = Console.CursorSize;
            Console.CursorSize = 100;     // Emphasize the cursor.

            while(true)
            {
                Console.WriteLine(
                    formattingString ,
                    Console.CursorVisible ? "VISIBLE" : "HIDDEN"
                );
                s = Console.ReadLine();
                if(!string.IsNullOrEmpty(s))
                {
                    if(s [ 0 ] == '+')
                    {
                        Console.CursorVisible = true;
                    }
                    else if(s [ 0 ] == '-')
                    {
                        Console.CursorVisible = false;
                    }
                    else if(s [ 0 ] == 'x')
                    {
                        break;
                    }
                }
            }
            Console.CursorVisible = originalCursorVisibile;
            Console.CursorSize = originalCursorSize;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        public static void TestMethod7()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string formattingString = "The CapsLock is {0}.\nPress `e` key to enable `CapsLock`,\nPress `d` key to disable `CapsLock`,\nPress `t` key to toggle `CapsLock`,\nor Press 'x' to exit:";

            bool capsLockIsPressed; // check if CapsLock is on or off.

            CapsLockHelper.Hook();
            while(true)
            {
                Console.WriteLine(
                    formattingString ,
                    Console.CapsLock ? "ON" : "OFF"
                );

                ConsoleKeyInfo key = Console.ReadKey(true); // read a key without displaying it in the console.
                Console.WriteLine("The user pressed: {0}" , key.KeyChar);

                if(key.Key == ConsoleKey.X)
                {
                    break; // exit the loop if 'x' is pressed.
                }

                switch(key.Key)
                {
                    case ConsoleKey.E:
                        Console.WriteLine("Pressing CapsLock");
                        CapsLockHelper.PressCapsLock(); // press CapsLock key.
                        break;
                    case ConsoleKey.D:
                        Console.WriteLine("Releasing CapsLock");
                        CapsLockHelper.ReleaseCapsLock(); // release CapsLock key.
                        break;
                    case ConsoleKey.T:
                        Console.WriteLine("Toggling CapsLock");
                        capsLockIsPressed = CapsLockHelper.IsCapsLockOn(); // check if CapsLock is in pressed state or not.
                        if(capsLockIsPressed)
                        {
                            CapsLockHelper.ReleaseCapsLock(); // release CapsLock key.
                        }
                        else
                        {
                            CapsLockHelper.PressCapsLock(); // press CapsLock key.
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid key pressed. Please press `e`, `d`, `t`, or `x`.");
                        break;
                }

                Thread.Sleep(100); // Prevent busy-waiting
            }

            CapsLockHelper.Unhook();

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to 
        /// 
        /// + detect `CapsLock` is pressed
        /// 
        /// + detect `NumLock` is pressed
        /// </summary>
        public static void TestMethod8()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("CapsLock is pressed:{0}" , Console.CapsLock);
            Console.WriteLine("NumLock is pressed:{0}" , Console.NumberLock);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// Executes a loop that prompts the user to press any key to continue or exit the loop.
        /// </summary>
        /// <remarks>This method continuously displays a message in the console, waiting for user input.
        /// The loop terminates when the user presses the "Clear" key.
        /// </remarks>
        public static void TestMethod9()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            while(true)
            {
                Console.WriteLine("Press any key to continue, or `cancel` to exit.");
                ConsoleKeyInfo key = Console.ReadKey(true); // read a key without displaying it in the console.
                if(key.Key == ConsoleKey.Clear)
                {
                    break;
                }

            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to 
        /// 
        /// + detect which key is pressed
        /// </summary>
        public static void TestMethod10()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            while(true)
            {
                Console.WriteLine("Press any key to continue, or `cancel` to exit.");
                ConsoleKeyInfo key = Console.ReadKey(true); // read a key without displaying it in the console.
                if(key.Key == ConsoleKey.Clear)
                {
                    Console.WriteLine("You pressed Clear key. Exiting...");
                    break;
                }
                Console.WriteLine("You pressed: {0}. Continuing..." , key.KeyChar);
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + change the console title
        /// </summary>
        public static void TestMethod11()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("The current console title is: \"{0}\"" ,
                      Console.Title);
            Console.WriteLine("  (Press any key to change the console title.)");
            Console.ReadKey(true);
            Console.Title = "The title has changed!";
            Console.WriteLine("Note that the new console title is \"{0}\"\n" +
                              "  (Press any key to quit.)" , Console.Title);
            Console.ReadKey(true);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + prevent example from ending if `CTL+C` is pressed
        /// </summary>
        public static void TestMethod12()
        {
            ConsoleKeyInfo key;
            // Prevent example from ending if CTL+C is pressed.
            Console.TreatControlCAsInput = true;

            Console.WriteLine("Press any combination of CTL, ALT, and SHIFT, and a console key.");
            Console.WriteLine("Press the Escape (Esc) key to quit: \n");
            do
            {
                key = Console.ReadKey();
                Console.Write(" --- You pressed ");
                if((key.Modifiers & ConsoleModifiers.Alt) != 0)
                {
                    Console.Write("ALT+");
                }
                if((key.Modifiers & ConsoleModifiers.Shift) != 0)
                {
                    Console.Write("SHIFT+");
                }
                if((key.Modifiers & ConsoleModifiers.Control) != 0)
                {
                    Console.Write("CTL+");
                }
                Console.WriteLine(key.KeyChar);
            } while(key.Key != ConsoleKey.Escape);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + detect the key press in console is available 
        /// </summary>
        public static void TestMethod13()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ConsoleKeyInfo key;

            do
            {
                Console.WriteLine("\nPress a key to display; press the 'x' key to quit.");

                // Your code could perform some useful task in the following loop. However,
                // for the sake of this example we'll merely pause for a quarter second.

                KeyboardHelper.WaitUntilKeyAvailable(); // Wait until a key is available.

                key = Console.ReadKey(true);
                Console.WriteLine("You pressed the '{0}' key." , key.Key);
            } while(key.Key != ConsoleKey.X);

            Console.WriteLine("GoodBye");

            Console.WriteLine("End of {0} method call" , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate
        /// 
        /// + set error stream of console through `Console.SetError()` method 
        /// 
        /// + get error stream of console through `Console.Error`
        /// </summary>
        public static void TestMethod14()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string [ ] args = Environment.GetCommandLineArgs();
            string errorOutput = "";
            // Make sure that there is at least one command line argument.
            if(args.Length <= 1)
            {
                errorOutput += "You must include a filename on the command line.\n";
            }

            string filePullPath = PathConstant.TEXT_CONTENT;
            // Display the contents of the file.
            StreamReader streamReader = new StreamReader(filePullPath);
            string contents = streamReader.ReadToEnd();
            streamReader.Close();
            Console.WriteLine(
                "*****Contents of file '{0}':\n\n" ,
                filePullPath
            );
            Console.WriteLine(contents);
            Console.WriteLine("*****\n");

            string logFile = PathConstant.LOG_GUID_FULLPATH;
            // Write error information to a file.
            Console.SetError(new StreamWriter(logFile));
            Console.Error.WriteLine(errorOutput);
            Console.Error.Close();
            // Reacquire the standard error stream.
            StreamWriter standardError = new StreamWriter(Console.OpenStandardError());
            standardError.AutoFlush = true;
            Console.SetError(standardError);
            Console.Error.WriteLine("\nError information written to '{0}'" , logFile);
            standardError.Close();

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read input from the console using `Console.In` and 
        /// 
        /// + write output to the console using `Console.Out`.
        /// </summary>
        public static void TestMethod15()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            TextReader textWriterInput = Console.In;
            TextWriter textWriterOutput = Console.Out;

            textWriterOutput.WriteLine("Hola Mundo!");
            textWriterOutput.Write("What is your name: ");
            String name = textWriterInput.ReadLine();

            textWriterOutput.WriteLine("Buenos Dias, {0}!" , name);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// Export console output info a log (`.log`) file under `~/AppData/Output/Console` directory.
        /// </summary>
        public static void TestMethod16()
        {
            string fileFullPath =
                FilePathHandler.FileFullPathHandler
                .GetExportedMessageFullPath(
                    MethodBase.GetCurrentMethod().Name ,
                    ".log"
                );

            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("The output on the console will be exported into a `.log` file.");
            Console.WriteLine("Press the key after it finishes will see output on the console that is exported into the `.log` file");
            Console.WriteLine("Please open the log file until the it finishes to write output into the log file.\nOtherwise, you will see incomplete output");
            Console.WriteLine("You can see these exported output at `{0}` file" , fileFullPath);
            Console.WriteLine("Waiting a while...");

            TextWriter originalConsoleOut = Console.Out;

            FileHandler.CreateFile(fileFullPath); // create the file if it does not exist.

            using(
                StreamWriter consoleStreamWriter =
                new StreamWriter(fileFullPath , true , Encoding.UTF8)
            )
            {
                Console.SetOut(consoleStreamWriter);

                Console.WriteLine("Output Message:\nHello World");

                consoleStreamWriter.Flush();
            }

            Console.SetOut(originalConsoleOut);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// The following example replaces four consecutive space characters in a string with a tab character.
        /// </summary>
        public static void TestMethod17()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            int tabSize = 4; // Define the tab size.
            string outputFilePath = FilePathHandler.FileFullPathHandler
                .GetExportedMessageFullPath(
                    MethodBase.GetCurrentMethod().Name ,
                    ".txt"
                );

            string inputFilePath = PathConstant.TEXT_CONTENT;

            using(var writer = new StreamWriter(outputFilePath))
            {
                using(var reader = new StreamReader(inputFilePath))
                {
                    // Redirect standard output from the console to the output file.
                    Console.SetOut(writer);
                    // Redirect standard input from the console to the input file.
                    Console.SetIn(reader);
                    string line;
                    while((line = Console.ReadLine()) != null)
                    {
                        string newLine = line.Replace(("").PadRight(tabSize , ' ') , "\t");
                        Console.WriteLine(newLine);
                    }
                }
            }

            TextWriter standardedOutputStream = new StreamWriter(Console.OpenStandardOutput())
            {
                AutoFlush = true
            };
            Console.SetOut(standardedOutputStream);

            TextReader standardedInputStream = new StreamReader(Console.OpenStandardInput());
            Console.SetIn(standardedInputStream);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrates how to 
        /// 
        /// + redirect standard input, output, and error streams in the console application
        /// 
        /// + check input stream is redirected to standard input stream
        /// 
        /// + check output stream is redirected to standard output stream
        /// 
        /// + check error stream is redirected to standard error stream
        /// </summary>
        public static void TestMethod18()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.WriteLine("Is it redirected to standard input stream?{0}" , Console.IsInputRedirected);
            Console.WriteLine("Is it redirected to standard output stream?{0}" , Console.IsOutputRedirected);
            Console.WriteLine("Is it redirected to standard error stream?{0}" , Console.IsErrorRedirected);

            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~");

            string textContentFullPath = PathConstant.TEXT_CONTENT;

            string outputFullPath = FilePathHandler.FileFullPathHandler
                .GetExportedMessageFullPath(
                    MethodBase.GetCurrentMethod().Name ,
                    ".log"
                );

            string errorFullPath = FilePathHandler.FileFullPathHandler
                .GetExportedErrorMessageFullPath(
                    MethodBase.GetCurrentMethod().Name ,
                    ".log"
                );

            using(StreamReader streamReader = new StreamReader(textContentFullPath))
            {
                using(StreamWriter streamWriter = new StreamWriter(outputFullPath , true , Encoding.UTF8))
                {
                    using(StreamWriter errorStreamWriter = new StreamWriter(errorFullPath , true , Encoding.UTF8))
                    {
                        // Redirect standard error from the console to the error file.
                        Console.SetError(errorStreamWriter);
                        // Redirect standard output from the console to the output file.
                        Console.SetOut(streamWriter);
                        // Redirect standard input from the console to the input file.
                        Console.SetIn(streamReader);
                        Console.SetError(new StreamWriter(Console.OpenStandardError()));

                        Console.WriteLine("Output Message:\nHello World");
                        Console.WriteLine("Is it redirected to standard input stream?{0}" , Console.IsInputRedirected);
                        Console.WriteLine("Is it redirected to standard output stream?{0}" , Console.IsOutputRedirected);
                        Console.WriteLine("Is it redirected to standard error stream?{0}" , Console.IsErrorRedirected);

                        Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~");
                    }
                }
            }

            TextReader inputStandardStream = new StreamReader(Console.OpenStandardInput());
            TextWriter outputStandardStream = new StreamWriter(Console.OpenStandardOutput())
            {
                AutoFlush = true
            };
            TextWriter errorStandardStream = new StreamWriter(Console.OpenStandardError())
            {
                AutoFlush = true
            };

            Console.SetIn(inputStandardStream);
            Console.SetOut(outputStandardStream);
            Console.SetError(errorStandardStream);

            Console.WriteLine("Is it redirected to standard input stream?{0}" , Console.IsInputRedirected);
            Console.WriteLine("Is it redirected to standard output stream?{0}" , Console.IsOutputRedirected);
            Console.WriteLine("Is it redirected to standard error stream?{0}" , Console.IsErrorRedirected);

            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~");

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illstrates how to 
        /// 
        /// + handle cancel key press event in the console application.
        /// </summary>
        public static void TestMethod19()
        {
            StreamWriter standardOutputStream = new StreamWriter(Console.OpenStandardOutput())
            {
                AutoFlush = true
            };
            Console.SetOut(standardOutputStream);

            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            Console.TreatControlCAsInput = true; // Treat `CTL+C` as input instead of terminating the application.

            CancelKeyPressEventHandler cancelKeyPressEventHandler = new CancelKeyPressEventHandler();
            Console.CancelKeyPress += cancelKeyPressEventHandler.CancelKeyPressEvent;
            Console.CancelKeyPress += (sender , args) =>
            {
                Console.WriteLine("Cancel key press event triggered. Exiting...");
                args.Cancel = true;
                Environment.Exit(0); // Exit the application gracefully
            };

            ConsoleKeyInfo key;
            do
            {
                Console.WriteLine("Press any key to continue or Press `X` key to exit, or Press cancel key (i.e. `CTL`+`C` or `CTL`+ `Fn` + `B` key) to trigger the cancel key press event.\nNOTE that DNOT press `CTL`+ `Fn` + `F11`.\nOtherwise, an exception was thrown at runtime.");
                StreamReader standardInputStream = new StreamReader(Console.OpenStandardInput());
                Console.SetIn(standardInputStream);

                key = Console.ReadKey(true);
            } while(key.Key != ConsoleKey.X);
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        public static void TestMethod20()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            ConsoleKeyInfo previousKeyInfo;
            ConsoleKeyInfo currentKeyInfo;

            Console.TreatControlCAsInput = true; // Treat `CTL+C` as input instead of terminating the application.

            Console.WriteLine("Press any key to continue.");
            previousKeyInfo = Console.ReadKey(true);

            Console.WriteLine("You pressed `{0}`." , previousKeyInfo.GetInfo());
            KeyToggleDetector keyToggleDetector;

            do
            {
                keyToggleDetector = new KeyToggleDetector(previousKeyInfo);

                Console.WriteLine("Press any key to continue or Press `X` key to exit.");
                KeyboardHelper.ClearConsoleInputBuffer(); // Clear any pending input from the console's input buffer.
                currentKeyInfo = Console.ReadKey(true); // read a key without displaying it in the console.
                if(keyToggleDetector.IsKeyStateChanged(currentKeyInfo))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Your currently pressed key `{0}` is NOT same as previous one." , currentKeyInfo.KeyChar);
                    Console.ResetColor();
                }
                if(currentKeyInfo.Key == ConsoleKey.X)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("You pressed `{0}`.Exiting..." , currentKeyInfo.GetInfo());
                    Console.ResetColor();
                    break;
                }
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("You pressed `{0}`.Continuing..." , currentKeyInfo.GetInfo());
                Console.ResetColor();

                previousKeyInfo = currentKeyInfo;
                Thread.Sleep(1000); // Prevent busy-waiting                
            } while(true);

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrates how to
        /// 
        /// + play a beep sound in the console application using `Console.Beep` method.
        /// </summary>
        public static void TestMethod21()
        {
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            ConsoleKeyInfo currentKeyInfo;
            int frequency = 800;
            int duration = 1000;
            Console.TreatControlCAsInput = true; // Treat `CTL+C` as input instead of terminating the application. 

            do
            {
                Console.WriteLine("Press any key to continue and then beep,\nor Press `S` to set the frequency and duration of beep then beep,\nor Press `X` key to exit.");
                KeyboardHelper.WaitUntilKeyAvailable(); // Wait until a key is available.

                currentKeyInfo = Console.ReadKey(true); // read a key without displaying it in the console.

                if(currentKeyInfo.Key == ConsoleKey.S)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("You pressed `{0}`.Continuing..." , currentKeyInfo.GetInfo());

                    Console.WriteLine("Enter the frequency (in Hz) for the beep sound:");

                    //Console.Clear();

                    Console.ForegroundColor = ConsoleColor.Green;

                    string frequencyConsoleReadLine = Console.ReadLine();
                    Console.WriteLine("frequencyConsoleReadLine:{0}", frequencyConsoleReadLine);
                    if(!(int.TryParse(frequencyConsoleReadLine , out frequency) && frequency > 0))
                    {
                        frequency = Math.Clamp(
                            BeepConstants.DEFAULT_FREQUENCY ,
                            BeepConstants.MIN_FREQUENCY ,
                            BeepConstants.MAX_FREQUENCY
                        ); // Ensure duration does not exceed maximum allowed duration.
                        Console.WriteLine("Invalid frequency. Using default frequency of {0} Hz." , BeepConstants.DEFAULT_FREQUENCY);
                    }
                    else
                    {
                        frequency = Math.Clamp(
                            frequency ,
                            BeepConstants.MIN_FREQUENCY ,
                            BeepConstants.MAX_FREQUENCY
                        ); // Ensure duration does not exceed maximum allowed duration.
                        Console.WriteLine("Frequency set to {0} Hz." , frequency);
                    }

                    //Console.Clear();
                    Console.ReadLine();

                    string durationConsoleReadLine =  Console.ReadLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("durationConsoleReadLine:{0}" , durationConsoleReadLine);
                    if(!(int.TryParse(durationConsoleReadLine , out duration) && duration > 0))
                    {
                        duration = Math.Max(1 , BeepConstants.DEFAULT_DURATION); // Ensure duration is at least 1 milliseconds.
                        Console.WriteLine("Invalid duration. Using default duration of {0} milliseconds." , BeepConstants.DEFAULT_DURATION);
                    }else
                    {                       
                        Console.WriteLine("Duration set to {0} milliseconds." , duration);
                    }

                    Console.ResetColor();
                    Console.WriteLine("Beeping with frequency {0} Hz for {1} milliseconds." , frequency , duration);
                    Console.Beep(frequency , duration);
                }
                else if(currentKeyInfo.Key == ConsoleKey.X)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("You pressed `{0}`.Exiting..." , currentKeyInfo.GetInfo());
                    Console.ResetColor();
                    break;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("You pressed `{0}`.Continuing..." , currentKeyInfo.GetInfo());
                    Console.ResetColor();
                    Console.WriteLine("Beeping...");
                    Console.Beep(); // Play a beep sound to indicate a key press.
                }
                Thread.Sleep(1000); // Prevent busy-waiting                
            } while(true);
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

﻿using System;

namespace Example.Helper.Keyboard
{
    public static class KeyboardHelper
    {
        /// <summary>
        /// Clears any pending input from the console's input buffer.
        /// </summary>
        public static void ClearConsoleInputBuffer()
        {
            while(Console.KeyAvailable)
            {
                Console.ReadKey(true); // Read and discard the key
            }
        }

        /// <summary>
        /// Clears any pending input from the console's input buffer.
        /// </summary>
        public static void ClearConsoleInputBuffer(int mode)
        {
            while(Console.KeyAvailable)
            {
                Console.ReadLine(); // Read and discard the key
            }
        }

        /// <summary>
        /// waits until a key is pressed before continuing execution.
        /// </summary>
        public static void WaitUntilKeyAvailable(int milliSeconds = 250)
        {
            while(!Console.KeyAvailable)
            {
                // Wait until a key is pressed
                Thread.Sleep(milliSeconds); // Sleep to avoid busy waiting
            }
        }
    }
}

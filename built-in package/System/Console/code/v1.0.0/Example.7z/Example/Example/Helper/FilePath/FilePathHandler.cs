﻿using Example.Constants;
using System;
using System.IO;

namespace Example.Helper.FilePath
{
    public static class FilePathHandler
    {
        public static class FileFullPathHandler
        {
            public static string GetExportedMessageFullPath(
                string methodName,
                string fileExtension = ".log"
            )
            {
                string guid = Guid.NewGuid().ToString();
                string fileName = $@"Output in {methodName} method";

                string fileDirectory = PathConstant.OUTPUT_DIRECTORY;

                string fileFullPath =
                    Path.Combine(
                        fileDirectory ,
                        $@"{fileName}_{guid}{fileExtension}"
                    );

                return fileFullPath;
            }

            public static string GetExportedErrorMessageFullPath(
                string methodName ,
                string fileExtension = ".log"
            )
            {
                string guid = Guid.NewGuid().ToString();
                string fileName = $@"Error in {methodName} method";

                string fileDirectory = PathConstant.OUTPUT_DIRECTORY;

                string fileFullPath =
                    Path.Combine(
                        fileDirectory ,
                        $@"{fileName}_{guid}{fileExtension}"
                    );

                return fileFullPath;
            }
        }
    }
}

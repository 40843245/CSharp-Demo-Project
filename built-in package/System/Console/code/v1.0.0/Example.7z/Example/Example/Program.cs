﻿// See https://aka.ms/new-console-template for more information
using Example.DemoClass;

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod1();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod2();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod3();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod4();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod5();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod6();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

/// problem with TestMethod7, it does not work as expected
//Console.WriteLine("---------------------------------------");
//DemoClass1.TestMethod7();
//Console.WriteLine("---------------------------------------");
//Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod8();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod9();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod10();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod11();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod12();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod13();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod14();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod15();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod16();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod17();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod18();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod19();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod20();
Console.WriteLine("---------------------------------------");
Console.ReadLine();

Console.WriteLine("---------------------------------------");
DemoClass1.TestMethod21();
Console.WriteLine("---------------------------------------");
Console.ReadLine();
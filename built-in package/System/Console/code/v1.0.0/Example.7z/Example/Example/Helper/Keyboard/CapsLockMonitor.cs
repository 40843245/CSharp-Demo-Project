﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Example.Helper.Keyboard
{
    public static partial class CapsLockHelper
    {
        // --- P/Invoke for Global Keyboard Hook ---
        private const int WH_KEYBOARD_LL = 13; // Hook ID for low-level keyboard hook
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_SYSKEYDOWN = 0x0104; // For system keys like Alt

        private static LowLevelKeyboardProc _proc = HookCallback;
        private static IntPtr _hookID = IntPtr.Zero;
        private static bool _lastKnownCapsLockState;

        // Delegate for the hook callback
        private delegate IntPtr LowLevelKeyboardProc(int nCode , IntPtr wParam , IntPtr lParam);

        [DllImport("user32.dll" , CharSet = CharSet.Auto , SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook , LowLevelKeyboardProc lpfn , IntPtr hMod , uint dwThreadId);

        [DllImport("user32.dll" , CharSet = CharSet.Auto , SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll" , CharSet = CharSet.Auto , SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk , int nCode , IntPtr wParam , IntPtr lParam);

        [DllImport("kernel32.dll" , CharSet = CharSet.Auto , SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        private static bool _lastCapsLockState;


        // This callback is executed when a keyboard event occurs
        private static IntPtr HookCallback(int nCode , IntPtr wParam , IntPtr lParam)
        {
            if(nCode >= 0 && (wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN))
            {
                int vkCode = Marshal.ReadInt32(lParam);

                // Check if the pressed key is Caps Lock (or any key that might trigger a state change)
                if(vkCode == VK_CAPITAL)
                {
                    Console.WriteLine("\n[SYSTEM] Caps Lock key pressed. Toggling state...");
                    // After the key press, check the actual toggled state
                    bool currentCapsLockState = IsCapsLockOn();
                    if(currentCapsLockState != _lastKnownCapsLockState)
                    {
                        _lastKnownCapsLockState = currentCapsLockState;
                        Console.WriteLine($"\n[SYSTEM] Caps Lock state changed to: {(currentCapsLockState ? "ON" : "OFF")}");
                        Console.Write("Enter text: "); // Re-prompt to keep the input line clean
                    }
                }
            }
            // Always call the next hook in the chain
            return CallNextHookEx(_hookID , nCode , wParam , lParam);
        }

        public static void Hook()
        {
            using(Process curProcess = Process.GetCurrentProcess())
            {
                using(ProcessModule curModule = curProcess.MainModule)
                {
                    _hookID = SetWindowsHookEx(WH_KEYBOARD_LL , _proc , GetModuleHandle(curModule.ModuleName) , 0);
                    if(_hookID == IntPtr.Zero)
                    {
                        Console.WriteLine("Warning: Failed to install keyboard hook. Caps Lock detection might not be real-time.");
                    }
                    else
                    {
                        Console.WriteLine("Keyboard hook installed successfully.");
                    }
                }
            }
        }

        public static void Unhook()
        {
            if(_hookID != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_hookID);
                _hookID = IntPtr.Zero;
                Console.WriteLine("Keyboard hook uninstalled.");
            }
        }
    }
}

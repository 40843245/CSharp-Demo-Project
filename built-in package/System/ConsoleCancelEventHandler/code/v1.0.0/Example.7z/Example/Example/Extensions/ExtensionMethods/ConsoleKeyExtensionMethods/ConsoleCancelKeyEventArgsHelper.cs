﻿namespace Example.Extensions.ExtensionMethods.ConsoleKeyExtensionMethods
{
    public static partial class ConsoleCancelKeyEventArgsHelper
    {
        /// <summary>
        /// get Control modifiers from ConsoleCancelEventArgs
        /// </summary>
        /// <param name="keyInfo"></param>
        /// <returns>
        /// a tuple containing two boolean values:
        /// 
        /// + the first value indicates if the `Control+C` key combination was pressed
        /// 
        /// + the second value indicates if the `Control+Break` key combination was pressed
        /// </returns>
        public static Tuple<bool , bool> GetControlModifiers(
            this ConsoleCancelEventArgs keyInfo
        )
        {
            Tuple<bool , bool> controlModifiers = new Tuple<bool , bool>(
                (keyInfo.SpecialKey == ConsoleSpecialKey.ControlC) ,
                (keyInfo.SpecialKey == ConsoleSpecialKey.ControlBreak)
            );
            return controlModifiers;
        }
    }
}

﻿using Example.Extensions.ExtensionMethods.ConsoleKeyExtensionMethods;
using System;
using System.Reflection;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrates how to 
        /// 
        /// + detect cancel key is pressed through `Console.CancelKeyPress` event
        /// 
        /// + prevent the process from terminating immediately 
        /// 
        /// when the `Console.CancelKeyPress` event concludes (by setting `args.Cancel = true`).
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call,",MethodBase.GetCurrentMethod().Name);

            Console.TreatControlCAsInput = true; // This line is optional, it allows Control+C to be treated as input rather than terminating the process immediately

            Console.CancelKeyPress += (sender , args) =>
            {
                Console.WriteLine("Cancel key pressed. Exiting gracefully...");
                bool isControlCPressed, isControlBreakPressed;
                (isControlCPressed, isControlBreakPressed) = args.GetControlModifiers(); // This line is just to demonstrate the use of the extension method
                Console.WriteLine("Special Key: `{0}`" , args.SpecialKey);
                Console.WriteLine("Is Control+C Pressed?`{0}`" , isControlCPressed);
                Console.WriteLine("Is Control+Break Pressed?`{0}`" , isControlBreakPressed);
                Console.WriteLine("args.Cancel: `{0}`" , args.Cancel);
                Console.WriteLine("args.Equal(true): `{0}`" , args.Equals(true));
                args.Cancel = true; // Prevents the process from terminating immediately
                Console.WriteLine("args.Cancel: `{0}`" , args.Cancel);
                Console.WriteLine("args.Equal(true): `{0}`" , args.Equals(true));
            };

            

            Console.WriteLine("Press any key to continue or `Ctrl+Fn+B` to cancel...");
            Console.ReadKey(true); // Wait for a key press to continue
            
            Console.WriteLine("Press any key to exit the method...");
            Console.ReadKey(true); // Wait for a key press to continue
            Console.WriteLine("End of {0} method call,",MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrates how to 
        /// 
        /// + detect cancel key is pressed through `Console.CancelKeyPress` event
        /// 
        /// + terminate the process immediately
        /// 
        /// when the `Console.CancelKeyPress` event concludes (by setting `args.Cancel = false`).
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            
            Console.TreatControlCAsInput = true; // This line is optional, it allows Control+C to be treated as input rather than terminating the process immediately

            Console.CancelKeyPress += (sender , args) =>
            {
                Console.WriteLine("Cancel key pressed. Exiting gracefully...");
                bool isControlCPressed, isControlBreakPressed;
                (isControlCPressed, isControlBreakPressed) = args.GetControlModifiers(); // This line is just to demonstrate the use of the extension method
                Console.WriteLine("Special Key: `{0}`" , args.SpecialKey);
                Console.WriteLine("Is Control+C Pressed?`{0}`" , isControlCPressed);
                Console.WriteLine("Is Control+Break Pressed?`{0}`" , isControlBreakPressed);
                Console.WriteLine("args.Cancel: `{0}`" , args.Cancel);
                Console.WriteLine("args.Equal(true): `{0}`" , args.Equals(true));
                args.Cancel = false; // terminates the process immediately
                Console.WriteLine("args.Cancel: `{0}`" , args.Cancel);
                Console.WriteLine("args.Equal(true): `{0}`" , args.Equals(true));
            };

            Console.WriteLine("Press any key to continue or `Ctrl+Fn+B` to cancel...");
            Console.ReadKey(true); // Wait for a key press to continue

            Console.WriteLine("Press any key to exit the method...");
            Console.ReadKey(true); // Wait for a key press to continue

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

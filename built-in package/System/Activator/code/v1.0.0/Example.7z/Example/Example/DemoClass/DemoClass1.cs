﻿using Example.Bean;
using Example.Helpers.Classes;
using System;
using System.Reflection;
using System.Text;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrate how to dynamically instaniate an instance which calls the constructor with no argument given current `Type` --
        /// 
        /// `Activator.CreateInstance` static method
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            object obj = Activator.CreateInstance(typeof(StringBuilder));

            StringBuilder stringBuilder = (StringBuilder)obj;
            stringBuilder.AppendLine("Hello World!");

            Console.WriteLine(stringBuilder.ToString());
        }

        /// <summary>
        /// illustrate how to dynamically instaniate an instance which calls the constructor with one or more arguments given current `Type` --
        /// 
        /// `Activator.CreateInstance` static method
        /// </summary>       
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            object [ ] parametersOfPerson = new object [ ]
            {
                1,
                "Yazawa",
                "Nico",
            };

            Person personNico = (Person)Activator.CreateInstance(typeof(Person), parametersOfPerson);

            object [ ] parametersOfGreeting = new object [ ]
            {
                personNico,
                "Welcome",
            };

            Greeting greetingToNico = (Greeting)Activator.CreateInstance(typeof(Greeting), parametersOfGreeting);

            greetingToNico.Say();
        }
    }
}

﻿using Example.Bean;
using System;

namespace Example.Helpers.Classes
{
    public class Greeting
    {
        public Person Person { get;}

        public DateTime GreetingAt { get;}

        public string GreetingMessage { get; }


        public delegate void SayDelegate();
        public Greeting(
            Person person,
            string greetingMessage
        )
        {
            GreetingAt = DateTime.Now;
            Person = person;
            GreetingMessage = greetingMessage;
        }
        public void Say()
        {
            Console.WriteLine("{0} {1}",GreetingMessage, Person);
        }
    }
}

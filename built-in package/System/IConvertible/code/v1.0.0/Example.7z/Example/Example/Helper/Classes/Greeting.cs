﻿using Example.Bean;
using System;

namespace Example.Helpers.Classes
{
    public class Greeting : IConvertible
    {
        public Person Person { get;}

        public DateTime GreetingAt { get;}

        public string GreetingMessage { get; }


        public delegate void SayDelegate();
        public Greeting(
            Person person,
            string greetingMessage
        )
        {
            GreetingAt = DateTime.Now;
            Person = person;
            GreetingMessage = greetingMessage;
        }
        public void Say()
        {
            Console.WriteLine("{0} {1}",GreetingMessage, Person);
        }

        public TypeCode GetTypeCode()
        {
            return Person.ToString().GetTypeCode();
        }

        public bool ToBoolean(IFormatProvider provider)
        {
            return !string.IsNullOrWhiteSpace(Person.ToString());
        }

        public byte ToByte(IFormatProvider provider)
        {
            return (byte)Person.Id;
        }

        public char ToChar(IFormatProvider provider)
        {
            string name = Person.ToString();
            return string.IsNullOrWhiteSpace(name) == true ? '\0' : name [ 0 ];
        }

        public DateTime ToDateTime(IFormatProvider provider)
        {
            return GreetingAt;
        }

        public decimal ToDecimal(IFormatProvider provider)
        {
            return (decimal)Person.Id;
        }

        public double ToDouble(IFormatProvider provider)
        {
            return (double)Person.Id;
        }

        public short ToInt16(IFormatProvider provider)
        {
            return (short)Person.Id;
        }

        public int ToInt32(IFormatProvider provider)
        {
            return (int)Person.Id;
        }

        public long ToInt64(IFormatProvider provider)
        {
            return (long)Person.Id;
        }

        public sbyte ToSByte(IFormatProvider provider)
        {
            return (sbyte)Person.Id;
        }

        public float ToSingle(IFormatProvider provider)
        {
            return (float)Person.Id;
        }

        public string ToString(IFormatProvider provider)
        {
            return Person.ToString();
        }

        public ushort ToUInt16(IFormatProvider provider)
        {
            return (ushort)Person.Id;
        }

        public uint ToUInt32(IFormatProvider provider)
        {
            return (uint)Person.Id;
        }

        public ulong ToUInt64(IFormatProvider provider)
        {
            return (ulong)Person.Id;
        }

        public object ToType(Type conversionType , IFormatProvider provider)
        {
            return Convert.ChangeType(this , typeof(Greeting));
        }
    }
}

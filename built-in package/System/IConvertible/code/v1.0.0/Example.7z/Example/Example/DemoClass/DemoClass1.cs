﻿using Example.Bean;
using Example.Helpers.Classes;
using System;
using System.Globalization;
using System.Reflection;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrate how to implement `IConvertible` interface.
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call" , MethodBase.GetCurrentMethod().Name);

            CultureInfo cultureInfo = CultureInfo.CurrentCulture;
            NumberFormatInfo numberFormatInfo = cultureInfo.NumberFormat;
            DateTimeFormatInfo dateTimeFormatInfo = cultureInfo.DateTimeFormat;
      
            Person personNico = new Person()
            {
                FirstName = "Yazawa" ,
                LastName = "Nico" ,
                Id = 1 ,
            };

            Greeting greetingToNico = 
                new Greeting(
                    person: personNico,
                    greetingMessage:"Welcome"
                );

            Console.WriteLine(greetingToNico.ToString());

            Console.WriteLine("nico's id:{0}",greetingToNico.ToDecimal(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToInt16(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToInt32(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToInt64(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToUInt16(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToUInt32(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToUInt64(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToByte(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToSByte(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToSingle(numberFormatInfo));
            Console.WriteLine("nico's id:{0}",greetingToNico.ToDouble(numberFormatInfo));
            Console.WriteLine("{0}'s first char is {1}",greetingToNico.ToString(),greetingToNico.ToChar(numberFormatInfo));
            Console.WriteLine("nico's typeCode:{0}",greetingToNico.GetTypeCode().ToString());

            Console.WriteLine();

            if(greetingToNico is IConvertible iConvertibleGreetingToNico)
            {
                Console.WriteLine("{0} is IConvertible" , greetingToNico.ToString());
             
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToDecimal(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToInt16(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToInt32(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToInt64(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToUInt16(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToUInt32(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToUInt64(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToByte(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToSByte(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToSingle(numberFormatInfo));
                Console.WriteLine("nico's id:{0}" , iConvertibleGreetingToNico.ToDouble(numberFormatInfo));
                Console.WriteLine("{0}'s first char is {1}" , iConvertibleGreetingToNico.ToString() , iConvertibleGreetingToNico.ToChar(numberFormatInfo));
                Console.WriteLine("nico's typeCode:{0}" , iConvertibleGreetingToNico.GetTypeCode().ToString());
            }
            else
            {
                Console.WriteLine("{0} is NOT IConvertible" , greetingToNico.ToString());
            }
        }
    }
}

﻿// See https://aka.ms/new-console-template for more information

using Example.DemoClass;

Console.WriteLine("----------------------------");
DemoClass1.TestMethod1();
Console.WriteLine("----------------------------");
Console.ReadLine();

Console.WriteLine("----------------------------");
DemoClass1.TestMethod2();
Console.WriteLine("----------------------------");
Console.ReadLine();

Console.WriteLine("----------------------------");
DemoClass1.TestMethod3();
Console.WriteLine("----------------------------");
Console.ReadLine();

Console.WriteLine("----------------------------");
DemoClass1.TestMethod4();
Console.WriteLine("----------------------------");
Console.ReadLine();

Console.WriteLine("----------------------------");
DemoClass1.TestMethod5();
Console.WriteLine("----------------------------");
Console.ReadLine();

Console.WriteLine("----------------------------");
DemoClass1.TestMethod6();
Console.WriteLine("----------------------------");
Console.ReadLine();


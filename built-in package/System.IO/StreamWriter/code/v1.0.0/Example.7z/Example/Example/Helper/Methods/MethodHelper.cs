﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Example.Helper.Methods
{
    public static class MethodHelper
    {
        /// <summary>
        /// Get caller method name.
        /// </summary>
        /// <param name="caller">
        /// caller method name
        /// </param>
        /// <returns></returns>
        public static string GetCallerMethodName([CallerMemberName] string caller = null)
        {
            return caller;
        }
    }
}

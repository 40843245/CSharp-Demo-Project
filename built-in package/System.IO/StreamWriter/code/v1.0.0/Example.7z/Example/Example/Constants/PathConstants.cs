﻿namespace Example.Constants
{
    public static class PathConstants
    {
        public static class DirectoryConstants
        {
            public static readonly string ROOT_DIRECTORY = Helper.FilePath.FilePathHelper.GetRootDirectory();

            public static readonly string APP_DATA =
            Path.Combine(ROOT_DIRECTORY , "AppData");

            public static readonly string DATA_SOURCE =
            Path.Combine(APP_DATA , "DataSource");

            public static readonly string INPUT =
                Path.Combine(DATA_SOURCE , "Input");

            public static readonly string OUTPUT =
                Path.Combine(DATA_SOURCE , "Output");
        }
    }
}

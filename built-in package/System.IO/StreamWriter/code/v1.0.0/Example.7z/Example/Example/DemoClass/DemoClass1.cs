﻿using Example.Helper.Methods;
using Example.Helper.Tasks;
using Example.Helper.Texts;
using Example.Utilities.DirectoryHandler;
using Example.Utilities.FileHandler;
using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace Example.DemoClass
{
    public static class DemoClass1
    {

        /// <summary>
        /// illustrate how to
        /// 
        /// + Write some text to a file in a specific file.
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string testMethodName = MethodBase.GetCurrentMethod().Name;
            string testMethodDirectory = System.IO.Path.Combine(Constants.PathConstants.DirectoryConstants.OUTPUT , testMethodName);

            int status = DirectoryHandler.CreateDirectory(testMethodDirectory);
            if(status == -1)
            {
                return;
            }

            string outputFilePath = System.IO.Path.Combine(testMethodDirectory , "output.txt");
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist
            using(StreamWriter streamWriter = new StreamWriter(outputFilePath , false))
            {
                streamWriter.WriteLine("This is a test message from {0} method." , MethodBase.GetCurrentMethod().Name);
                streamWriter.Write("Hello Nico,");
                streamWriter.Write("Current time is:`{0}`" , DateTime.Now.ToString());
                streamWriter.Write('\n');
                streamWriter.WriteLine("You want to dance at LoveLive club");
                streamWriter.WriteLine();
                streamWriter.WriteLine("Here is the first time to join the competition `LoveLive`");
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + **asynchronously** write some text to a file in a specific file.
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string testMethodName = MethodBase.GetCurrentMethod().Name;
            string testMethodDirectory = System.IO.Path.Combine(Constants.PathConstants.DirectoryConstants.OUTPUT , testMethodName);

            int status = DirectoryHandler.CreateDirectory(testMethodDirectory);
            if(status == -1)
            {
                return;
            }

            string outputFilePath = System.IO.Path.Combine(testMethodDirectory , "output.txt");
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist

            char [ ] charArray = new char [ ] { 'H' , 'e' , 'r' , 'e' , ' ' , 'i' , 's' , ' ' , 't' , 'h' , 'e' , ' ' , 's' , 'e' , 'n' , 't' , 'e' , 'n' , 'c' , 'e' , '.' };
            ReadOnlyMemory<char> readOnlyMemory = new ReadOnlyMemory<char>(new char [ ] { '3' , ',' , '2' , ',' , '1' , '!' , ' ' , 'g' , 'o' , '!' });
            char [] charArray2 = new char [ ] { 'f' , 'i' , 'n' , 's' , 'h' , ' ' , 'o' , 'f' , ' ', 't','h','i','s',' ','s','o','n','g','.' };
            using(StreamWriter streamWriter = new StreamWriter(outputFilePath , false))
            {
                streamWriter.WriteLineAsync(string.Format("This is a test message from {0} method." , MethodBase.GetCurrentMethod().Name));
                streamWriter.WriteAsync("Hello Nico,");
                streamWriter.WriteAsync(string.Format("Current time is:`{0}`" , DateTime.Now.ToString()));
                streamWriter.WriteAsync('\n');
                streamWriter.WriteLineAsync("You want to dance at LoveLive club");
                streamWriter.WriteLineAsync();
                streamWriter.WriteLineAsync("Here is the first time to join the competition `LoveLive`");
                streamWriter.WriteLineAsync("I will sing a song named -- lovelive paradise.");
                for(int i = 0; i < charArray.Length; i++)
                {
                    streamWriter.WriteAsync(charArray [ i ]);
                }
                streamWriter.WriteAsync('\n');
                streamWriter.WriteAsync(readOnlyMemory);
                streamWriter.WriteAsync('\n');
                streamWriter.WriteLineAsync(readOnlyMemory.ToArray(),0, readOnlyMemory.ToArray().Length);
                streamWriter.WriteAsync(charArray2,0,charArray2.Length);
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + enable and disable auto flush of stream writer
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string testMethodName = MethodBase.GetCurrentMethod().Name;
            string testMethodDirectory = System.IO.Path.Combine(Constants.PathConstants.DirectoryConstants.OUTPUT , testMethodName);

            int status = DirectoryHandler.CreateDirectory(testMethodDirectory);
            if(status == -1)
            {
                return;
            }

            char [ ] charArray = new char [ ] { 'H' , 'e' , 'r' , 'e' , ' ' , 'i' , 's' , ' ' , 't' , 'h' , 'e' , ' ' , 's' , 'e' , 'n' , 't' , 'e' , 'n' , 'c' , 'e' , '.' };
            ReadOnlySpan<char> readOnlySpan = new ReadOnlySpan<char>(new char [ ] { '3' , ',' , '2' , ',' , '1' , '!' , ' ' , 'g' , 'o' , '!' });
            char [ ] charArray2 = new char [ ] { 'f' , 'i' , 'n' , 's' , 'h' , ' ' , 'o' , 'f' , ' ' , 't' , 'h' , 'i' , 's' , ' ' , 's' , 'o' , 'n' , 'g' , '.' };

            string outputSyncWithoutAutoFlushFilePath = System.IO.Path.Combine(testMethodDirectory , "outputSyncWithoutAutoFlushFilePath.txt");
            FileHandler.CreateFile(outputSyncWithoutAutoFlushFilePath); // Create the file if it does not exist

            using(StreamWriter streamWriter = new StreamWriter(outputSyncWithoutAutoFlushFilePath,false))
            {
                streamWriter.AutoFlush = false; // Disable auto-flush to demonstrate manual flushing

                streamWriter.Write("Hello Nico,");
                streamWriter.Write(string.Format("Current time is:`{0}`" , DateTime.Now.ToString()));
                streamWriter.Write('\n');
                streamWriter.WriteLine("You want to dance at LoveLive club");
                streamWriter.WriteLine();
                streamWriter.WriteLine("Here is the first time to join the competition `LoveLive`");
                streamWriter.WriteLine("I will sing a song named -- lovelive paradise.");
                for(int i = 0; i < charArray.Length; i++)
                {
                    streamWriter.Write(charArray [ i ]);
                }
                streamWriter.Write('\n');
                streamWriter.Write(readOnlySpan);
                streamWriter.Write('\n');
                streamWriter.WriteLine(readOnlySpan.ToArray() , 0 , readOnlySpan.ToArray().Length);
                streamWriter.Write(charArray2 , 0 , charArray2.Length);

                streamWriter.Flush(); // Explicitly flush the stream to ensure data is written to the file
            }

            string outputSyncWithAutoFlushFilePath = System.IO.Path.Combine(testMethodDirectory , "outputSyncWithAutoFlushFilePath.txt");
            FileHandler.CreateFile(outputSyncWithAutoFlushFilePath); // Create the file if it does not exist

            using(StreamWriter streamWriter = new StreamWriter(outputSyncWithAutoFlushFilePath , false))
            {

                streamWriter.AutoFlush = true; // Enable auto-flush to ensure data is written immediately

                streamWriter.Write("Hello Nico,");
                streamWriter.Write(string.Format("Current time is:`{0}`" , DateTime.Now.ToString()));
                streamWriter.Write('\n');
                streamWriter.WriteLine("You want to dance at LoveLive club");
                streamWriter.WriteLine();
                streamWriter.WriteLine("Here is the first time to join the competition `LoveLive`");
                streamWriter.WriteLine("I will sing a song named -- lovelive paradise.");
                for(int i = 0; i < charArray.Length; i++)
                {
                    streamWriter.Write(charArray [ i ]);
                }
                streamWriter.Write('\n');
                streamWriter.Write(readOnlySpan);
                streamWriter.Write('\n');
                streamWriter.WriteLine(readOnlySpan.ToArray() , 0 , readOnlySpan.ToArray().Length);
                streamWriter.Write(charArray2 , 0 , charArray2.Length);

                // streamWriter.Flush(); // we don't need to call Flush() explicitly since AutoFlush is true
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + enable and disable auto flush of stream writer
        /// </summary>
        public async static void TestMethod4()
        {
            string testMethodName = MethodHelper.GetCallerMethodName();
            Console.WriteLine("In {0} method call," , testMethodName);

            string testMethodDirectory = System.IO.Path.Combine(Constants.PathConstants.DirectoryConstants.OUTPUT , testMethodName);

            int status = DirectoryHandler.CreateDirectory(testMethodDirectory);
            if(status == -1)
            {
                return;
            }

            char [ ] charArray = new char [ ] { 'H' , 'e' , 'r' , 'e' , ' ' , 'i' , 's' , ' ' , 't' , 'h' , 'e' , ' ' , 's' , 'e' , 'n' , 't' , 'e' , 'n' , 'c' , 'e' , '.' };
            char [] charArry3 = { '3' , ',' , '2' , ',' , '1' , '!' , ' ' , 'g' , 'o' , '!' };
            char [ ] charArray2 = new char [ ] { 'f' , 'i' , 'n' , 's' , 'h' , ' ' , 'o' , 'f' , ' ' , 't' , 'h' , 'i' , 's' , ' ' , 's' , 'o' , 'n' , 'g' , '.' };

            string outputAsyncWithoutAutoFlushFilePath = System.IO.Path.Combine(testMethodDirectory , "outputAsyncWithoutAutoFlushFilePath.txt");
            FileHandler.CreateFile(outputAsyncWithoutAutoFlushFilePath); // Create the file if it does not exist

            using(StreamWriter streamWriter = new StreamWriter(outputAsyncWithoutAutoFlushFilePath , false))
            {
                streamWriter.AutoFlush = false; // Disable auto-flush to demonstrate manual flushing

                await streamWriter.WriteAsync("Hello Nico,");
                await streamWriter.WriteAsync(string.Format("Current time is:`{0}`" , DateTime.Now.ToString()));
                await streamWriter.WriteAsync('\n');
                await streamWriter.WriteLineAsync("You want to dance at LoveLive club");
                await streamWriter.WriteLineAsync();
                await streamWriter.WriteLineAsync("Here is the first time to join the competition `LoveLive`");
                await streamWriter.WriteLineAsync("I will sing a song named -- lovelive paradise.");
                for(int i = 0; i < charArray.Length; i++)
                {
                    await streamWriter.WriteAsync(charArray [ i ]);
                }
                await streamWriter.WriteAsync('\n');
                await streamWriter.WriteAsync(charArry3,0,charArry3.Length);
                await streamWriter.WriteAsync('\n');
                await streamWriter.WriteLineAsync(charArry3 , 0 , charArry3.Length);
                await streamWriter.WriteLineAsync(charArray2 , 0 , charArray2.Length);

                await streamWriter.FlushAsync(); // Explicitly flush the stream to ensure data is written to the file
            }

            string outputAsyncWithAutoFlushFilePath = System.IO.Path.Combine(testMethodDirectory , "outputAsyncWithAutoFlushFilePath.txt");
            FileHandler.CreateFile(outputAsyncWithAutoFlushFilePath); // Create the file if it does not exist

            using(StreamWriter streamWriter = new StreamWriter(outputAsyncWithAutoFlushFilePath , false))
            {
                streamWriter.AutoFlush = true; // Enable auto-flush to ensure data is written immediately

                await streamWriter.WriteAsync("Hello Nico,");
                await streamWriter.WriteAsync(string.Format("Current time is:`{0}`" , DateTime.Now.ToString()));
                await streamWriter.WriteAsync('\n');
                await streamWriter.WriteLineAsync("You want to dance at LoveLive club");
                await streamWriter.WriteLineAsync();
                await streamWriter.WriteLineAsync("Here is the first time to join the competition `LoveLive`");
                await streamWriter.WriteLineAsync("I will sing a song named -- lovelive paradise.");
                for(int i = 0; i < charArray.Length; i++)
                {
                    streamWriter.Write(charArray [ i ]);
                }
                await streamWriter.WriteAsync('\n');
                await streamWriter.WriteAsync(charArry3,0,charArry3.Length);
                await streamWriter.WriteAsync('\n');
                await streamWriter.WriteLineAsync(charArry3 , 0 , charArry3.Length);
                await streamWriter.WriteLineAsync(charArray2 , 0 , charArray2.Length);

                // await streamWriter.FlushAsync(); // we don't need to call FlushAsync() explicitly since AutoFlush is true
            }

            Console.WriteLine("End of {0} method call," , testMethodName);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + write some text to a file with different encoding.
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string outputFilePath;
            string outputFileName;
            string formattingString;
            string testMethodName = MethodBase.GetCurrentMethod().Name;
            string testMethodDirectory = System.IO.Path.Combine(Constants.PathConstants.DirectoryConstants.OUTPUT , testMethodName);

            int status = DirectoryHandler.CreateDirectory(testMethodDirectory);
            if(status == -1)
            {
                return;
            }

            int counter = 1;
            formattingString = "output ex{0}.txt";

            ///* --------------- Example 1 --------------- *///
            Console.WriteLine("///* --------------- Example {0} --------------- *///" , counter);
            outputFileName = string.Format(formattingString , counter);
            outputFilePath = System.IO.Path.Combine(testMethodDirectory , outputFileName);
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist

            using(
                StreamWriter streamWriter =
                    new StreamWriter(
                        outputFilePath ,
                        false ,
                        encoding: Encoding.Unicode
                    )
            )
            {
                streamWriter.WriteLine("Current encoding is `{0}`" , streamWriter.Encoding.EncodingName);

                streamWriter.Write("Hello Nico,");
                streamWriter.Write("Current time is:`{0}`" , DateTime.Now.ToString());
                streamWriter.Write('\n');
                streamWriter.WriteLine("You want to dance at LoveLive club");
                streamWriter.WriteLine();
                streamWriter.WriteLine("Here is the first time to join the competition `LoveLive`");
            }

            counter++;

            ///* --------------- Example 2 --------------- *///
            Console.WriteLine("///* --------------- Example {0} --------------- *///" , counter);
            outputFileName = string.Format(formattingString , counter);
            outputFilePath = System.IO.Path.Combine(testMethodDirectory , outputFileName);
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist

            using(
                StreamWriter streamWriter =
                    new StreamWriter(
                        outputFilePath ,
                        false ,
                        encoding: Encoding.UTF32
                    )
            )
            {
                streamWriter.WriteLine("Current encoding is `{0}`" , streamWriter.Encoding.EncodingName);

                streamWriter.Write("Hello Nico,");
                streamWriter.Write("Current time is:`{0}`" , DateTime.Now.ToString());
                streamWriter.Write('\n');
                streamWriter.WriteLine("You want to dance at LoveLive club");
                streamWriter.WriteLine();
                streamWriter.WriteLine("Here is the first time to join the competition `LoveLive`");
            }

            counter++;

            ///* --------------- Example 3 --------------- *///
            Console.WriteLine("///* --------------- Example {0} --------------- *///" , counter);
            outputFileName = string.Format(formattingString , counter);
            outputFilePath = System.IO.Path.Combine(testMethodDirectory , outputFileName);
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist

            using(
                StreamWriter streamWriter =
                    new StreamWriter(
                        outputFilePath ,
                        false ,
                        encoding: new UnicodeEncoding()
                    )
            )
            {
                streamWriter.WriteLine("Current encoding is `{0}`" , streamWriter.Encoding.EncodingName);
                streamWriter.Write("Hello Nico,");
                streamWriter.Write("Current time is:`{0}`" , DateTime.Now.ToString());
                streamWriter.Write('\n');
                streamWriter.WriteLine("You want to dance at LoveLive club");
                streamWriter.WriteLine();
                streamWriter.WriteLine("Here is the first time to join the competition `LoveLive`");
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + get info of underlying stream through 
        /// 
        /// accessing the property of `BaseStream` instance getter property.
        /// 
        /// And also prove that
        /// 
        /// + to get that freshest info of underlying stream 
        /// 
        /// (such as Length through `streamWriter.BaseStream.Length`,
        /// 
        /// Position through `streamWriter.BaseStream.Position`)
        /// 
        /// after an operation underlying stream 
        /// 
        /// (such as set position of underlying stream back to the beginning 
        /// 
        /// through `streamWriter.BaseStream.Seek(0 , SeekOrigin.Begin)`,
        /// 
        /// we need to flush the buffer (such as through `streamWriter.Flush()` method call)
        /// </summary>
        public static void TestMethod6()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string outputFilePath;
            string outputFileName;
            string formattingString;
            string studentCouncilNameAtLoveLiveSchool = "Ayase Eli";
            string newMemberName = "Huang Jay";
            string testMethodName = MethodBase.GetCurrentMethod().Name;
            string testMethodDirectory = System.IO.Path.Combine(Constants.PathConstants.DirectoryConstants.OUTPUT , testMethodName);

            int status = DirectoryHandler.CreateDirectory(testMethodDirectory);
            if(status == -1)
            {
                return;
            }

            int counter = 1;
            formattingString = "output ex{0}.txt";
            studentCouncilNameAtLoveLiveSchool = "Ayase Eli";
            newMemberName = "Huang Jay";
            TextHelper textHelper;

            ///* --------------- Example 1 --------------- *///
            Console.WriteLine("///* --------------- Example {0} --------------- *///",counter);
            outputFileName = string.Format(formattingString , counter);
            outputFilePath = System.IO.Path.Combine(testMethodDirectory , outputFileName);
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist

            using(
                StreamWriter streamWriter =
                    new StreamWriter(
                        outputFilePath ,
                        false
                    )
            )
            {
                streamWriter.AutoFlush = false;

                textHelper = new TextHelper()
                {
                    streamWriter = streamWriter
                };

                Console.ForegroundColor = ConsoleColor.Green;

                textHelper.WriteLine("Current Position is `{0}`",streamWriter.BaseStream.Position);
                textHelper.WriteLine("Current Length is `{0}`",streamWriter.BaseStream.Length);

                Console.ForegroundColor = ConsoleColor.White;

                textHelper.WriteLine("{0}:Welcome to join LoveLive club" , studentCouncilNameAtLoveLiveSchool);
                textHelper.WriteLine("{0}:Let's say Hello to members in LoveLive club.", studentCouncilNameAtLoveLiveSchool);
                textHelper.WriteLine();
                textHelper.WriteLine("{0}:Hello Yazawa Nico.", newMemberName);
                textHelper.WriteLine("{0}:Hello Kosaka Honoka." , newMemberName);
                textHelper.WriteLine("{0}:Hello Ayase Eli." , newMemberName);
                textHelper.WriteLine("{0}:Hello Minami Kotori.",newMemberName);
                textHelper.WriteLine("{0}:Hello Sonoda Umi." , newMemberName);
                textHelper.WriteLine("{0}:Hello Hoshizora Rin." , newMemberName);
                textHelper.WriteLine("{0}:Hello Nishikino Maki." , newMemberName);
                textHelper.WriteLine("{0}:Hello Tojo Nozomi." , newMemberName);
                textHelper.WriteLine("{0}:Hello Koizumi Hanayo." , newMemberName);
                textHelper.WriteLine("And more...");

                textHelper.WriteLine("Before backing to beginning with offset 0,");

                Console.ForegroundColor = ConsoleColor.Green;

                textHelper.WriteLine("Current Position is `{0}`" , streamWriter.BaseStream.Position);
                textHelper.WriteLine("Current Length is `{0}`" , streamWriter.BaseStream.Length);

                Console.ForegroundColor = ConsoleColor.White;

                streamWriter.BaseStream.Seek(0 , SeekOrigin.Begin);

                textHelper.WriteLine("After backing to beginning with offset 0,");

                Console.ForegroundColor = ConsoleColor.Green;

                textHelper.WriteLine("Current Position is `{0}`" , streamWriter.BaseStream.Position);
                textHelper.WriteLine("Current Length is `{0}`" , streamWriter.BaseStream.Length);

                Console.ForegroundColor = ConsoleColor.White;

                textHelper.WriteLine("{0}:Please introduce yourself." , studentCouncilNameAtLoveLiveSchool);
                textHelper.WriteLine("{0}:My name is {0}" , newMemberName);
            }

            counter++;

            ///* --------------- Example 2 --------------- *///
            Console.WriteLine("///* --------------- Example {0} --------------- *///" , counter);
            outputFileName = string.Format(formattingString , counter);
            outputFilePath = System.IO.Path.Combine(testMethodDirectory , outputFileName);
            FileHandler.CreateFile(outputFilePath); // Create the file if it does not exist

            using(
                StreamWriter streamWriter =
                    new StreamWriter(
                        outputFilePath ,
                        false
                    )
            )
            {
                streamWriter.AutoFlush = false;

                textHelper = new TextHelper()
                {
                    streamWriter = streamWriter
                };

                Console.ForegroundColor = ConsoleColor.Green;

                textHelper.WriteLine("Current Position is `{0}`" , streamWriter.BaseStream.Position);
                textHelper.WriteLine("Current Length is `{0}`" , streamWriter.BaseStream.Length);

                Console.ForegroundColor = ConsoleColor.White;

                textHelper.WriteLine("{0}:Welcome to join LoveLive club" , studentCouncilNameAtLoveLiveSchool);
                textHelper.WriteLine("{0}:Let's say Hello to members in LoveLive club." , studentCouncilNameAtLoveLiveSchool);
                textHelper.WriteLine();
                textHelper.WriteLine("{0}:Hello Yazawa Nico." , newMemberName);
                textHelper.WriteLine("{0}:Hello Kosaka Honoka." , newMemberName);
                textHelper.WriteLine("{0}:Hello Ayase Eli." , newMemberName);
                textHelper.WriteLine("{0}:Hello Minami Kotori." , newMemberName);
                textHelper.WriteLine("{0}:Hello Sonoda Umi." , newMemberName);
                textHelper.WriteLine("{0}:Hello Hoshizora Rin." , newMemberName);
                textHelper.WriteLine("{0}:Hello Nishikino Maki." , newMemberName);
                textHelper.WriteLine("{0}:Hello Tojo Nozomi." , newMemberName);
                textHelper.WriteLine("{0}:Hello Koizumi Hanayo." , newMemberName);
                textHelper.WriteLine("And more...");

                streamWriter.Flush();
                
                textHelper.WriteLine("Before backing to beginning with offset 0,");

                Console.ForegroundColor = ConsoleColor.Green;

                textHelper.WriteLine("Current Position is `{0}`" , streamWriter.BaseStream.Position);
                textHelper.WriteLine("Current Length is `{0}`" , streamWriter.BaseStream.Length);

                Console.ForegroundColor = ConsoleColor.White;

                streamWriter.BaseStream.Seek(0 , SeekOrigin.Begin);

                textHelper.WriteLine("After backing to beginning with offset 0,");

                Console.ForegroundColor = ConsoleColor.Green;

                textHelper.WriteLine("Current Position is `{0}`" , streamWriter.BaseStream.Position);
                textHelper.WriteLine("Current Length is `{0}`" , streamWriter.BaseStream.Length);

                Console.ForegroundColor = ConsoleColor.White;

                textHelper.WriteLine("{0}:Please introduce yourself." , studentCouncilNameAtLoveLiveSchool);
                textHelper.WriteLine("{0}:My name is {0}" , newMemberName);
            }

            counter++;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

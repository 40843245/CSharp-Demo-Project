﻿namespace Example.Helper.Texts
{
    public class TextHelper
    {
        public required StreamWriter streamWriter { get; init; }
        public void Write(
            string formattingString,
            params object?[] args
        )
        {
            Console.Write(formattingString,args);
            streamWriter.Write(formattingString,args);
        }

        public void Write(
            string s
        )
        {
            Console.Write(s);
            streamWriter.Write(s);
        }

        public void Write(
            char c
        )
        {
            Console.Write(c);
            streamWriter.Write(c);
        }


        public void WriteLine(
            string formattingString ,
            params object? [ ] args
        )
        {
            Console.WriteLine(formattingString , args);
            streamWriter.WriteLine(formattingString , args);
        }

        public void WriteLine(
            string s
        )
        {
            Console.WriteLine(s);
            streamWriter.WriteLine(s);
        }

        public void WriteLine(
            char c
        )
        {
            Console.WriteLine(c);
            streamWriter.WriteLine(c);
        }

        public void WriteLine()
        {
            Console.WriteLine();
            streamWriter.WriteLine();
        }
    }
}

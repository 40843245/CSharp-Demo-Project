﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Example.Utilities.FileHandler
{
    /// <summary>
    /// utility class that handles file. 
    /// </summary>
    public static class FileHandler
    {
        /// <summary>
        /// copy file from `sourceFileFullPath` to `destinationFileFullPath` (if `destinationFileFullPath` does not exist, it will be created).
        /// 
        /// > [!NOTE]
        /// > NOTE that 
        /// >
        /// > When `destinationFileFullPath` does exist, the file will be overwritten.
        /// 
        /// > [!CAUTION]
        /// >
        /// > `sourceFileFullPath` must be a full path of file.
        /// >
        /// > If `sourceFileFullPath` is not a file (such as it is a directory), it will throw exception.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="destinationFileFullPath"></param>
        public static void Copy(string sourceFileFullPath , string destinationFileFullPath)
        {
            CreateFile(destinationFileFullPath);

            System.IO.File.Copy(sourceFileFullPath , destinationFileFullPath , true);
        }

        public static void CreateFile(string destinationFileFullPath)
        {
            bool exists = System.IO.File.Exists(destinationFileFullPath);
            if(!exists)
            {
                using(System.IO.File.Create(destinationFileFullPath)) // use using to auto close it after block execution
                {

                }
            }
        }
    }
}
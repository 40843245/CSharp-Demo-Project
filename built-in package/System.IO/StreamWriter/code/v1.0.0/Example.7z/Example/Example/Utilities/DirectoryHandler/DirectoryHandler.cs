﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example.Utilities.DirectoryHandler
{
    /// <summary>
    /// utility class that handles about directory
    /// </summary>
    public static class DirectoryHandler
    {
        /// <summary>
        /// return true iff `sourceFileFullPath` exists and it is a directory. (validate by `System.IO.FileAttributes`)
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool IsDirectory(string sourceFileFullPath)
        {
            bool exists = Exists(sourceFileFullPath);
            if (exists == false)
            {
                return false;
            }

            FileAttributes fileAttr = File.GetAttributes(sourceFileFullPath);
            return (fileAttr & FileAttributes.Directory) == FileAttributes.Directory;
        }

        /// <summary>
        /// return true iff `sourceFileFullPath` exists and it is a file. (validate by `System.IO.FileAttributes`)
        /// 
        /// > [!NOTE]
        /// > it is not equivalent to negation of `IsDirectory` method call.  
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool IsFile(string sourceFileFullPath)
        {
            bool exists = Exists(sourceFileFullPath);
            if (exists == false)
            {
                return false;
            }

            return !IsDirectory(sourceFileFullPath);
        }

        /// <summary>
        /// return true iff `sourceFileFullPath` is a directory or file. 
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool Exists(string sourceFileFullPath)
        {
            if (Directory.Exists(sourceFileFullPath))
            {
                return true;
            }

            if (File.Exists(sourceFileFullPath))
            {
                return true;
            }

            return false;
        }

        public static int CreateDirectory(string sourceDirectory)
        {
            if(Directory.Exists(sourceDirectory))
            {
                return 0; // directory already exists
            }
            try
            {
                Directory.CreateDirectory(sourceDirectory);
                return 1; // directory created successfully
            }
            catch(Exception ex)
            {
                return -1; // error occurred
            }
        }
        /// <summary>
        /// add a file under directory.
        /// 
        /// add a file whose full path is `sourceFileFullPath` under directory `destinationDirectory`,
        /// 
        /// then rename the new file name (with extension) (exclusive of directory of new file name) as `childName`
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="childName"></param>
        public static void AddChild(
            string sourceFileFullPath,
            string destinationDirectory,
            string childName
        )
        {
            string destinationFileFullPath = Path.Combine(destinationDirectory, childName);

            CreateDirectory(destinationDirectory);

            FileHandler.FileHandler.Copy(sourceFileFullPath, destinationFileFullPath);

            return;
        }


        /// <summary>
        /// delete directory.
        /// 
        /// delete all children of `sourceDirectory`,
        /// 
        /// then delete the folder `sourceDirectory`
        /// </summary>
        /// <param name="sourceDirectory"></param>
        public static void DeleteDirectory(string sourceDirectory)
        {
            DeleteChildren(sourceDirectory);
            Directory.Delete(sourceDirectory);
        }

        /// <summary>
        /// delete specific child of a directory.
        /// 
        /// delete specific child whose name is `childName` of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="childName"></param>
        public static void DeleteChild(string sourceDirectory, string childName)
        {
            string fileFullPath = Path.Combine(sourceDirectory, childName);
            DeleteFileOrFolder(fileFullPath);
        }

        /// <summary>
        /// delete all children of a directory.
        /// 
        /// delete all children of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        public static void DeleteChildren(string sourceDirectory)
        {
            List<string> children = FindChildren(sourceDirectory);
            int childrenLength = children.Count();
            for (int i = 0; i < childrenLength; i++)
            {
                string child = children[i];
                DeleteFileOrFolder(child);
            }
        }

        /// <summary>
        /// delete a file or folder.
        /// 
        /// delete a file or folder whose full path is `sourceFileFullPath`.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        public static void DeleteFileOrFolder(string sourceFileFullPath)
        {
            bool isDirectory = IsDirectory(sourceFileFullPath);

            if (isDirectory)
            {
                DeleteDirectory(sourceFileFullPath);
            }
            else
            {
                File.Delete(sourceFileFullPath);
            }
        }

        /// <summary>
        /// find all children of a directory.
        /// 
        /// find all children of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <returns></returns>
        public static List<string> FindChildren(string sourceDirectory)
        {
            List<string> children = new List<string>();
            List<string> tempVariable = new List<string>();
            tempVariable = Directory.GetFiles(sourceDirectory).ToList();
            children.AddRange(tempVariable);
            tempVariable = Directory.GetDirectories(sourceDirectory).ToList();
            children.AddRange(tempVariable);
            return children;
        }

        /// <summary>
        /// get specific child of a directory.
        /// 
        /// get specific child whose file name is `targetFileName` of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="targetFileName"></param>
        /// <returns></returns>
        public static string GetChild(string sourceDirectory, string targetFileName)
        {
            bool hasSpecificChild = HasChild(sourceDirectory, targetFileName);

            if (hasSpecificChild)
            {
                string targetFileFullPath = Path.Combine(sourceDirectory, targetFileName);
                return targetFileFullPath;
            }

            return null;
        }

        /// <summary>
        /// check a directory has a specific child.
        /// 
        /// check a directory `sourceDirectory` has a specific child whose name is `targetFileName`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="targetFileName"></param>
        /// <returns></returns>
        public static bool HasChild(string sourceDirectory, string targetFileName)
        {
            List<string> children = FindChildren(sourceDirectory);
            bool hasSpecificChild = children.Exists(
                child => targetFileName.Equals(Path.GetFileName(child))
            );
            return hasSpecificChild;
        }
    }
}

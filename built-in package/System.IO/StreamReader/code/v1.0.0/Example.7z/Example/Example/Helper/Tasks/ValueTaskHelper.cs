﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace Example.Helper.Tasks
{
    public static class ValueTaskHelper
    {
        /// <summary>
        /// run a task with a timeout.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="valueTaskFunc"></param>
        /// <param name="timeout"></param>
        /// <returns>
        /// + returns the task with result 
        /// 
        /// if it completes within the timeout. 
        /// 
        /// + Otherwise,
        /// 
        /// returns default value.
        /// </returns>
        public static async ValueTask<T> RunWithTimeout<T>(Func<ValueTask<T>> valueTaskFunc, TimeSpan timeout)
        {
            using (var cancellationTokenSource = new CancellationTokenSource(timeout))
            {
                var valueTask = valueTaskFunc();

                Task<T> task = valueTask.AsTask();

                if (await Task.WhenAny(task, Task.Delay(Timeout.Infinite, cancellationTokenSource.Token)) == task)
                {
                    return await valueTask; // Task completed within timeout
                }
                return default;
                // throw new TimeoutException("The operation has timed out.");
            }
        }
    }
}

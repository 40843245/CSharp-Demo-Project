﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace Example.Helper.Tasks
{
    public static class TaskHelper
    {
        /// <summary>
        /// run a task with a timeout.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="taskFunc"></param>
        /// <param name="timeout"></param>
        /// <returns>
        /// + returns the task with result 
        /// 
        /// if it completes within the timeout. 
        /// 
        /// + Otherwise,
        /// 
        /// returns default value.
        /// </returns>
        public static async Task<T> RunWithTimeout<T>(Func<Task<T>> taskFunc, TimeSpan timeout)
        {
            using (var cancellationTokenSource = new CancellationTokenSource(timeout))
            {
                var task = taskFunc();
                if (await Task.WhenAny(task, Task.Delay(Timeout.Infinite, cancellationTokenSource.Token)) == task)
                {
                    return await task; // Task completed within timeout
                }
                return default;
                // throw new TimeoutException("The operation has timed out.");
            }
        }
    }
}

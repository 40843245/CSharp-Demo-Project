﻿using Example.Helper.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrate how to
        /// 
        /// + read the content with given file with `System.IO.StreamReader`.
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                string? line = null;
                while((line = streamReader.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + seek there are available character to be read 
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                while(streamReader.Peek() > -1)
                {
                    string line = streamReader.ReadLine();
                    Console.WriteLine(line);
                }
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + seek there are available character to be read 
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int nextCharCode = -1;
                while((nextCharCode = streamReader.Peek()) > -1)
                {
                    char nextChar = (char)nextCharCode;
                    string line = streamReader.ReadLine();
                    Console.WriteLine("next char:`{0}` next char code:`{1}`,next line:{2}" , nextChar , nextCharCode , line);
                }
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read a set of character from a file using `System.IO.StreamReader`.
        /// </summary>
        public static void TestMethod4()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            int length = 10; // Define the length of the buffer
            Span<char> buffer = stackalloc char [ length ]; // Allocate a buffer on the stack

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int numberOfCharToRead = -1;
                while((numberOfCharToRead = streamReader.Read(buffer)) > 0)
                {
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , buffer.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r"));
                }
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read one character from a file using `System.IO.StreamReader`.
        /// </summary>
        public static void TestMethod5()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int nextCharCode = -1;
                while((nextCharCode = streamReader.Read()) > -1)
                {
                    char nextChar = (char)nextCharCode;
                    string nextString = nextChar.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r");
                    Console.WriteLine("next char:`{0}` next char code:`{1}`" , nextString , nextCharCode);
                }
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read more characters from a file using `System.IO.StreamReader`.
        /// </summary>
        public static void TestMethod6()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int length = 10; // Define the length of the buffer
                int index = 0;
                int count = 0;
                int numberOfCharToRead = 0;
                char [ ] buffer = new char [ length ];
                for(
                    count = buffer.Length;
                    (numberOfCharToRead = streamReader.Read(buffer , index , count)) > 0;
                    count = buffer.Length
                )
                {
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , (new string(buffer)).Replace("\n" , "\\n").Replace("\r" , "\\r"));
                }
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read all characters from a file using `System.IO.StreamReader`.
        /// </summary>
        public static void TestMethod7()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                string fileContent = streamReader.ReadToEnd();
                string fileContentWithReplacement = fileContent.Replace("\n" , "\\n").Replace("\r" , "\\r");
                Console.WriteLine("Before reading rest of file content through invoking `ReadToEnd` method,");
                Console.WriteLine("file content:\n{0}" , fileContentWithReplacement);
                Console.WriteLine("Is file content either null or empty? {0}" , string.IsNullOrEmpty(fileContentWithReplacement));

                string fileContentAfterReadingToEnd = streamReader.ReadToEnd();
                string fileContentAfterReadingToEndWithReplacement = fileContentAfterReadingToEnd.Replace("\n" , "\\n").Replace("\r" , "\\r");
                Console.WriteLine("After reading rest of file content through invoking `ReadToEnd` method,");
                Console.WriteLine("file content:\n{0}" , fileContentAfterReadingToEndWithReplacement);
                Console.WriteLine("Is file content either null or empty? {0}" , string.IsNullOrEmpty(fileContentAfterReadingToEndWithReplacement));

                int counter = 0;
                int nextCharCode = -1;
                while((nextCharCode = streamReader.Read()) > -1)
                {
                    char nextChar = (char)nextCharCode;
                    string nextString = nextChar.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r");
                    Console.WriteLine("next char:`{0}` next char code:`{1}`" , nextString , nextCharCode);
                    counter++;
                }
                Console.WriteLine("After invoking `ReadToEnd` method, total number of characters read: {0}" , counter);
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read rest of file content asynchronously from a file using `System.IO.StreamReader` and `TaskHelper.RunWithTimeout`.
        /// </summary>
        public static void TestMethod8()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            Task<string>? readLineTask1 = null;
            Task<string>? readLineTask2 = null;

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                readLineTask1 = TaskHelper.RunWithTimeout<string>(
                    () => streamReader.ReadToEndAsync() ,
                    TimeSpan.FromSeconds(5)
                ); // Wait for the task to complete
                string fileContent = readLineTask1.Result ?? string.Empty;
                string fileContentWithReplacement = fileContent.Replace("\n" , "\\n").Replace("\r" , "\\r");
                Console.WriteLine("Before reading rest of file content through invoking `ReadToEndAsync` method,");
                Console.WriteLine("file content:\n{0}" , fileContentWithReplacement);
                Console.WriteLine("Is file content either null or empty? {0}" , string.IsNullOrEmpty(fileContentWithReplacement));

                readLineTask2 = TaskHelper.RunWithTimeout<string>(
                    () => streamReader.ReadToEndAsync() ,
                    TimeSpan.FromSeconds(5)
                ); // Wait for the task to complete

                string fileContentAfterReadingToEnd = readLineTask2.Result ?? string.Empty;
                string fileContentAfterReadingToEndWithReplacement = fileContentAfterReadingToEnd.Replace("\n" , "\\n").Replace("\r" , "\\r");
                Console.WriteLine("After reading rest of file content through invoking `ReadToEndAsync` method,");
                Console.WriteLine("file content:\n{0}" , fileContentAfterReadingToEndWithReplacement);
                Console.WriteLine("Is file content either null or empty? {0}" , string.IsNullOrEmpty(fileContentAfterReadingToEndWithReplacement));
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read more characters asynchronously from a file using `System.IO.StreamReader` and `TaskHelper.RunWithTimeout`.
        /// </summary>
        public static void TestMethod9()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            int length = 10; // Define the length of the buffer
            int index = 0;
            int count = 0;
            char [ ] buffer = new char [ length ]; // Allocate a buffer on the heap

            int nextCharacterToRead = 0;
            Task<int>? readTask = null;

            count = buffer.Length;
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                readTask = TaskHelper.RunWithTimeout<int>(
                    () => streamReader.ReadAsync(buffer , index , count) ,
                    TimeSpan.FromSeconds(5)
                ); // Wait for the task to complete
                while(readTask != null)
                {
                    nextCharacterToRead = readTask.Result;
                    if(!(nextCharacterToRead > 0))
                    {
                        break;
                    }
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , nextCharacterToRead , (new string(buffer)).Replace("\n" , "\\n").Replace("\r" , "\\r"));
                    readTask = TaskHelper.RunWithTimeout<int>(
                          () => streamReader.ReadAsync(buffer , index , count) ,
                         TimeSpan.FromSeconds(5)
                    ); // Wait for the task to complete
                }
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read file content line-by-line asynchronously from a file using `System.IO.StreamReader` and `TaskHelper.RunWithTimeout`.
        /// </summary>
        public static void TestMethod10()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            string? line = string.Empty;
            Task<string?>? readToEndTask = null;

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                readToEndTask = TaskHelper.RunWithTimeout<string?>(
                    () => streamReader.ReadLineAsync() ,
                    TimeSpan.FromSeconds(5)
                ); // Wait for the task to complete
                while(readToEndTask != null)
                {
                    line = readToEndTask.Result;
                    if(line == null)
                    {
                        break; // No more lines to read
                    }
                    Console.WriteLine(line);
                    readToEndTask = TaskHelper.RunWithTimeout<string?>(
                        () => streamReader.ReadLineAsync() ,
                        TimeSpan.FromSeconds(5)
                    ); // Wait for the task to complete   
                }
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read a set of character **with guarantee** from a file using `System.IO.StreamReader` and `Span<char>`.
        /// 
        /// </summary>
        public static void TestMethod11()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            int length = 10; // Define the length of the buffer
            Span<char> buffer = stackalloc char [ length ]; // Allocate a buffer on the stack

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int numberOfCharToRead = -1;
                while((numberOfCharToRead = streamReader.ReadBlock(buffer)) > 0)
                {
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , buffer.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r"));
                }
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read a set of character **with guarantee** from a file using `System.IO.StreamReader` and `char []`.
        /// </summary>
        public static void TestMethod12()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int length = 10; // Define the length of the buffer
                int index = 0;
                int count = 0;
                int numberOfCharToRead = 0;
                char [ ] buffer = new char [ length ];
                for(
                    count = buffer.Length;
                    (numberOfCharToRead = streamReader.ReadBlock(buffer , index , count)) > 0;
                    count = buffer.Length
                )
                {
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , (new string(buffer)).Replace("\n" , "\\n").Replace("\r" , "\\r"));
                }
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + **asynchronously** read a set of character **with guarantee** from a file using `System.IO.StreamReader` and `Span<char>`.
        /// 
        /// </summary>
        public static void TestMethod13()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            int length = 10; // Define the length of the buffer
            char [ ] buffer = new char [ length ]; // Allocate a buffer on the heap
            Array.Fill(buffer , ' ');
            Memory<char> memoryBuffer = new Memory<char>(buffer); // Create a Memory<char> from the char array

            int numberOfCharToRead = -1;
            ValueTask<int> readBlockValueTask = default;

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                readBlockValueTask = ValueTaskHelper.RunWithTimeout<int>(
                    () => streamReader.ReadBlockAsync(memoryBuffer) ,
                    TimeSpan.FromSeconds(5)
                ); // Wait for the task to complete
                numberOfCharToRead = readBlockValueTask.AsTask().Result;

                while(numberOfCharToRead > 0)
                {
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , memoryBuffer.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r"));

                    buffer = new char [ length ]; // Allocate a buffer on the heap
                    Array.Fill(buffer , ' ');
                    memoryBuffer = new Memory<char>(buffer); // Create a Memory<char> from the char array

                    readBlockValueTask = ValueTaskHelper.RunWithTimeout<int>(
                        () => streamReader.ReadBlockAsync(memoryBuffer) ,
                        TimeSpan.FromSeconds(5)
                    ); // Wait for the task to complete
                    numberOfCharToRead = readBlockValueTask.AsTask().Result;
                }
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + **asynchronously** read a set of character **with guarantee** from a file using `System.IO.StreamReader` and `char []`.
        /// </summary>
        public static void TestMethod14()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int length = 10; // Define the length of the buffer
                int index = 0;
                int count = 0;
                int numberOfCharToRead = 0;
                char [ ] buffer = new char [ length ];
                Task<int> readBlockTask = default;

                for(
                    count = buffer.Length,
                    readBlockTask = TaskHelper.RunWithTimeout<int>(
                        () => streamReader.ReadBlockAsync(buffer , index , count) ,
                        TimeSpan.FromSeconds(5)
                    ), // Wait for the task to complete
                    numberOfCharToRead = readBlockTask.Result;
                    numberOfCharToRead > 0;
                    count = buffer.Length,
                    readBlockTask = TaskHelper.RunWithTimeout<int>(
                        () => streamReader.ReadBlockAsync(buffer , index , count) ,
                        TimeSpan.FromSeconds(5)
                    ), // Wait for the task to complete
                    numberOfCharToRead = readBlockTask.Result
                )
                {
                    Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , (new string(buffer)).Replace("\n" , "\\n").Replace("\r" , "\\r"));
                }
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + detect whether the end of stream has been reached using `System.IO.StreamReader.EndOfStream` instance getter-property.
        /// </summary>
        public static void TestMethod15()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);

            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                bool isEndOfStream = false;
                isEndOfStream = streamReader.EndOfStream;
                Console.WriteLine("Is end of stream? {0}" , isEndOfStream);
                streamReader.ReadToEnd();
                isEndOfStream = streamReader.EndOfStream;
                Console.WriteLine("Is end of stream? {0}" , isEndOfStream);
            }

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + get underlying stream information using `System.IO.StreamReader.BaseStream` instance getter-property.
        /// 
        /// + get the position, length, read/write capabilities of the underlying stream
        /// 
        /// + seek the underlying stream using `System.IO.Stream.Seek` method
        /// 
        /// + etc.
        /// </summary>
        public static void TestMethod16()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            using(StreamReader streamReader = new StreamReader(filePath))
            {
                int nextCharCode = default;
                char nextChar = default;
                string restOfFileContent = default;

                Console.WriteLine("Can this stream can be read? `{0}`" , streamReader.BaseStream.CanRead);
                Console.WriteLine("Can this stream can be seeked? `{0}`" , streamReader.BaseStream.CanSeek);
                Console.WriteLine("Can this stream can be written? `{0}`" , streamReader.BaseStream.CanWrite);

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                nextCharCode = streamReader.Read();
                nextChar = (char)nextCharCode;

                Console.WriteLine("next char:`{0}`, next char code:`{1}`" , nextChar.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r") , nextCharCode);

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                restOfFileContent = streamReader.ReadToEnd();

                Console.WriteLine("rest of file content:\n{0}" , restOfFileContent.Replace("\n" , "\\n").Replace("\r" , "\\r"));

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.BaseStream.Seek(2 , SeekOrigin.Begin);

                restOfFileContent = streamReader.ReadToEnd();

                Console.WriteLine("rest of file content:\n{0}" , restOfFileContent.Replace("\n" , "\\n").Replace("\r" , "\\r"));

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.BaseStream.Seek(0 , SeekOrigin.Begin);

                nextCharCode = streamReader.Read();
                nextChar = (char)nextCharCode;

                Console.WriteLine("next char:`{0}`, next char code:`{1}`" , nextChar.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r") , nextCharCode);

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.BaseStream.Seek(5 , SeekOrigin.Current);

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + read a file with different encodings using `System.IO.StreamReader`
        /// 
        /// + check the current encoding of the stream using
        ///  
        /// `System.IO.StreamReader.CurrentEncoding` instance getter-property
        /// </summary>
        public static void TestMethod17()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            int nextCharCode = default;
            char nextChar = default;

            int counter = 1;

            ///* ----------- Example 1 ----------- *///
            Console.WriteLine("///* ----------- Example {0} ----------- *///" , counter);
            using(
                StreamReader streamReader =
                    new StreamReader(
                        filePath ,
                        new UnicodeEncoding()
                    )
            )
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Current encoding: {0}" , streamReader.CurrentEncoding.EncodingName);
                Console.ForegroundColor = ConsoleColor.White;

                nextCharCode = streamReader.Read();
                nextChar = (char)nextCharCode;

                Console.WriteLine("next char:`{0}`, next char code:`{1}`" , nextChar.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r") , nextCharCode);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Current encoding: {0}" , streamReader.CurrentEncoding.EncodingName);
                Console.ForegroundColor = ConsoleColor.White;
            }
            counter++;

            ///* ----------- Example 2 ----------- *///
            Console.WriteLine("///* ----------- Example {0} ----------- *///" , counter);
            using(
                StreamReader streamReader =
                    new StreamReader(
                        filePath ,
                        Encoding.ASCII
                    )
            )
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Current encoding: {0}" , streamReader.CurrentEncoding.EncodingName);
                Console.ForegroundColor = ConsoleColor.White;

                nextCharCode = streamReader.Read();
                nextChar = (char)nextCharCode;

                Console.WriteLine("next char:`{0}`, next char code:`{1}`" , nextChar.ToString().Replace("\n" , "\\n").Replace("\r" , "\\r") , nextCharCode);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Current encoding: {0}" , streamReader.CurrentEncoding.EncodingName);
                Console.ForegroundColor = ConsoleColor.White;
            }
            counter++;

            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to
        /// 
        /// + clear internal buffer of the `System.IO.StreamReader` 
        /// 
        /// using `System.IO.StreamReader.DiscardBufferedData` method.
        /// </summary>
        public static void TestMethod18()
        {
            Console.WriteLine("In {0} method call," , MethodBase.GetCurrentMethod().Name);
            string inputDirectory = Example.Constants.PathConstants.DirectoryConstants.INPUT;
            string fileName = "Words.txt";
            string filePath = System.IO.Path.Combine(inputDirectory , fileName);

            int numberOfCharToRead = 0;
            int index = 0;
            int count = 0;
            int length = 4; // Define the length of the buffer
            char [ ] buffer = new char [ length ]; // Allocate a buffer on the heap
            string restOfFileContent = string.Empty;

            int counter = 1;

            ///* ----------- Example 1 ----------- *///
            Console.WriteLine("///* ----------- Example {0} ----------- *///" , counter);
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                buffer = new char [ length ];
                index = 0;
                count = buffer.Length;
                numberOfCharToRead = streamReader.Read(buffer , index , count);

                Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , (new string(buffer)).Replace("\n" , "\\n").Replace("\r" , "\\r"));

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.DiscardBufferedData(); // Discard any buffered data

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                restOfFileContent = streamReader.ReadToEnd();
                Console.WriteLine("rest of file content:\n`{0}`" , restOfFileContent.Replace("\n" , "\\n").Replace("\r" , "\\r"));

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.DiscardBufferedData(); // Discard any buffered data

                Console.WriteLine("After discarding buffered data,");

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;
            }

            counter++;

            ///* ----------- Example 2 ----------- *///
            Console.WriteLine("///* ----------- Example {0} ----------- *///" , counter);
            using(StreamReader streamReader = new StreamReader(filePath))
            {
                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                buffer = new char [ length ];
                index = 0;
                count = buffer.Length;
                numberOfCharToRead = streamReader.Read(buffer , index , count);

                Console.WriteLine("read `{0}` char, these chars `{1}` to be read." , numberOfCharToRead , (new string(buffer)).Replace("\n" , "\\n").Replace("\r" , "\\r"));

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.DiscardBufferedData(); // Discard any buffered data

                Console.WriteLine("After discarding buffered data,");

                streamReader.BaseStream.Seek(2 , SeekOrigin.Begin);
                Console.WriteLine("Back to offset 2,");

                restOfFileContent = streamReader.ReadToEnd();
                Console.WriteLine("rest of file content:\n`{0}`" , restOfFileContent.Replace("\n" , "\\n").Replace("\r" , "\\r"));

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;

                streamReader.DiscardBufferedData(); // Discard any buffered data

                Console.WriteLine("After discarding buffered data,");

                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine("The length of the stream is `{0}`" , streamReader.BaseStream.Length);
                Console.WriteLine("The position of the stream is `{0}`" , streamReader.BaseStream.Position);
                Console.WriteLine("Is this stream end of stream? `{0}`" , streamReader.EndOfStream);

                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine("End of {0} method call," , MethodBase.GetCurrentMethod().Name);
        }
    }
}

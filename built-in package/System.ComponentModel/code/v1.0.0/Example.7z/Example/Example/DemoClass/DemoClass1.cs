﻿using Example.Beans;
using Example.Extensions.ExtensionMethods.AttributeExtensionMethods;
using System;
using System.ComponentModel;
using System.Reflection;

namespace Example.DemoClass
{
    public static class DemoClass1
    {
        /// <summary>
        /// illustrate 
        /// 
        /// + how to use `DescriptionAttribute` attribute inside annotation to describe the property.
        /// 
        /// + how to get the description of property. 
        /// </summary>
        public static void TestMethod1()
        {
            Console.WriteLine("In {0} method call", MethodBase.GetCurrentMethod().Name);

            DescriptionAttribute descriptionAttribute = null;
            string infoText = string.Empty;

            User userNico = new User()
            {
                Id = 1,
                Name = "Yazawa Nico",
            };

            PlayList playListNico = new PlayList()
            {
                Id = 1,
                Name = "Nico's First Playlist",
                Videos = new System.Collections.Generic.List<Video>()
                {
                    new Video() { Id = 1, Title = "Nico's First Video" },
                    new Video() { Id = 2, Title = "Nico's Second Video" }
                }
            };

            PlayLists playListsNico = new PlayLists()
            {
                PlayListMenu = new System.Collections.Generic.List<PlayList>()
                {
                    playListNico
                }
            };

            SociaMediaChannel sociaMediaChannelNico = new SociaMediaChannel()
            {
                Owner = userNico,
                PlayLists = playListsNico,
            };

            int counter = 1;

            ///*----- Example 1 -----*///
            Console.WriteLine("///*----- Example {0} -----*///", counter);

            descriptionAttribute = sociaMediaChannelNico.GetDescriptionAttribute(nameof(sociaMediaChannelNico.PlayLists));

            infoText = descriptionAttribute.GetInfo(nameof(sociaMediaChannelNico.PlayLists));

            Console.WriteLine(infoText);
            Console.WriteLine();

            counter++;

            ///*----- Example 2 -----*///
            Console.WriteLine("///*----- Example {0} -----*///", counter);

            descriptionAttribute = sociaMediaChannelNico.GetDescriptionAttribute(nameof(sociaMediaChannelNico));

            infoText = descriptionAttribute.GetInfo(nameof(sociaMediaChannelNico));

            Console.WriteLine(infoText);
            Console.WriteLine();

            counter++;

            Console.WriteLine("End of {0} method call", MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// Default -- `DescriptionAttribute.Default`
        /// </summary>
        public static void TestMethod2()
        {
            Console.WriteLine("In {0} method call", MethodBase.GetCurrentMethod().Name);
            Console.WriteLine("Description of DescriptionAttribute.Default=`{0}`", DescriptionAttribute.Default.Description);
            Console.WriteLine("End of {0} method call", MethodBase.GetCurrentMethod().Name);
        }

        /// <summary>
        /// illustrate how to check the `DescriptionAttribute` instance is a default value or not
        /// by invoking `DescriptionAttribute.IsDefaultAttribute()` instance method.
        /// </summary>
        public static void TestMethod3()
        {
            Console.WriteLine("In {0} method call", MethodBase.GetCurrentMethod().Name);

            DescriptionAttribute descriptionAttribute = null;
            string infoText = string.Empty;

            User userNico = new User()
            {
                Id = 1,
                Name = "Yazawa Nico",
            };

            PlayList playListNico = new PlayList()
            {
                Id = 1,
                Name = "Nico's First Playlist",
                Videos = new System.Collections.Generic.List<Video>()
                {
                    new Video() { Id = 1, Title = "Nico's First Video" },
                    new Video() { Id = 2, Title = "Nico's Second Video" }
                }
            };

            PlayLists playListsNico = new PlayLists()
            {
                PlayListMenu = new System.Collections.Generic.List<PlayList>()
                {
                    playListNico
                }
            };

            SociaMediaChannel sociaMediaChannelNico = new SociaMediaChannel()
            {
                Owner = userNico,
                PlayLists = playListsNico,
            };

            descriptionAttribute = sociaMediaChannelNico.GetDescriptionAttribute(nameof(sociaMediaChannelNico.PlayLists));

            Console.WriteLine("Is it a default attribute?`{0}`", descriptionAttribute.IsDefaultAttribute().ToString());

            descriptionAttribute = userNico.GetDescriptionAttribute(nameof(userNico.Name));

            Console.WriteLine("Is it a default attribute?`{0}`", descriptionAttribute.IsDefaultAttribute().ToString());

            Console.WriteLine("Is DescriptionAttribute.Default a default attribute?`{0}`", DescriptionAttribute.Default.IsDefaultAttribute().ToString());
            Console.WriteLine("End of {0} method call", MethodBase.GetCurrentMethod().Name);
        }
    }
}

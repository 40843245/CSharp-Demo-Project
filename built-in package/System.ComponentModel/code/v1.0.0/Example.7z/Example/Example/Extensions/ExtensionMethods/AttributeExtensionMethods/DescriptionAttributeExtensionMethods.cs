﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Example.Extensions.ExtensionMethods.AttributeExtensionMethods
{
    public static partial class DescriptionAttributeExtensionMethods
    {
        public static string GetDescription(
            this DescriptionAttribute descriptionAttribute
        )
        {
            if (descriptionAttribute == null)
            {
                throw new ArgumentNullException(nameof(descriptionAttribute), "Description attribute cannot be null.");
            }
            return descriptionAttribute.Description;
        }

        public static string GetInfo(
            this DescriptionAttribute descriptionAttribute,
            string propertyName
        )
        {
            try
            {
                if (descriptionAttribute == null)
                {
                    throw new ArgumentNullException(nameof(descriptionAttribute), "Description attribute cannot be null.");
                }
            }
            catch (ArgumentNullException ex)
            {
                Console.Error.WriteLine("An `ArgumentNullException` exception thrown at descriptionAttribute.GetInfo extenstion method.");
                Console.Error.WriteLine("The error message:");
                Console.Error.WriteLine(ex.Message);
                return string.Empty;
            }

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendFormat("About the property:{0}\n", propertyName);
            stringBuilder.AppendLine("\tDescription Info:");
            stringBuilder.AppendFormat("\t{0}\n",descriptionAttribute.GetDescription());
            stringBuilder.AppendLine("\tIs the description applied on a default attribute?");
            stringBuilder.AppendFormat("\t{0}\n",descriptionAttribute.IsDefaultAttribute().ToString());

            return stringBuilder.ToString();
        }

        public static DescriptionAttribute GetDescriptionAttribute(
            this object obj,
            string propertyName
        )
        {
            try
            {
                AttributeCollection attributeCollection = TypeDescriptor.GetProperties(obj)[propertyName].Attributes;
                return (DescriptionAttribute)attributeCollection[typeof(DescriptionAttribute)];
            }
            catch (System.NullReferenceException ex)
            {
                Console.Error.WriteLine("An `System.NullReferenceException` exception thrown at object.GetDescriptionAttribute extenstion method.");
                Console.Error.WriteLine("The error message:");
                Console.Error.WriteLine(ex.Message);
            }
            return null;
        }
    }
}

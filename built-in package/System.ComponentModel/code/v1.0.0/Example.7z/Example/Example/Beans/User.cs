﻿using System.ComponentModel;

namespace Example.Beans
{
    public class User
    {
        public int Id { get; init; }
        [Description("")]
        public string Name { get; set; }
    }
}

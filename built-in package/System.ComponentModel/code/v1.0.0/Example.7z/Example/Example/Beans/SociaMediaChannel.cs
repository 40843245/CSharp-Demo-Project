﻿using System.ComponentModel;

namespace Example.Beans
{
    public class SociaMediaChannel
    {
        [Description("PlayLists that category all videos")]
        public PlayLists PlayLists { get; init; }

        [Description("The info about owner of this channel in Social Media App")]
        public User Owner { get; init; }
    }
}

﻿using System.Collections.Generic;

namespace Example.Beans
{
    public class PlayList
    {
        public int Id { get; init; }
        public string Name { get; init; }
        public List<Video> Videos { get; init;  }
    }
}

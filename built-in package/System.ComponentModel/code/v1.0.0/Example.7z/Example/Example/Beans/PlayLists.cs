﻿using System.Collections.Generic;

namespace Example.Beans
{
    public class PlayLists
    {
       public List<PlayList> PlayListMenu { get; init; }
    }
}
